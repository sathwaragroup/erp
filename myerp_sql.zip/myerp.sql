-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 07, 2025 at 07:30 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myerp`
--

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`id`, `name`, `code`, `address`, `phone`, `email`, `location`, `status`, `created_at`) VALUES
(1, 'Main Branch', 'BR001', 'Ahmedabad, Gujarat', '9876543210', 'main@branch.com', 'Ahmedabad', 'Active', '2025-05-04 04:06:35'),
(2, 'South Zone', 'BR002', 'Surat, Gujarat', '9876543211', 'south@branch.com', 'Surat', 'Inactive', '2025-05-04 04:06:35'),
(3, 'North Zone', 'BR003', 'Gandhinagar', '9876543212', 'north@branch.com', 'Gandhinagar', 'Active', '2025-05-04 04:06:35'),
(4, 'West Side', 'BR004', 'Rajkot', '9876543213', 'west@branch.com', 'Rajkot', 'Inactive', '2025-05-04 04:06:35'),
(5, 'East Side', 'BR005', 'Vadodara', '9876543214', 'east@branch.com', 'Vadodara', 'Active', '2025-05-04 04:06:35'),
(6, 'Branch 6', 'BR006', 'Bharuch', '9876543215', 'br6@branch.com', 'Bharuch', 'Active', '2025-05-04 04:06:35'),
(7, 'Branch 7', 'BR007', 'Anand', '9876543216', 'br7@branch.com', 'Anand', 'Active', '2025-05-04 04:06:35'),
(8, 'Branch 8', 'BR008', 'Mehsana', '9876543217', 'br8@branch.com', 'Mehsana', 'Active', '2025-05-04 04:06:35'),
(9, 'Branch 9', 'BR009', 'Bhavnagar', '9876543218', 'br9@branch.com', 'Bhavnagar', 'Active', '2025-05-04 04:06:35'),
(10, 'Branch 10', 'BR010', 'Jamnagar', '9876543219', 'br10@branch.com', 'Jamnagar', 'Active', '2025-05-04 04:06:35'),
(11, 'Branch 11', 'BR011', 'Junagadh', '9876543220', 'br11@branch.com', 'Junagadh', '1', '2025-05-04 04:06:35'),
(12, 'Branch 12', 'BR012', 'Navsari', '9876543221', 'br12@branch.com', 'Navsari', '1', '2025-05-04 04:06:35'),
(13, 'Branch 13', 'BR013', 'Vapi', '9876543222', 'br13@branch.com', 'Vapi', '1', '2025-05-04 04:06:35'),
(14, 'Branch 14', 'BR014', 'Morbi', '9876543223', 'br14@branch.com', 'Morbi', '1', '2025-05-04 04:06:35'),
(15, 'Branch 15', 'BR015', 'Godhra', '9876543224', 'br15@branch.com', 'Godhra', '1', '2025-05-04 04:06:35'),
(16, 'Branch 16', 'BR016', 'Patan', '9876543225', 'br16@branch.com', 'Patan', '1', '2025-05-04 04:06:35'),
(17, 'Branch 17', 'BR017', 'Dahod', '9876543226', 'br17@branch.com', 'Dahod', '1', '2025-05-04 04:06:35'),
(18, 'Branch 18', 'BR018', 'Nadiad', '9876543227', 'br18@branch.com', 'Nadiad', '1', '2025-05-04 04:06:35'),
(19, 'Branch 19', 'BR019', 'Amreli', '9876543228', 'br19@branch.com', 'Amreli', '1', '2025-05-04 04:06:35'),
(20, 'Branch 20', 'BR020', 'Botad', '9876543229', 'br20@branch.com', 'Botad', '1', '2025-05-04 04:06:35'),
(21, 'Branch 21', 'BR021', 'Palanpur', '9876543230', 'br21@branch.com', 'Palanpur', '1', '2025-05-04 04:06:35'),
(22, 'Branch 22', 'BR022', 'Veraval', '9876543231', 'br22@branch.com', 'Veraval', '1', '2025-05-04 04:06:35'),
(23, 'Branch 23', 'BR023', 'Valsad', '9876543232', 'br23@branch.com', 'Valsad', '1', '2025-05-04 04:06:35'),
(24, 'Branch 24', 'BR024', 'Mandvi', '9876543233', 'br24@branch.com', 'Mandvi', '1', '2025-05-04 04:06:35'),
(25, 'Branch 25', 'BR025', 'Kutch', '9876543234', 'br25@branch.com', 'Kutch', '1', '2025-05-04 04:06:35'),
(26, 'Branch 26', 'BR026', 'Porbandar', '9876543235', 'br26@branch.com', 'Porbandar', '1', '2025-05-04 04:06:35'),
(27, 'Branch 27', 'BR027', 'Borsad', '9876543236', 'br27@branch.com', 'Borsad', '1', '2025-05-04 04:06:35'),
(28, 'Branch 28', 'BR028', 'Chhota Udepur', '9876543237', 'br28@branch.com', 'Chhota Udepur', '1', '2025-05-04 04:06:35'),
(29, 'Branch 29', 'BR029', 'Surendranagar', '9876543238', 'br29@branch.com', 'Surendranagar', '1', '2025-05-04 04:06:35'),
(30, 'Branch 30', 'BR030', 'Modasa', '9876543239', 'br30@branch.com', 'Modasa', '1', '2025-05-04 04:06:35'),
(31, 'test123', NULL, NULL, NULL, NULL, 'ahmedabad', 'Active', '2025-05-04 16:42:16');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `created_at`) VALUES
(1, 'Cable', NULL, '2025-04-29 17:35:36'),
(2, 'Pipe', NULL, '2025-04-29 17:35:36'),
(3, 'Mobile Accessories', NULL, '2025-04-29 17:35:36'),
(4, 'Cables', 'All types of cables, including USB, HDMI, Type-C, etc.', '2025-04-29 17:55:13'),
(5, 'Pipes', 'Various types of pipes, including PVC, Flexible, Steel, etc.', '2025-04-29 17:55:13'),
(6, 'Mobile Accessories', 'Accessories for mobile phones, such as screen guards and back covers', '2025-04-29 17:55:13'),
(7, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.0; Trident/3.1)', 'Ut officia ut dolor adipisci fuga vero. Optio itaque et minus laborum cumque. Quaerat occaecati voluptas corporis inventore totam. Rerum pariatur natus iusto quas et quo.', '2016-01-07 07:31:48'),
(8, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_7_2) AppleWebKit/5320 (KHTML, like Gecko) Chrome/15.0.817', 'Qui at et veritatis qui officia quaerat. Sed esse quia culpa commodi illo ducimus. Dolor et explicabo laudantium perferendis mollitia a. Debitis rerum et qui vitae numquam et consequuntur.', '2023-12-12 18:31:20'),
(9, 'Mozilla/5.0 (X11; Linuxi686; rv:7.0) Gecko/20230413 Firefox/3.6.16', 'Aliquam maxime vel dolor doloribus quo. Ea necessitatibus dolorem esse quaerat.', '2006-10-16 01:23:41'),
(10, 'Mozilla/5.0 (Windows 95; sl-SI; rv:1.9.1.20) Gecko/20160513 Firefox/3.8', 'Cumque vero commodi vel eius nam ut dolor. Nobis impedit incidunt libero eos molestias. Veritatis ut commodi architecto sunt a.', '1976-09-25 08:44:09'),
(13, 'Opera/8.58 (Windows NT 5.1; en-US) Presto/2.9.172 Version/12.00', 'Aut et quidem sunt sint beatae sunt. In itaque doloremque fugit numquam voluptas quasi. Voluptas sint aut nisi laboriosam consectetur fugit. Molestias harum voluptates officia dolorem omnis.', '1991-08-26 16:29:48'),
(14, 'Mozilla/5.0 (X11; Linuxx86_64; rv:6.0) Gecko/20190419 Firefox/12.0', 'Nobis delectus et est dolor veritatis ut saepe. Fugiat sint ducimus aliquam rerum perferendis. Minus dolorum libero vel totam. Quia dolor debitis qui ducimus.', '1998-12-02 11:56:24'),
(15, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_5_1) AppleWebKit/5360 (KHTML, like Gecko) Chrome/15.0.841.0 ', 'Delectus nobis fugiat unde sint est autem dolor dolorem. Perspiciatis et maiores suscipit sint quod distinctio aut quisquam. Voluptas molestiae et non beatae quidem excepturi et totam. Aspernatur nam tenetur maiores culpa veniam cupiditate magni dolorem. Sed enim maxime delectus vel nisi.', '1992-04-27 17:19:50'),
(16, 'Mozilla/5.0 (X11; Linuxi686; rv:5.0) Gecko/20111006 Firefox/4.0', 'Vel dolor unde est quos. Ad ut incidunt nemo porro sit veritatis. Distinctio iusto impedit voluptas odio in quod dolor quia.', '1980-03-26 15:38:27'),
(17, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows 95; Trident/5.1)', 'Provident et molestiae ab nihil ex quasi veniam. Nisi repellendus harum ea ut. Reprehenderit minima totam voluptatem debitis accusantium voluptas ab nam.', '1993-07-05 08:01:45'),
(19, 'Opera/9.52 (Windows NT 6.0; en-US) Presto/2.9.166 Version/12.00', 'Amet deserunt eveniet aperiam quidem expedita aut quaerat voluptatum. Et expedita dicta natus inventore voluptatem quasi sunt. Non voluptas dolores vitae corrupti dolor ullam rerum.', '2019-06-25 23:49:36'),
(20, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/5350 (KHTML, like Gecko) Chrome/15.0.861.0 Safari/5350', 'Dolorem ex dolores aliquam rerum optio non. Modi quia temporibus dolor voluptatem amet voluptate. Nobis ut numquam rerum adipisci illum.', '1987-08-24 02:07:52'),
(21, 'Mozilla/5.0 (Windows CE; sl-SI; rv:1.9.2.20) Gecko/20160831 Firefox/5.0', 'Voluptatem consequatur voluptatem ut commodi itaque ullam nihil et. Soluta libero asperiores perspiciatis qui vel. Itaque et est est sed. Non minus sit atque. Qui similique amet totam iure.', '1983-08-21 12:28:35'),
(22, 'Opera/9.27 (Windows CE; en-US) Presto/2.9.160 Version/10.00', 'Qui impedit omnis dolore aut iusto facere quod. Quae explicabo sunt non et nesciunt. Cum quo est minima aut.', '2019-06-18 21:13:53'),
(23, 'Opera/8.47 (Windows NT 5.2; sl-SI) Presto/2.9.181 Version/11.00', 'Est eos ipsa quibusdam qui quod esse. Rerum totam est ut accusantium. Incidunt laborum cumque sit quis et.', '2009-07-29 14:38:35'),
(24, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_1 like Mac OS X; en-US) AppleWebKit/532.34.6 (KHTML, like Geck', 'Omnis quia possimus velit veniam dolorum quam. Qui animi veritatis impedit rem reiciendis et. Dolorem ex voluptate assumenda placeat.', '1994-09-09 09:58:39'),
(25, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.0; Trident/4.0)', 'Eligendi inventore sint rerum consequatur. Sunt aperiam velit quis rem. Laborum excepturi quidem dolore architecto.', '1996-02-17 15:00:48'),
(26, 'Opera/9.84 (X11; Linuxi686; sl-SI) Presto/2.9.186 Version/11.00', 'Quia impedit reiciendis eaque at tempora qui praesentium. Quo ut saepe enim aspernatur sed. Aut voluptas quo ipsa quam adipisci non et. Consequatur temporibus et ea aut.', '2016-06-09 12:23:09'),
(27, 'Opera/8.84 (Windows 98; Win 9x 4.90; en-US) Presto/2.9.179 Version/12.00', 'Assumenda id natus expedita ad distinctio ut. Autem repellendus magni eos ab. Tempora sequi et nihil suscipit.', '1972-06-27 13:47:39'),
(29, 'Mozilla/5.0 (Windows NT 5.0; en-US; rv:1.9.0.20) Gecko/20201202 Firefox/3.6.12', 'Eum recusandae omnis autem iure deleniti est. Natus voluptates ducimus similique et possimus cum. Velit ea doloribus voluptatem aut sapiente quo atque.', '2023-10-02 05:53:16'),
(30, 'Mozilla/5.0 (Windows 98; Win 9x 4.90) AppleWebKit/5342 (KHTML, like Gecko) Chrome/15.0.899.0 Safari/', 'Repellat quo inventore qui ea. Ut voluptate alias recusandae molestiae. Ut et animi animi. Molestiae illo maiores harum cupiditate consequatur.', '2006-12-08 05:59:08'),
(31, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5330 (KHTML, like Gecko) Chrome/14.0.831.0 Safari/5330', 'Eveniet odit distinctio rerum atque dolor labore tempora. Eveniet fugit optio perspiciatis totam ut officiis eos.', '1995-04-03 01:02:11'),
(32, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_1 like Mac OS X; en-US) AppleWebKit/532.20.3 (KHTML, like Geck', 'Dolorem optio perspiciatis et et autem nobis reiciendis. Et placeat officiis et sequi omnis. Vel eligendi qui odit ex ut et. Deserunt omnis iure autem.', '1972-02-12 15:25:37'),
(33, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows 98; Trident/5.1)', 'Nihil maxime aspernatur consequatur. Pariatur excepturi necessitatibus aut voluptas aut. Aut et odio quos aliquam sequi aperiam.', '1975-03-11 06:46:19'),
(34, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.2; Trident/5.1)', 'Eveniet minima quos rerum perferendis. Repellendus ipsa aperiam similique minima non quisquam.', '1984-08-02 04:04:49'),
(35, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_8_3 rv:5.0; sl-SI) AppleWebKit/531.28.5 (KHTML, like Gecko) ', 'Dolorem atque quidem dolorum doloribus voluptatem est harum. Voluptate ut qui suscipit fugiat ex. Enim dolorem laudantium cupiditate quia. Ut molestias fugiat quia aliquid ab voluptatibus.', '2019-01-17 21:00:44'),
(36, 'Mozilla/5.0 (X11; Linuxi686; rv:6.0) Gecko/20230716 Firefox/3.6.1', 'Eligendi incidunt vel minima deserunt sunt a est incidunt. Delectus ab qui aliquid modi aliquid hic quo molestiae. Error et eaque sapiente numquam voluptas.', '2004-04-10 10:33:19'),
(37, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_3 like Mac OS X; en-US) AppleWebKit/535.33.5 (KHTML, like Geck', 'Perferendis expedita non omnis deleniti. Rem cupiditate illo libero quos.', '2013-01-12 03:26:29'),
(39, 'Opera/9.13 (X11; Linuxi686; sl-SI) Presto/2.9.170 Version/10.00', 'Corporis in vero velit eum iste enim cumque. Fugit quia perspiciatis saepe aliquid voluptatem quia. In hic porro dicta. Earum illo totam debitis fugit delectus distinctio.', '1972-11-10 07:38:49'),
(40, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows 98; Trident/4.0)', 'Commodi facilis recusandae reiciendis id temporibus et quia. Rerum porro laudantium error dignissimos. Consectetur et earum a quia error doloremque. Sed nostrum occaecati rerum suscipit officiis tempora quia.', '1997-06-07 13:53:24'),
(42, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.1; Trident/4.1)', 'Placeat explicabo eos dignissimos eligendi mollitia. Sed quas deleniti eos beatae. Commodi aliquid nesciunt et aperiam minima. Cupiditate blanditiis eos enim.', '1991-01-06 23:25:46'),
(43, 'Mozilla/5.0 (Windows NT 6.2; en-US; rv:1.9.1.20) Gecko/20181101 Firefox/3.8', 'Vero qui fugiat et doloremque aut soluta. Voluptas autem sit aliquid reiciendis temporibus. Magnam quia autem et. Quia atque et dolor voluptatum.', '1980-06-20 14:02:59'),
(44, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_7_1 rv:6.0) Gecko/20170808 Firefox/3.8', 'Eveniet officia autem ut quia sit. Et iste velit accusantium illo sed fugit nihil porro. Est repudiandae porro repellat voluptatem. Quam et est minima omnis consequatur et.', '2017-02-06 10:00:47'),
(45, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_8_5 rv:2.0; en-US) AppleWebKit/534.36.4 (KHTML, like Gecko) ', 'Quas omnis ullam alias velit voluptatem sit aperiam. Consequatur quasi illo eligendi quod repudiandae voluptates. Officia fugit omnis quibusdam facilis harum. Consequatur sed voluptates voluptates velit ipsa laudantium.', '1997-11-27 04:24:27'),
(46, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_7_5 rv:3.0; sl-SI) AppleWebKit/534.9.6 (KHTML, like Gec', 'Occaecati qui ipsa cupiditate beatae molestias et. Omnis enim aut vel est neque sapiente. Sapiente possimus enim autem aut eos rerum praesentium. Impedit possimus quia iusto.', '2017-11-02 11:02:14'),
(49, 'Mozilla/5.0 (Windows NT 5.1; sl-SI; rv:1.9.2.20) Gecko/20101012 Firefox/3.8', 'Id magnam autem ipsa ea dolor excepturi illo. Quasi quisquam illo et non. Quod rerum vero sint sit.', '1995-03-11 11:13:01'),
(50, 'Opera/8.23 (Windows NT 5.1; sl-SI) Presto/2.9.176 Version/12.00', 'Consectetur sit qui et a omnis. Autem provident veritatis tempora modi consequuntur et. Magnam et et odit pariatur rerum iusto.', '1982-12-07 01:38:20'),
(51, 'Mozilla/5.0 (Windows; U; Windows 95) AppleWebKit/533.47.2 (KHTML, like Gecko) Version/4.0.3 Safari/5', 'Et necessitatibus laudantium distinctio recusandae. Aspernatur qui ratione provident. Aspernatur eum autem hic et. Maxime sed assumenda quia cum.', '1979-07-12 16:01:17'),
(52, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows 98; Win 9x 4.90; Trident/4.0)', 'Quos incidunt assumenda sed ratione labore et alias qui. Eaque soluta repudiandae consequatur culpa quia et et itaque. Earum ipsa deleniti aut ad velit natus id quae. Aliquam et nihil recusandae quasi vero. Placeat consequuntur consequatur deserunt totam repellendus quaerat.', '2008-02-15 12:38:45'),
(53, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.2; Trident/3.0)', 'Autem voluptas reprehenderit sapiente ipsa illum ab labore. Sequi ut quam odio ad magnam libero quos. Officiis suscipit ducimus minima ad.', '1977-05-31 15:24:06'),
(56, 'Mozilla/5.0 (Windows NT 4.0; en-US; rv:1.9.0.20) Gecko/20120812 Firefox/8.0', 'Et nemo voluptate perferendis sit enim. Fugit molestiae culpa facere omnis. Sed enim dolorum recusandae. Vel dicta amet expedita similique distinctio sit.', '1995-03-18 12:12:13'),
(57, 'Mozilla/5.0 (Windows NT 5.1; en-US; rv:1.9.1.20) Gecko/20210117 Firefox/3.6.20', 'Sed corporis aut nam deserunt quod. Sed iste distinctio iusto qui. Voluptatem numquam incidunt ut et qui molestias sint. Molestiae ut quis quidem minus aspernatur repellat. Enim consequuntur error quia et dolorem.', '2014-08-27 06:59:02'),
(58, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_6_1 rv:5.0) Gecko/20130324 Firefox/8.0', 'Illum numquam repellendus id perferendis. Architecto repellat sint quas ea voluptate nobis assumenda quo. Nihil suscipit laborum non consequatur ea. Officiis eligendi saepe nisi sapiente non unde.', '1997-06-11 21:55:20'),
(61, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_6_7 rv:5.0) Gecko/20120111 Firefox/4.0', 'Et ipsam inventore recusandae et id numquam et sint. Sit ducimus alias quo saepe labore. Nulla quaerat eos consequatur in magni ab excepturi fuga.', '2016-12-23 14:55:28'),
(62, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_8_8 rv:6.0; en-US) AppleWebKit/535.40.1 (KHTML, like Geck', 'Et quis sit corporis cumque est. Saepe tempore nihil voluptate sequi. Dolorem atque et officia veritatis quia et.', '1973-01-08 02:13:21'),
(65, 'Mozilla/5.0 (Windows CE) AppleWebKit/5322 (KHTML, like Gecko) Chrome/13.0.801.0 Safari/5322', 'Velit natus velit omnis libero alias. Modi delectus odio est asperiores accusamus qui. Repudiandae aut possimus aut quia labore eos est. Et delectus aut vitae eveniet mollitia eaque labore.', '1978-06-17 07:50:39'),
(66, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_2 like Mac OS X; sl-SI) AppleWebKit/531.39.3 (KHTML, like Geck', 'Explicabo maxime debitis ullam sequi officiis molestiae debitis. Sunt veniam illum ratione earum ducimus doloremque fuga non. Alias dolore ratione ea hic. Possimus ut repellendus et maxime inventore dolorem cupiditate.', '1993-12-31 23:23:12'),
(67, 'Opera/9.28 (Windows 98; en-US) Presto/2.9.166 Version/11.00', 'In autem facilis nihil dicta. Quo illum voluptatum consequuntur. Aspernatur tempore quia earum explicabo. Fuga pariatur natus ut deserunt perferendis iste autem veritatis.', '1996-09-19 07:09:28'),
(68, 'Opera/8.43 (X11; Linuxi686; sl-SI) Presto/2.9.188 Version/12.00', 'Ut dicta quisquam illo beatae. Excepturi quia sint vero natus nihil. Et inventore ipsam ipsa perspiciatis. Consequatur eveniet beatae et tenetur tempora quibusdam dicta.', '2005-05-07 16:18:44'),
(69, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_3 like Mac OS X; en-US) AppleWebKit/531.36.4 (KHTML, like Geck', 'Rerum reiciendis velit quidem exercitationem mollitia rem. Recusandae id corrupti reprehenderit molestiae omnis adipisci blanditiis labore. Ut voluptas nisi non ipsam tempore.', '2024-07-20 16:53:41'),
(70, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows CE; Trident/4.1)', 'Tempore laboriosam natus rem assumenda. Enim tempore et quaerat. Nihil rerum beatae quae incidunt voluptas aspernatur. Beatae accusamus iure et ab at vero.', '2018-01-03 11:46:49'),
(71, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_1 like Mac OS X; sl-SI) AppleWebKit/535.50.7 (KHTML, like Geck', 'Minima voluptatum ut et eaque. Quod tempora debitis voluptatem explicabo quasi soluta est. Et expedita esse illum rerum sed. Odio sit quibusdam rerum commodi quo et.', '1995-03-04 11:53:30'),
(72, 'Mozilla/5.0 (Windows 98; Win 9x 4.90) AppleWebKit/5342 (KHTML, like Gecko) Chrome/15.0.834.0 Safari/', 'Accusantium natus quam cumque autem libero. Ut maxime quaerat in pariatur aut enim. Velit enim enim vero ut porro.', '2023-07-06 08:16:10'),
(74, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_6 rv:4.0) Gecko/20160114 Firefox/3.8', 'Aut totam minus molestiae. Sapiente sequi assumenda accusamus rerum et.', '1977-05-10 06:19:08'),
(75, 'Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/532.43.7 (KHTML, like Gecko) Version/5.1 Safari', 'Ea minima et ipsum rerum. Nemo sed omnis soluta fugiat cum incidunt mollitia. Dolorem quaerat voluptatem quasi temporibus vitae sit. Occaecati ut aliquam vel architecto aut. Qui quis odio aut velit ad.', '1970-07-12 14:56:19'),
(76, 'Mozilla/5.0 (Windows NT 5.0; en-US; rv:1.9.2.20) Gecko/20230302 Firefox/11.0', 'Repellendus quia qui culpa non distinctio. Nihil rerum est est. Tenetur alias quibusdam molestias nihil sed ut. Non repellendus blanditiis vel dolores consequatur.', '1979-05-24 22:14:52'),
(77, 'Opera/9.70 (X11; Linuxx86_64; sl-SI) Presto/2.9.188 Version/10.00', 'Quibusdam sint nihil nam reiciendis. Vel dolores voluptates accusantium eum. Nesciunt et non aliquid modi commodi aut consequatur est.', '1974-10-01 02:25:20'),
(78, 'Mozilla/5.0 (Windows 95; en-US; rv:1.9.0.20) Gecko/20121011 Firefox/3.8', 'Eos a fugiat quos dolores ea. Similique sit totam et. Eveniet reprehenderit quis nulla. A soluta vitae alias rerum ut molestias.', '1973-11-30 15:06:12'),
(79, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7 rv:4.0) Gecko/20220629 Firefox/3.8', 'Aliquid rerum placeat autem in non cumque incidunt. Voluptates praesentium necessitatibus temporibus nemo et. Consectetur aut architecto maiores soluta earum quisquam. Id aut natus quaerat harum laboriosam. Tempora architecto praesentium voluptates omnis omnis.', '2008-04-29 14:15:31'),
(80, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/5340 (KHTML, like Gecko) Chrome/14.0.895.0 Safari/5340', 'Est repellat nisi aut voluptatem impedit. Doloremque qui modi sed labore nisi. Amet rerum velit sit doloribus est eos odit qui. Dolore vitae labore beatae quibusdam ut.', '2011-01-20 10:37:34'),
(82, 'Mozilla/5.0 (X11; Linuxx86_64; rv:7.0) Gecko/20210729 Firefox/3.6.4', 'Minima harum et aperiam. Soluta ut consequatur perspiciatis esse et. Dolorem ea omnis dolor praesentium quas ipsam amet. Omnis numquam ut ducimus sunt dolor.', '1970-04-21 11:04:30'),
(83, 'Opera/8.86 (Windows NT 6.2; en-US) Presto/2.9.186 Version/10.00', 'Ut modi qui est beatae quia nihil repellendus. Non quia sunt rerum officia. Voluptas libero ullam illo.', '2011-02-06 20:39:58'),
(84, 'Mozilla/5.0 (Windows; U; Windows NT 5.01) AppleWebKit/534.32.5 (KHTML, like Gecko) Version/4.0.5 Saf', 'Consequatur totam maxime rerum nostrum. Sed voluptatem ipsam natus qui quae. Vitae officia possimus eum architecto quae sunt. Id dolores est fuga molestias eius.', '2004-01-04 00:44:29'),
(86, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7 rv:6.0; en-US) AppleWebKit/534.46.5 (KHTML, like Gecko', 'Temporibus debitis repellat quos quae facere. Qui ut similique facere. Nemo incidunt dolorem veritatis est. Id sit voluptatem numquam dolorem ea ratione.', '1977-11-27 02:27:25'),
(87, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_1) AppleWebKit/5331 (KHTML, like Gecko) Chrome/14.0.823.', 'Non veniam totam consequuntur ut quos explicabo. Recusandae dolor fugiat numquam tempore excepturi animi culpa nam. Rerum vero et enim aliquid est.', '1994-12-03 12:09:14'),
(88, 'Opera/9.55 (Windows NT 4.0; sl-SI) Presto/2.9.187 Version/11.00', 'Et eligendi similique ut. Sit eum qui nesciunt sunt. Qui voluptas recusandae iusto aut sequi voluptas.', '1977-03-04 13:23:22'),
(89, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_8_2) AppleWebKit/5322 (KHTML, like Gecko) Chrome/14.0.8', 'Voluptate aut nam officiis iste cumque. Cumque distinctio rerum at adipisci sint pariatur. Voluptatem non aspernatur placeat eius odio. Minima impedit repellat doloribus laboriosam doloribus.', '2011-08-28 22:21:13'),
(91, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 4.0; Trident/3.0)', 'Assumenda sint nesciunt nihil natus corrupti quod commodi. Aut ratione qui praesentium hic. Accusantium molestias et voluptas veritatis occaecati possimus omnis. Quaerat omnis reiciendis quia.', '2023-01-10 14:34:27'),
(92, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_0 like Mac OS X; sl-SI) AppleWebKit/532.26.2 (KHTML, like Geck', 'Quis in accusamus illo ratione voluptatum tempora quis. Nam voluptatem repellendus et nostrum. Tenetur quo tenetur nihil aspernatur. Veniam alias dolores sequi odit. Unde eum laboriosam perferendis.', '2007-09-26 17:04:29'),
(93, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_2 like Mac OS X; sl-SI) AppleWebKit/534.42.7 (KHTML, like Geck', 'Nisi autem ut quasi sapiente eum magni porro. Quas qui non vel doloribus fugit rerum voluptates. Veritatis quisquam animi quia.', '2007-01-03 02:15:06'),
(94, 'Opera/9.84 (Windows NT 5.2; sl-SI) Presto/2.9.179 Version/12.00', 'Est itaque assumenda magni aut. Commodi quia incidunt laudantium inventore vitae. Qui maiores velit animi non possimus vel. Tempore consequuntur amet omnis dignissimos aut labore.', '2014-04-08 00:06:48'),
(95, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5321 (KHTML, like Gecko) Chrome/14.0.875.0 Safari/5321', 'Occaecati ea voluptatibus fugiat dolorem esse. Cupiditate modi totam aut facere.', '2005-08-07 00:01:04'),
(96, 'Opera/8.30 (Windows CE; en-US) Presto/2.9.179 Version/10.00', 'Aut quos dolorem libero sed perferendis distinctio delectus aspernatur. Consequuntur nostrum accusantium quisquam eum veniam. Fugit omnis vero ducimus debitis atque laborum assumenda. Occaecati necessitatibus cum assumenda consequuntur illo ea aut.', '1993-07-09 04:38:24'),
(97, 'Opera/8.20 (X11; Linuxx86_64; sl-SI) Presto/2.9.174 Version/10.00', 'Quis aut consequatur autem et minus in qui. Optio explicabo omnis non alias. Quia neque voluptates sunt eum maxime. Ut inventore qui eum totam amet aut. Cupiditate aliquam quia molestiae doloribus id a nostrum.', '1994-05-14 05:03:11'),
(98, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_1 like Mac OS X; en-US) AppleWebKit/534.40.6 (KHTML, like Geck', 'Et sint neque modi aut aliquam voluptas laborum. Debitis doloremque id vitae est tempore reiciendis. Voluptate debitis repellat quisquam itaque aspernatur.', '2002-02-14 11:52:25'),
(99, 'Opera/8.84 (X11; Linuxx86_64; en-US) Presto/2.9.162 Version/10.00', 'Quos veniam deserunt saepe ut quisquam. Voluptate soluta facilis soluta esse. Aut veniam fugit explicabo corrupti consequatur enim aut.', '2018-02-28 10:51:18'),
(101, 'Mozilla/5.0 (Windows NT 6.0; sl-SI; rv:1.9.0.20) Gecko/20211001 Firefox/3.6.15', 'Beatae eum dignissimos voluptas reiciendis corrupti qui sapiente quasi. Molestias repudiandae inventore non sint consequuntur illo accusamus. Qui non et quia et consequuntur in. Distinctio ullam quod culpa consequatur iusto.', '2014-11-24 15:20:26'),
(109, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.01; Trident/3.1)', 'Amet et et at optio nostrum. Odit ex qui aut odio autem et. Odit tempora reprehenderit modi pariatur. Quia tempora adipisci voluptatibus harum quas ab molestiae.', '2011-03-04 21:52:10'),
(116, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.1)', 'Consequatur eius minus et quaerat molestiae. Enim quidem officiis ipsa voluptas. Illum aspernatur eum explicabo. Aut tempore eum suscipit quod aut vitae molestias.', '1986-10-10 09:50:44'),
(119, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.2; Trident/5.1)', 'Enim voluptas consequatur explicabo quidem. Deleniti a qui a consequuntur nemo adipisci ut. Quia quam blanditiis dignissimos temporibus quisquam.', '1974-06-27 20:53:06'),
(136, 'Mozilla/5.0 (Windows NT 6.2; sl-SI; rv:1.9.2.20) Gecko/20180107 Firefox/13.0', 'Consequatur laudantium suscipit veritatis. Voluptatem commodi corporis voluptates eum natus. Atque voluptatem saepe iste officia voluptatibus explicabo. Ratione cum unde esse ratione.', '1976-12-24 12:45:47'),
(137, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows CE; Trident/5.1)', 'Dolorem eius quo et ea velit. Aut non rerum natus sit ea ea nesciunt. Et necessitatibus rerum recusandae architecto est. Sint ut quis non expedita. Fuga aliquam numquam animi mollitia repudiandae ex dignissimos.', '1980-02-19 14:13:31'),
(140, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5362 (KHTML, like Gecko) Chrome/14.0.896.0 Safari/5362', 'Nulla delectus delectus eos et eum eligendi est. Ut iusto odit tempora. Reprehenderit distinctio doloremque non esse est. Eos est et dolorum qui alias sed non.', '1993-03-13 01:10:02'),
(159, 'Mozilla/5.0 (Windows NT 6.0; sl-SI; rv:1.9.0.20) Gecko/20191206 Firefox/15.0', 'Necessitatibus iste repellendus blanditiis et. Voluptas voluptatem cumque impedit sit. Quasi omnis dolore est repellat voluptas molestiae itaque. Sequi culpa omnis exercitationem neque in et est.', '1987-11-13 11:03:13'),
(160, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5320 (KHTML, like Gecko) Chrome/14.0.848.0 Safari/5320', 'Dicta mollitia magni qui recusandae. Ducimus maxime voluptas ullam officia sed asperiores. Facere labore quo ex odit ut libero quis.', '2016-07-27 00:08:43'),
(162, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_6_2 rv:6.0; sl-SI) AppleWebKit/534.23.4 (KHTML, like Geck', 'Dolores incidunt sint quaerat corrupti ipsa. Sit nulla earum explicabo. Aut aut et occaecati at necessitatibus. Non et dolorem neque cumque sint quia.', '2019-01-19 01:42:25'),
(168, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_2 like Mac OS X; en-US) AppleWebKit/531.27.7 (KHTML, like Geck', 'Autem alias at mollitia. Commodi quo est voluptas ducimus provident asperiores. Blanditiis accusamus eos dolores eaque. Odio quos rerum molestias ut non illum aut placeat.', '1974-02-18 08:00:38'),
(177, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.0; Trident/4.1)', 'Quaerat et et eos ipsa at laborum. Temporibus sapiente et delectus quia ea consequuntur. Ex in rerum unde dolorum voluptate ea asperiores corporis. Amet recusandae non quibusdam officia et pariatur.', '1983-03-10 09:42:55'),
(182, 'Opera/9.51 (Windows 98; Win 9x 4.90; sl-SI) Presto/2.9.180 Version/12.00', 'Totam commodi itaque praesentium et velit facilis. Officia et ea ea quam reprehenderit. Ea et sint eveniet ut atque doloremque.', '1979-03-10 21:51:16'),
(187, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_8_3) AppleWebKit/5330 (KHTML, like Gecko) Chrome/14.0.8', 'Est vel veniam et ab. Earum minus quasi qui temporibus qui est illo. Aut voluptatem ratione repellat excepturi a id.', '1994-09-06 13:10:14'),
(190, 'Mozilla/5.0 (X11; Linuxi686; rv:5.0) Gecko/20190920 Firefox/3.8', 'Dolores deserunt quidem modi nihil inventore. Autem voluptate eveniet quo qui consequatur a sit. Tenetur accusamus sint impedit. Iusto corporis qui vel officiis quaerat error minus. Minus totam incidunt rerum possimus.', '1991-10-31 01:52:26'),
(197, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5321 (KHTML, like Gecko) Chrome/13.0.822.0 Safari/5321', 'Velit fuga omnis dolores provident. Quibusdam in doloremque voluptas ab corporis assumenda. Velit rerum maxime atque animi a iusto aspernatur.', '1991-01-31 16:46:48'),
(199, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 5.0; Trident/3.0)', 'Ut nihil beatae a mollitia. Maxime vero eos quia alias deserunt nihil. Vel aut delectus aspernatur ut tempore perferendis est.', '2006-03-16 06:53:07'),
(341, 'Opera/9.19 (Windows NT 4.0; en-US) Presto/2.9.185 Version/12.00', 'Aliquam minus sit minima explicabo vel. Consequatur consequatur assumenda quibusdam enim. Aut sint quam voluptatem sed. Veniam enim autem aut voluptas. Iure sint ex molestiae sunt quis.', '2000-02-16 09:11:40'),
(344, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_9) AppleWebKit/5352 (KHTML, like Gecko) Chrome/14.0.8', 'Sapiente omnis ratione quis possimus. Dolor suscipit sint sed officiis hic suscipit id. Nostrum enim molestiae maiores voluptate. In sed voluptas mollitia labore.', '2022-07-22 21:36:24'),
(347, 'Mozilla/5.0 (Windows NT 5.2; en-US; rv:1.9.2.20) Gecko/20161017 Firefox/15.0', 'Voluptas rerum rerum aliquam exercitationem. Nihil et voluptatem assumenda nulla in tenetur dolorem. Optio asperiores laudantium qui amet quas inventore voluptatum. Iusto sed ut exercitationem quisquam molestiae et accusantium.', '1990-05-02 15:15:44'),
(356, 'Mozilla/5.0 (X11; Linuxi686; rv:6.0) Gecko/20200311 Firefox/3.6.16', 'Maiores aut id eligendi quo autem magnam. Quod qui quia in sunt non corrupti.', '1992-05-09 01:53:57'),
(359, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_1 rv:4.0; sl-SI) AppleWebKit/531.50.6 (KHTML, like Gecko', 'Eligendi reiciendis delectus dicta iusto corrupti ipsam. Est tempore eum soluta assumenda velit voluptatem quod.', '2023-02-21 10:56:42'),
(367, 'Opera/8.53 (Windows 98; sl-SI) Presto/2.9.163 Version/12.00', 'Commodi omnis dolorum facilis voluptatem magnam molestias. Exercitationem suscipit veritatis explicabo optio ut. Eius adipisci sed velit amet vel. Labore porro laborum ipsam mollitia provident quis ad placeat.', '2025-02-23 18:44:01'),
(375, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/5340 (KHTML, like Gecko) Chrome/13.0.858.0 Safari/5340', 'Non magnam facere tenetur qui autem. Perferendis dolores sequi praesentium. Deleniti amet facere voluptatum corporis ad optio.', '1972-05-20 13:23:18'),
(383, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.2; Trident/5.1)', 'Ut voluptatem quam qui. Debitis sit qui totam asperiores eos quas perspiciatis non. Rerum aut non minus facilis voluptas minima.', '2002-05-29 00:34:41'),
(393, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_8_3 rv:4.0) Gecko/20101210 Firefox/3.6.6', 'Neque commodi labore magnam aut et dolorem. Hic velit qui rerum eos earum minima possimus eum. Veritatis id nihil nostrum non qui hic vitae.', '2021-04-07 11:43:40'),
(397, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 6.0; Trident/5.1)', 'Iure ea atque aut magnam quam dolores ad. Et porro aliquam quaerat quos aut temporibus doloribus voluptas. Similique aperiam laboriosam soluta et dolorem optio omnis.', '2011-10-12 06:55:24'),
(401, 'Opera/8.67 (Windows NT 5.2; sl-SI) Presto/2.9.184 Version/11.00', 'Mollitia hic suscipit vitae qui magnam. Est a et voluptatem placeat. Odio recusandae ut maiores voluptatem ut. Cupiditate et voluptatem quae suscipit eligendi rerum perspiciatis.', '1973-01-22 19:09:31'),
(403, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5360 (KHTML, like Gecko) Chrome/14.0.884.0 Safari/5360', 'Nam qui rerum eius dolorem. Nesciunt et est et modi cum libero ipsum. Eveniet in nostrum in dolorum porro velit voluptatem. Cupiditate expedita eum debitis hic.', '1974-05-17 18:04:21'),
(419, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_6_1 rv:4.0) Gecko/20150909 Firefox/3.8', 'Sed accusamus pariatur dolore modi. Quia et asperiores et voluptates ducimus. Et ut eum odit pariatur iure dolorum tenetur.', '2003-12-25 20:42:54'),
(435, 'Opera/8.21 (X11; Linuxx86_64; en-US) Presto/2.9.185 Version/11.00', 'Facere iure facilis facilis quos accusantium. Iure vel ducimus doloribus labore voluptatibus voluptatem mollitia. Totam id itaque autem consequatur repudiandae officiis. Et tenetur eos et culpa amet.', '1973-10-08 06:27:14'),
(436, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_1 like Mac OS X; en-US) AppleWebKit/531.33.2 (KHTML, like Geck', 'Consequatur ducimus repellat deserunt dignissimos. Molestias ducimus temporibus quia totam non odit. Quos et earum minima quod maiores cumque itaque. Quod omnis debitis et ipsam in.', '1992-05-25 05:34:05'),
(454, 'Opera/9.99 (X11; Linuxi686; en-US) Presto/2.9.162 Version/11.00', 'Ut non dolorum quasi libero velit itaque aut. Et atque exercitationem quisquam voluptas ea. Aspernatur voluptatem dicta aliquam quae quo aut quae provident. Dicta qui in esse sunt dolorem est magnam.', '1970-08-09 18:17:35'),
(459, 'Opera/9.18 (Windows NT 6.1; en-US) Presto/2.9.180 Version/11.00', 'Provident cumque possimus aliquam pariatur autem non pariatur iste. Iure consectetur aut id expedita et. Repudiandae consequuntur consequatur est quod eum aut.', '1995-12-31 20:29:25'),
(464, 'Opera/9.83 (Windows NT 6.0; sl-SI) Presto/2.9.169 Version/10.00', 'Voluptas quam dolore id laborum mollitia. Quis quia amet veniam quo ea laudantium quis dolorum. Minima ut vero quis et. Perferendis dolore mollitia omnis.', '1988-11-15 10:31:58'),
(468, 'Opera/8.85 (X11; Linuxx86_64; en-US) Presto/2.9.174 Version/10.00', 'Aut accusantium eos velit expedita similique temporibus. Velit et sed veritatis quas aut molestias quibusdam nihil. Corporis reiciendis ex mollitia tempore expedita ducimus. Sit possimus voluptatem et nihil.', '2000-01-25 12:12:52'),
(469, 'Opera/9.94 (Windows NT 5.2; sl-SI) Presto/2.9.183 Version/12.00', 'Perferendis temporibus modi sint quis placeat voluptas ut. Vero consequatur labore consequatur quia. Ut et porro voluptas est.', '1989-01-24 15:19:45'),
(479, 'Opera/8.72 (Windows NT 6.2; sl-SI) Presto/2.9.180 Version/12.00', 'Ut tempore incidunt eos rerum. Consequatur velit architecto dolores. Totam error quisquam a at.', '1976-03-29 14:13:07'),
(493, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.2; Trident/3.1)', 'Pariatur quia consequatur asperiores optio rem aut. Possimus numquam nobis magni eum aspernatur et enim. Sit omnis maxime provident doloremque.', '1999-12-02 20:23:18'),
(494, 'Mozilla/5.0 (Windows; U; Windows CE) AppleWebKit/535.16.1 (KHTML, like Gecko) Version/5.0 Safari/535', 'Animi alias saepe quas minima esse quaerat. Perspiciatis eum eos sed eum consequatur. Molestiae adipisci voluptatum cumque nihil temporibus aut.', '1982-07-10 00:50:31'),
(495, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows CE; Trident/5.0)', 'Et inventore animi dolorum dolores et quam sequi. Rerum dolores accusamus ipsam est voluptas. Non et totam maiores iure occaecati veritatis.', '1996-02-23 16:04:31'),
(527, 'Mozilla/5.0 (Windows; U; Windows NT 4.0) AppleWebKit/535.15.7 (KHTML, like Gecko) Version/5.0 Safari', 'Explicabo repudiandae consequatur aut. Architecto dolore voluptatem molestias aut mollitia. Asperiores rerum qui esse in natus in id. Odit eos ducimus qui possimus mollitia quia.', '2023-12-13 13:17:22'),
(533, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 5.2; Trident/3.0)', 'Distinctio et magnam laudantium temporibus in doloremque. Qui omnis molestias rerum ipsa.', '1994-11-22 11:26:20'),
(546, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_7_7 rv:3.0; en-US) AppleWebKit/532.23.7 (KHTML, like Gecko) ', 'Repellendus sint iure saepe perferendis doloribus perspiciatis corporis. Voluptatum sunt dicta quisquam ea quidem. Enim ipsum quo minima molestiae tempore. Eaque reprehenderit est accusamus.', '1977-08-24 01:27:32'),
(577, 'Mozilla/5.0 (X11; Linuxi686; rv:5.0) Gecko/20240518 Firefox/3.6.15', 'Et et quo ut beatae qui voluptas. Voluptas est nesciunt voluptatibus aut aut.', '2023-11-23 09:32:43'),
(579, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_8 rv:3.0; en-US) AppleWebKit/532.25.7 (KHTML, like Ge', 'Dolores dolor quibusdam itaque minus natus. Sunt illum voluptas labore laborum eius ipsa aspernatur. Porro aut reprehenderit cumque voluptates. Consequatur consequatur dolorem quia corrupti ut dolores laudantium.', '2002-07-03 22:19:01'),
(584, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.0; Trident/3.1)', 'Animi ea possimus culpa unde eum. Debitis odit aliquam ullam laborum quas doloremque et. Ut atque nihil corporis possimus amet veniam eveniet. Dignissimos nihil quod illum.', '1990-12-27 23:54:27'),
(601, 'Mozilla/5.0 (X11; Linuxx86_64; rv:7.0) Gecko/20210322 Firefox/3.6.8', 'Vel enim qui et velit voluptas pariatur. Eum eligendi dolorem eius. Rerum laudantium consequatur et voluptas.', '1982-10-19 18:40:05'),
(606, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.01; Trident/3.0)', 'Fugiat numquam dicta non in in totam animi. Dolorum facilis nulla qui non qui ullam nobis. Et animi occaecati et molestiae alias. Corporis aut cupiditate dignissimos deleniti natus fugiat.', '2007-09-19 20:28:23'),
(623, 'Mozilla/5.0 (Windows; U; Windows NT 5.01) AppleWebKit/535.4.1 (KHTML, like Gecko) Version/5.1 Safari', 'Omnis doloremque aut illum rem tempore in id laborum. Est dicta cupiditate non iusto. Commodi in explicabo ipsum repellat.', '1985-09-27 16:27:05'),
(624, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows 95; Trident/3.1)', 'Quis eaque autem numquam atque. Dolores non voluptas error nesciunt totam velit sequi. Unde fuga ullam ex qui at quia. Ipsum porro molestias aut cupiditate eligendi consectetur iste.', '2013-06-03 20:17:09'),
(627, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_5_7 rv:5.0) Gecko/20160918 Firefox/3.8', 'Qui perferendis vero voluptas labore voluptas. Deleniti ipsum voluptas illo aspernatur.', '2004-10-07 14:18:03'),
(629, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_5_6 rv:2.0; en-US) AppleWebKit/533.32.4 (KHTML, like Geck', 'Fugiat error magni possimus sunt quae unde. Ut consequuntur rem veritatis rerum amet qui perferendis. Facilis harum qui ab hic. Possimus aut distinctio enim est. Voluptatem qui quia et perspiciatis libero dolorem.', '2002-04-30 02:18:37'),
(633, 'Mozilla/5.0 (X11; Linuxx86_64; rv:6.0) Gecko/20210301 Firefox/3.6.4', 'Ut molestiae voluptatem esse velit nobis nemo et. Ut ea voluptatem dolore impedit est dolores. Vero aut accusantium repellendus impedit. Qui nobis aut perspiciatis odio ab ex.', '1983-09-04 04:39:49'),
(640, 'Opera/9.81 (Windows 98; Win 9x 4.90; sl-SI) Presto/2.9.175 Version/10.00', 'Error quia voluptates magni sit possimus maiores iste. Dolorum sint et quos dolore. Error voluptatem ut autem nemo.', '1970-07-21 08:00:17'),
(649, 'Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/534.21.3 (KHTML, like Gecko) Version/5.0 Safari', 'Voluptas voluptatem dolor consequatur voluptate perspiciatis. Saepe distinctio at similique. Autem in sint quos enim.', '2023-12-27 16:32:04'),
(654, 'Mozilla/5.0 (Windows 98; en-US; rv:1.9.0.20) Gecko/20210629 Firefox/3.8', 'Expedita deserunt aliquid enim ipsum in. Excepturi labore ut reiciendis quibusdam tenetur.', '2008-07-01 18:06:15'),
(658, 'Mozilla/5.0 (Windows; U; Windows CE) AppleWebKit/534.13.4 (KHTML, like Gecko) Version/5.1 Safari/534', 'Dolorem unde deserunt asperiores maiores eveniet et. Consequuntur esse fugit inventore sit ea accusamus ut asperiores. In voluptates perspiciatis veritatis assumenda. Autem rem tempora necessitatibus recusandae facilis aliquid quaerat natus.', '1981-10-04 17:45:10'),
(662, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 4.0; Trident/5.1)', 'Est illo consequuntur laborum enim aut. Eum iusto voluptas culpa numquam sunt necessitatibus. Suscipit voluptas omnis non libero id quia maxime. Vel unde sint qui velit fuga neque. Ab iusto iure earum delectus molestiae dolore est corporis.', '2010-11-20 16:42:02'),
(666, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_8_2 rv:4.0) Gecko/20170514 Firefox/3.8', 'Aliquam molestiae occaecati consequuntur ratione. Quibusdam repudiandae laborum necessitatibus. Enim omnis ut deserunt.', '2014-04-29 11:19:45'),
(670, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_0 like Mac OS X; sl-SI) AppleWebKit/534.18.6 (KHTML, like Geck', 'Adipisci cumque dolorem velit excepturi cumque suscipit accusamus. Vero voluptatem sed molestiae porro consequatur. Voluptatem consequatur qui debitis ipsa. Ipsum qui voluptatem et iste enim error.', '1985-07-14 05:01:40'),
(701, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_8_8 rv:2.0; en-US) AppleWebKit/535.48.1 (KHTML, like Ge', 'Ut ut laboriosam sed laborum est aut. Accusantium sit eaque ea et repellat cupiditate nisi. Dolore accusantium itaque et quia quae.', '2025-04-29 17:04:23'),
(702, 'Mozilla/5.0 (Windows NT 5.01) AppleWebKit/5362 (KHTML, like Gecko) Chrome/14.0.857.0 Safari/5362', 'Facilis corporis aspernatur numquam numquam. Illo est ut voluptate consequatur deserunt natus. Maxime quia quod quidem aspernatur quo nulla fugiat.', '2024-12-08 09:30:51'),
(706, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_5_5) AppleWebKit/5312 (KHTML, like Gecko) Chrome/15.0.853.0 ', 'Et maiores minus nulla quis. Impedit deserunt rerum sit omnis quae. Voluptatem vero quibusdam mollitia facere omnis.', '1982-04-11 09:49:33'),
(708, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_7 rv:4.0) Gecko/20240505 Firefox/9.0', 'Consequatur magnam provident dignissimos cumque magnam. Sequi reprehenderit quis non nihil. Dolore et est incidunt voluptas amet hic ipsam.', '2021-02-17 20:15:29'),
(709, 'Mozilla/5.0 (Windows NT 5.01) AppleWebKit/5340 (KHTML, like Gecko) Chrome/14.0.841.0 Safari/5340', 'Molestiae velit quod nesciunt nulla totam enim. Earum est doloremque dolores et culpa. Incidunt excepturi qui nisi cupiditate deleniti. Sint dolores sed aut similique sit tempore autem.', '2010-09-16 11:47:13'),
(712, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_0 rv:5.0; en-US) AppleWebKit/533.6.3 (KHTML, like Gecko)', 'Reprehenderit laboriosam sapiente laborum sit. Facere et dolorum vel exercitationem saepe distinctio.', '1973-01-10 11:30:18'),
(716, 'Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/534.24.1 (KHTML, like Gecko) Version/4.0.2 Safa', 'Officia odit et reiciendis amet quia harum. Nobis aperiam ex non ea. Nihil facere deleniti aut explicabo odio reprehenderit.', '1995-02-21 20:37:12'),
(724, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_7_7) AppleWebKit/5330 (KHTML, like Gecko) Chrome/14.0.877', 'Placeat aspernatur repellat qui earum esse dolor. Reiciendis qui pariatur temporibus. Consectetur doloremque minima maiores voluptatum temporibus eveniet delectus.', '1993-05-31 14:14:33'),
(726, 'Opera/9.16 (Windows NT 5.2; en-US) Presto/2.9.188 Version/11.00', 'Facere eligendi et eos quae. Et ut accusamus ea vitae eligendi tempore sit.', '2003-04-29 03:53:39'),
(729, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5330 (KHTML, like Gecko) Chrome/14.0.846.0 Safari/5330', 'Quidem impedit culpa totam ut. Eveniet recusandae vitae qui sed. Aut facilis quos aliquid placeat.', '2023-01-21 04:23:35'),
(734, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_7_9 rv:5.0; sl-SI) AppleWebKit/533.34.1 (KHTML, like Geck', 'Voluptatibus ut quisquam esse. Fugit similique nisi est sed odio dolores. Maiores adipisci molestiae possimus perspiciatis et.', '1990-10-11 11:10:11'),
(740, 'Mozilla/5.0 (Windows 98; Win 9x 4.90; sl-SI; rv:1.9.1.20) Gecko/20100916 Firefox/3.8', 'Ipsam ea ullam sunt ut eligendi nemo suscipit. Dolor est et nesciunt dolores ducimus illum quia. Sunt dolorem nobis hic aspernatur laboriosam placeat sint ut. Atque et numquam tempora quis at. Excepturi enim dolor dolor temporibus voluptatem eum.', '1989-03-02 15:30:13'),
(743, 'Mozilla/5.0 (Windows 95; sl-SI; rv:1.9.2.20) Gecko/20170722 Firefox/3.6.18', 'Officia minima illum in et. Deserunt mollitia reprehenderit voluptatum. Dolor id harum reprehenderit neque quo. Accusamus aut numquam et quia facilis repudiandae consequatur eos.', '1970-08-09 05:40:05'),
(756, 'Mozilla/5.0 (X11; Linuxx86_64; rv:5.0) Gecko/20171016 Firefox/3.8', 'Quis iusto non laborum quis ducimus error atque. Ex autem id dolorem voluptas iure voluptatibus. Inventore ullam tempore quos ut harum et. Deleniti dolor vero molestiae laborum vitae.', '1984-12-17 20:38:47'),
(762, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.2; Trident/5.1)', 'Soluta voluptatem dicta qui cum incidunt est. Neque eius corrupti expedita incidunt vel. Qui quia quia sequi asperiores possimus dolores.', '1986-12-14 21:03:54'),
(768, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5362 (KHTML, like Gecko) Chrome/15.0.834.0 Safari/5362', 'Unde ex reprehenderit voluptatem ut dolore et. Et porro error minima tempora explicabo voluptate amet eveniet. Sunt necessitatibus odio commodi odit libero qui labore. Fugit dolorum quos occaecati voluptatibus in corporis sint.', '2015-04-29 22:21:35'),
(804, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_7_3) AppleWebKit/5331 (KHTML, like Gecko) Chrome/15.0.8', 'Facere veritatis facilis sed accusamus illum laboriosam. Aliquid nostrum non animi commodi temporibus rerum. Neque labore error corrupti.', '1985-07-09 06:36:28'),
(806, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5311 (KHTML, like Gecko) Chrome/15.0.882.0 Safari/5311', 'Nesciunt nemo id corporis architecto repellendus consequatur dolores. Sint cumque exercitationem perferendis magnam quidem praesentium sunt ipsum. Commodi cumque quisquam iure corrupti rerum necessitatibus expedita. Accusamus ab quidem voluptatibus ut commodi culpa.', '1973-07-03 01:16:03'),
(814, 'Mozilla/5.0 (X11; Linuxx86_64; rv:6.0) Gecko/20250429 Firefox/3.8', 'Asperiores possimus labore non. Dolor nulla aspernatur nobis aut ut non. Quibusdam vel consequatur libero dolores aliquid temporibus. Ad dolorum mollitia nesciunt. Similique veniam odio praesentium illo quibusdam.', '2025-01-19 11:51:48'),
(818, 'Opera/9.39 (Windows NT 6.1; en-US) Presto/2.9.184 Version/11.00', 'Occaecati mollitia quis magni natus qui consequatur corrupti quia. Iusto similique sit earum est aliquid quasi reprehenderit debitis.', '2016-10-23 01:25:17'),
(820, 'Opera/9.46 (Windows NT 5.1; sl-SI) Presto/2.9.168 Version/11.00', 'Soluta voluptatem recusandae magni perferendis eaque cum. Asperiores sequi officia et quis quaerat. Qui ex inventore quasi eum ab cum. Cumque porro nemo ipsa et.', '2007-01-16 17:07:54'),
(841, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_1 like Mac OS X; en-US) AppleWebKit/531.24.2 (KHTML, like Geck', 'Quibusdam et et incidunt commodi. Natus velit in repudiandae in assumenda dolores. Quod explicabo rem est eum.', '2017-12-19 11:47:01'),
(866, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.2; Trident/4.0)', 'Delectus voluptate asperiores necessitatibus expedita. Sed sequi pariatur maiores qui quia quis. Libero magnam qui qui quia pariatur modi ut.', '2020-10-29 06:36:33'),
(870, 'Opera/9.81 (X11; Linuxx86_64; en-US) Presto/2.9.178 Version/11.00', 'Sit iste facere voluptas dolores quaerat expedita. Id quia pariatur dolores voluptas fuga sed placeat. Et debitis qui tempora error sit dolorem. Autem quae accusamus ut doloremque delectus libero.', '1973-05-23 08:27:17'),
(888, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_3 rv:3.0; en-US) AppleWebKit/532.4.1 (KHTML, like Gecko)', 'Ut et et quos omnis. Id et sit blanditiis. Suscipit id sunt ipsam ex.', '1972-12-22 18:39:40'),
(905, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_8_0 rv:6.0; sl-SI) AppleWebKit/533.17.4 (KHTML, like Ge', 'Doloribus aut ut odio iure. Nisi quae eligendi dolore recusandae dolorum. Et porro sit fuga quo corrupti sed ab. Unde iusto pariatur nihil quia.', '2004-10-29 22:26:06'),
(907, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_6_9 rv:2.0; sl-SI) AppleWebKit/535.11.4 (KHTML, like Gecko) ', 'Nam et esse cum iste. Accusantium et odio non eos molestiae alias rerum. In vel et distinctio officia sit laborum. Voluptas libero totam ut nobis.', '1998-02-28 11:34:10'),
(908, 'Opera/8.32 (X11; Linuxi686; en-US) Presto/2.9.187 Version/11.00', 'Sed nesciunt ex sunt voluptatem rerum nulla voluptatem nisi. Ipsum ut autem tempore dolores minus non. Debitis dolorum iusto et sed corporis deleniti.', '2008-04-05 00:09:18'),
(909, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_3 rv:2.0) Gecko/20160102 Firefox/6.0', 'Consequuntur nihil quia perferendis eos nemo error quasi. Blanditiis nihil autem et. Repudiandae qui sint recusandae voluptas. Eaque voluptatem voluptas quia voluptatibus totam.', '2018-07-07 18:12:34'),
(910, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_2 rv:5.0; sl-SI) AppleWebKit/535.19.2 (KHTML, like Gecko', 'Dolor cumque consectetur expedita molestiae occaecati omnis. Laudantium ducimus suscipit debitis aliquam dolorem aut nam velit. Vero corporis rerum vel distinctio.', '2020-02-14 22:47:15'),
(911, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 4.0; Trident/4.1)', 'Aliquid unde sed sed officia sed sit ad in. Sit est sit aut eveniet esse blanditiis sequi. Aut ea veritatis rerum commodi ullam aut dolore. Et rem officia in omnis iste enim et magnam.', '2012-02-25 20:35:01'),
(916, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5340 (KHTML, like Gecko) Chrome/14.0.823.0 Safari/5340', 'Soluta consequatur quis adipisci explicabo asperiores. Et accusamus suscipit natus. Omnis ratione tempore est voluptate quasi. Vero quas nobis dolores cupiditate. Magni est officia a sit.', '2006-03-22 07:58:22'),
(922, 'Mozilla/5.0 (Windows NT 4.0; sl-SI; rv:1.9.2.20) Gecko/20120114 Firefox/3.8', 'Eligendi quia nemo voluptas adipisci cumque. Non occaecati quidem consectetur perspiciatis possimus ullam adipisci. Reprehenderit illum quasi veritatis voluptatem dolorum voluptatem inventore. Quia sunt exercitationem est eos quo.', '1995-06-02 23:13:34'),
(928, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows 98; Win 9x 4.90; Trident/5.0)', 'Molestiae molestias perferendis quod alias veniam velit. Laudantium facere autem vero quaerat autem. Consequatur in est optio quis a distinctio sit. Est aliquam similique enim omnis ad.', '2009-10-18 00:27:42'),
(934, 'Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/535.12.3 (KHTML, like Gecko) Version/4.1 Safari', 'Consequatur in delectus dolores quaerat consequatur expedita qui. Voluptas excepturi qui quaerat numquam explicabo iste. Incidunt est est necessitatibus.', '2023-04-20 17:25:19'),
(950, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5321 (KHTML, like Gecko) Chrome/15.0.849.0 Safari/5321', 'Est aut ut pariatur. Numquam aut ratione laborum cum.', '1993-04-23 13:18:23'),
(957, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0; Trident/5.0)', 'Incidunt voluptate similique facilis velit est optio. Voluptates quidem debitis id unde ipsa ut. Saepe et odio ducimus unde ullam ab. Quas facere laudantium necessitatibus voluptate quia ut.', '2009-07-06 09:40:34'),
(967, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2 rv:4.0) Gecko/20171230 Firefox/3.8', 'Sapiente occaecati sapiente placeat qui. Nisi rerum quae autem. Id ab dolor dolore ut.', '1985-06-24 21:53:24'),
(976, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/4.1)', 'Non inventore deserunt molestias neque molestias cumque dolores. Sapiente nostrum earum repellat culpa aspernatur voluptates omnis.', '1984-06-02 09:30:29'),
(984, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_9) AppleWebKit/5331 (KHTML, like Gecko) Chrome/14.0.8', 'Perspiciatis id ex rem aperiam voluptatem. Earum consequatur officia et ut similique eveniet voluptas. Explicabo ab possimus fugiat cumque totam aut quod.', '2021-08-17 08:00:20'),
(985, 'Opera/9.62 (Windows NT 5.01; sl-SI) Presto/2.9.172 Version/10.00', 'Deleniti ut sit quis doloremque reiciendis dolorem. Dignissimos incidunt eum qui veniam.', '1988-11-01 08:37:56'),
(1052, 'Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/534.9.5 (KHTML, like Gecko) Version/4.0.2 Safar', 'Sed minima et numquam adipisci cum totam sunt. Fugit quos quisquam consequatur fuga eveniet. Deserunt ipsum corporis sunt in. Eaque et quasi quaerat aspernatur ea placeat quo optio. Perspiciatis sapiente ut et omnis.', '2017-06-14 06:22:08'),
(1054, 'Opera/8.89 (Windows NT 5.01; en-US) Presto/2.9.161 Version/12.00', 'Praesentium occaecati beatae labore vitae et. Tempora sunt inventore quo facere perspiciatis non illo. Dolor in similique voluptas sit saepe consequatur.', '2022-10-08 19:01:15'),
(1058, 'Opera/8.34 (Windows NT 5.1; sl-SI) Presto/2.9.167 Version/11.00', 'Rerum sed illo nisi eos nihil rem. Facere voluptatem ut et rerum animi tempore. Aspernatur a repellendus mollitia provident cumque commodi harum. Nostrum voluptatum sit et aut ipsa.', '2019-09-30 19:48:54'),
(1178, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_6_7 rv:4.0) Gecko/20190413 Firefox/15.0', 'Necessitatibus culpa enim sint et ut ea eos. Officia consequatur expedita quo magnam minus molestiae. Et temporibus accusamus autem placeat eligendi et animi. Voluptates deleniti quae quis.', '1984-04-29 16:17:12');
INSERT INTO `categories` (`id`, `name`, `description`, `created_at`) VALUES
(1328, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows 98; Win 9x 4.90; Trident/5.1)', 'Fuga vel vitae sed molestias consequatur velit fugit. Ut aut qui suscipit molestiae ipsum. Quo ipsam omnis ut distinctio eos eius. Delectus autem ad et sit minima itaque.', '1975-01-22 07:04:13'),
(1371, 'Mozilla/5.0 (Windows NT 5.0; en-US; rv:1.9.2.20) Gecko/20170525 Firefox/3.8', 'Et eius nesciunt ex quidem. Est praesentium quam accusamus et. Ut rerum quis fugit assumenda est molestias.', '1980-01-24 22:59:23'),
(1378, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5361 (KHTML, like Gecko) Chrome/13.0.801.0 Safari/5361', 'Ipsum modi distinctio tempore temporibus aspernatur tempora sapiente quaerat. Praesentium numquam quam saepe et praesentium quia recusandae. Placeat consectetur et sint ex nesciunt. Accusamus mollitia eligendi dicta aut.', '2013-04-18 16:45:19'),
(1445, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_6_7 rv:3.0; sl-SI) AppleWebKit/534.17.5 (KHTML, like Gecko) ', 'Ut voluptatum consequatur suscipit perspiciatis voluptatem possimus. Id illum distinctio consequuntur maiores dolores explicabo modi necessitatibus. Adipisci voluptas excepturi aut et. Sed quam rem quia laudantium eligendi exercitationem libero.', '1983-08-02 10:45:03'),
(1449, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0; Trident/3.0)', 'Itaque excepturi eos quam dignissimos repellat nobis et. Doloremque dicta ipsum fugiat adipisci enim id voluptatem voluptas. Autem neque repellat doloribus et consequuntur est et. Id aut quia exercitationem pariatur.', '2005-07-25 08:54:21'),
(1454, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows 98; Trident/4.0)', 'Illum consequatur qui quo explicabo sed commodi. Dignissimos rerum nam ratione aspernatur suscipit adipisci et ratione. Voluptas quos recusandae commodi error. Laborum facere consequuntur commodi voluptatem eaque.', '1984-02-03 00:59:19'),
(1459, 'Opera/9.47 (X11; Linuxx86_64; sl-SI) Presto/2.9.188 Version/12.00', 'Praesentium consectetur at omnis autem sequi sequi explicabo pariatur. Voluptatum quasi dolores voluptatem quasi labore. Ut aliquid commodi iste labore ullam.', '1977-01-17 17:45:56'),
(1560, 'Mozilla/5.0 (X11; Linuxi686; rv:7.0) Gecko/20160925 Firefox/3.6.11', 'Est ab vitae quibusdam quo quia. Vitae voluptate consequatur alias eligendi maiores. Magnam nihil est architecto velit. Cum qui voluptates quia consequatur in aperiam repudiandae ducimus.', '2017-07-22 15:06:29'),
(1588, 'Mozilla/5.0 (X11; Linuxx86_64; rv:7.0) Gecko/20210228 Firefox/14.0', 'Voluptas qui architecto a omnis consectetur sed est numquam. Error est debitis quia accusantium numquam dolore doloribus qui. Illum deserunt voluptatem quia blanditiis odit illo est quisquam.', '1976-12-23 21:26:34'),
(1597, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 6.2; Trident/5.0)', 'Et necessitatibus fuga adipisci magnam corrupti libero. Sint et odio blanditiis iusto aut ex aspernatur dicta. Iusto rem quo doloremque voluptatem odio in ut. Qui aperiam nihil enim reiciendis vel soluta est sit.', '1992-10-02 13:47:11'),
(1689, 'Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/532.37.4 (KHTML, like Gecko) Version/4.0.2 Safa', 'Sed esse illo aut atque. Dolor consectetur sed quos esse rerum qui enim. Veritatis eaque soluta et et tempore optio ut.', '1981-10-30 21:38:19'),
(1783, 'Opera/9.82 (Windows NT 5.2; en-US) Presto/2.9.177 Version/10.00', 'Aut rerum deserunt ducimus eum quod corrupti sit in. Distinctio minus sunt inventore tenetur est non dolorem. Aut ducimus saepe assumenda voluptas. Dolore porro quos aspernatur nam laudantium.', '2012-03-02 05:08:48'),
(1891, 'Opera/9.36 (Windows 95; sl-SI) Presto/2.9.171 Version/11.00', 'Voluptatem maiores quia rerum rem. Dolorem deleniti voluptates quis consectetur. Amet dolorum sed nostrum non itaque qui.', '2013-05-14 21:13:19'),
(1970, 'Mozilla/5.0 (Windows NT 5.0; en-US; rv:1.9.0.20) Gecko/20250101 Firefox/3.8', 'Enim exercitationem autem dolorem quaerat ad modi reiciendis enim. Nisi architecto ratione eaque necessitatibus. Quo qui nostrum voluptates vero omnis. Quae impedit optio sint fugiat fugiat dolore in dolore.', '2022-12-24 23:52:07'),
(2014, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows 95; Trident/3.0)', 'Id voluptate quo similique quae odio. Nam voluptates placeat et aut assumenda. Sit similique occaecati aperiam quasi unde. Ut vel sit id nesciunt et qui voluptatum.', '1978-06-25 19:09:37'),
(2029, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_1 rv:4.0; sl-SI) AppleWebKit/531.21.2 (KHTML, like Gecko', 'Voluptates aliquid architecto at dolor illum eos aliquam officiis. Nam nam beatae quod saepe dolorem facilis commodi. Qui perspiciatis quasi accusamus illum ut explicabo enim. Sint ab ut quis debitis.', '2010-02-20 13:22:11'),
(2060, 'Opera/8.65 (Windows NT 4.0; en-US) Presto/2.9.166 Version/11.00', 'Qui ut ipsam aperiam et eos nemo dicta. Voluptas molestias accusantium aut ratione quia minus. Aliquid enim quasi et.', '1998-06-20 16:08:31'),
(2096, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.2; Trident/3.1)', 'Impedit nisi sed placeat consequatur architecto maiores harum. Sed exercitationem reprehenderit dolore ea voluptatem. Officiis non temporibus dolor voluptas labore ut repellat. Illo quam eligendi debitis impedit. Reiciendis mollitia quibusdam reiciendis nam occaecati et non quos.', '1981-11-03 05:22:42'),
(2107, 'Opera/9.92 (Windows CE; sl-SI) Presto/2.9.174 Version/11.00', 'Quod voluptatem non unde. Non impedit molestiae occaecati adipisci aspernatur dolore. Totam enim qui quia. Ipsa qui aliquam sit ea.', '1974-11-14 12:39:21'),
(2187, 'Mozilla/5.0 (Windows NT 5.0) AppleWebKit/5312 (KHTML, like Gecko) Chrome/14.0.828.0 Safari/5312', 'Debitis itaque laboriosam deserunt eos ut rerum aperiam. Nemo iste at quisquam quo ducimus voluptatem deserunt. Rerum est quis est eveniet.', '1983-11-12 02:15:53'),
(2228, 'Opera/8.38 (X11; Linuxx86_64; sl-SI) Presto/2.9.161 Version/11.00', 'Eaque fuga tempora assumenda iste nemo. Consequatur maiores omnis impedit dolorem. Eum sed dolor aliquam officiis minima itaque. Earum in earum velit et recusandae velit.', '1988-03-15 16:04:04'),
(2285, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_6_2) AppleWebKit/5362 (KHTML, like Gecko) Chrome/15.0.874', 'Earum modi ut facilis et. Soluta in laborum quia voluptas in est. Officiis est atque architecto.', '1986-04-11 13:06:49'),
(2345, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 6.2; Trident/4.0)', 'Vel distinctio rem minus ut. Error voluptatem reprehenderit qui vero similique. Dolores distinctio ea explicabo et.', '1972-08-02 13:15:04'),
(2368, 'Mozilla/5.0 (Windows NT 5.0; en-US; rv:1.9.2.20) Gecko/20230110 Firefox/15.0', 'Non ratione magni temporibus. Deleniti ut ut at incidunt tenetur reprehenderit quidem. Itaque suscipit pariatur ratione at quia. Possimus necessitatibus rerum sint rerum quod veniam.', '2022-08-26 23:45:49'),
(2673, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5342 (KHTML, like Gecko) Chrome/15.0.813.0 Safari/5342', 'Quas voluptatem incidunt numquam. Alias dolores sed ipsa et. Itaque ab vel voluptas voluptas accusantium sequi et.', '2021-12-30 20:58:32'),
(2882, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_0 like Mac OS X; sl-SI) AppleWebKit/535.37.1 (KHTML, like Geck', 'Eos quas voluptates soluta reprehenderit ad. Nulla aut repudiandae repudiandae eos. Et nobis earum autem aut dolores expedita deserunt. Totam molestiae nam iusto voluptatum cum repudiandae dignissimos.', '1993-05-11 05:20:32'),
(2937, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_2 like Mac OS X; en-US) AppleWebKit/534.36.1 (KHTML, like Geck', 'Nesciunt voluptatem aut autem ea quas quos. Sit ut sed vel praesentium. Eum quos voluptate ut aut consequatur nesciunt qui.', '2019-04-17 10:25:32'),
(3049, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_2) AppleWebKit/5360 (KHTML, like Gecko) Chrome/13.0.836.', 'Vel dolore debitis sed dolorum. Mollitia odio magni sed nihil natus eos. Et unde et ut eos quia.', '1972-07-31 10:55:56'),
(3089, 'Opera/8.42 (X11; Linuxi686; en-US) Presto/2.9.169 Version/10.00', 'Quo necessitatibus illum quasi vitae iusto doloribus hic. Perspiciatis a accusantium nobis nam illo. Odit quo dolorem consequatur eveniet distinctio.', '1991-12-11 16:17:19'),
(3348, 'Opera/9.80 (Windows 98; sl-SI) Presto/2.9.164 Version/11.00', 'Ut sed qui fugit reprehenderit enim. Qui accusamus maiores voluptatem qui cupiditate. Magni recusandae placeat nesciunt pariatur quos laudantium eum.', '2013-06-03 22:31:31'),
(3515, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_4 rv:3.0; sl-SI) AppleWebKit/531.1.2 (KHTML, like Gec', 'Earum asperiores dignissimos consequuntur iste. Maiores enim repudiandae et aperiam voluptatum. Voluptatem tenetur vel hic non alias vitae sunt. Ut tempora qui molestias sunt doloremque.', '1980-07-12 09:00:41'),
(3587, 'Mozilla/5.0 (Windows; U; Windows NT 5.01) AppleWebKit/534.33.6 (KHTML, like Gecko) Version/5.0.4 Saf', 'Labore alias fugiat eius qui odit. Dignissimos et et consequatur reprehenderit quos qui est. Ea enim nostrum nostrum sit dolore velit. Et rerum dicta molestiae voluptatem ex tempore.', '2000-10-30 09:54:12'),
(3812, 'Mozilla/5.0 (X11; Linuxi686; rv:7.0) Gecko/20190408 Firefox/3.8', 'Non repudiandae rerum autem quis qui pariatur. Maxime non voluptas nisi minus. Voluptatem reiciendis quaerat veritatis quo ratione. Ipsam recusandae adipisci aliquam.', '2010-08-10 06:08:26'),
(3976, 'Opera/8.26 (Windows CE; en-US) Presto/2.9.189 Version/12.00', 'Mollitia voluptate a aliquid maxime aliquam velit dolorum. Neque perferendis nostrum cupiditate deserunt. Voluptatem pariatur id tempora quaerat consequuntur quia.', '2008-06-11 18:50:19'),
(3978, 'Mozilla/5.0 (Windows NT 6.2; sl-SI; rv:1.9.0.20) Gecko/20200604 Firefox/3.8', 'Adipisci laborum tempora ut quia odit. Dicta molestias omnis similique error eius occaecati. Nesciunt modi dolores aut nihil omnis minima hic. Ipsa iusto deleniti mollitia libero facilis. Quasi qui non dolorum saepe.', '2014-01-27 11:32:28'),
(4012, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_7_8 rv:4.0; sl-SI) AppleWebKit/534.26.2 (KHTML, like Gecko) ', 'Et et corporis ea autem ut. Atque vel magnam deleniti qui. Ipsa consequatur in sint doloribus incidunt quas consequatur molestiae.', '2021-12-11 19:37:02'),
(4262, 'Opera/9.76 (Windows 98; sl-SI) Presto/2.9.175 Version/11.00', 'Suscipit quia impedit ut est facere corporis. Quae consequatur ut est id et unde. Est et voluptatem vel et odio autem corporis. In aut ullam possimus aut ex adipisci commodi.', '1973-10-22 15:50:04'),
(4464, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows 98; Trident/5.1)', 'Autem nisi voluptatem maiores itaque. Itaque quae nemo eum et consequuntur dolorem. Quisquam facere nesciunt veniam asperiores. Quibusdam est eveniet dolor nesciunt corrupti reprehenderit odit.', '1988-10-16 12:32:02'),
(4465, 'Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/531.8.1 (KHTML, like Gecko) Version/5.0.1 Safar', 'Qui et quo repellat nam. Ut velit quidem minus facilis. Et eos amet non et. Harum commodi fuga expedita ea laborum ut aperiam.', '1997-10-05 16:45:20'),
(4635, 'Mozilla/5.0 (Windows NT 4.0; sl-SI; rv:1.9.1.20) Gecko/20191116 Firefox/7.0', 'Iure ut voluptates sunt voluptatem quis excepturi. Expedita quis totam aspernatur ut. A magni voluptatum occaecati alias. Incidunt minus temporibus est suscipit dignissimos perferendis eum. Aut id quia sint aut consequuntur quo.', '1971-12-07 03:07:42'),
(4664, 'Mozilla/5.0 (Windows 95; en-US; rv:1.9.1.20) Gecko/20110814 Firefox/3.8', 'Nemo quod dicta vero illo. Quia itaque culpa consequuntur autem. Maxime ea dicta et debitis ea natus iste.', '2010-05-01 12:38:13'),
(4787, 'Mozilla/5.0 (Windows NT 5.0) AppleWebKit/5361 (KHTML, like Gecko) Chrome/13.0.838.0 Safari/5361', 'Non eos rerum sequi ab cumque id. Fugiat ipsam vel aut eum. Est similique delectus eaque incidunt at iure. Autem laudantium ut praesentium quia.', '2023-06-09 00:32:03'),
(4797, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows 98; Trident/3.1)', 'Eos molestiae nobis ab quod. Enim iste repellendus voluptas nihil a voluptatibus non. Et possimus laboriosam expedita qui repudiandae ea totam a.', '1973-03-02 03:09:00'),
(4802, 'Opera/9.34 (Windows NT 5.2; sl-SI) Presto/2.9.163 Version/10.00', 'Quaerat sunt magnam iure quisquam iste minus soluta. Ut accusantium quia expedita exercitationem. Porro voluptates impedit occaecati occaecati voluptatum ullam. Et quia numquam beatae perspiciatis neque sunt doloremque.', '2021-08-25 19:08:20'),
(4861, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.1; Trident/4.0)', 'Commodi saepe quos maiores. Totam vel itaque libero voluptas placeat qui aperiam. Et sit est in sed voluptatibus blanditiis. Alias harum non nulla.', '1973-08-29 22:50:04'),
(5165, 'Mozilla/5.0 (Windows NT 5.01; sl-SI; rv:1.9.1.20) Gecko/20170807 Firefox/3.6.1', 'Animi ratione nisi molestiae eaque. Aliquid quam cupiditate explicabo asperiores. Provident ut aspernatur similique voluptas qui quia rerum.', '2024-09-22 23:19:20'),
(5218, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows CE; Trident/5.0)', 'Inventore nisi consequuntur dolorem sed cupiditate voluptates modi qui. Magni velit sed impedit et omnis fugiat. Ipsam nesciunt nisi deserunt. Qui dolores totam autem vel autem distinctio aperiam.', '1975-04-11 00:36:46'),
(5237, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_7_6) AppleWebKit/5341 (KHTML, like Gecko) Chrome/13.0.807.0 ', 'Officia voluptas illo enim quibusdam quia. Iusto quo omnis commodi qui. Cumque molestiae aut consectetur quod aliquam. Ut totam nihil odit placeat eius autem.', '2013-01-15 21:17:55'),
(5238, 'Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/533.7.3 (KHTML, like Gecko) Version/4.1 Safari/', 'Laborum ea explicabo recusandae excepturi eum. Deserunt sunt mollitia maxime quibusdam in. Nemo beatae labore beatae. Est quia veritatis vel asperiores repellendus quas repudiandae.', '2011-04-06 19:40:31'),
(5241, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_8_6 rv:2.0; en-US) AppleWebKit/533.4.4 (KHTML, like Gecko) V', 'Ipsum reiciendis laudantium mollitia modi. Reprehenderit aspernatur suscipit est explicabo laborum. Est at excepturi commodi dolorum. Minima saepe qui consequatur accusamus. Aut cupiditate voluptas doloremque voluptatem animi est consectetur nihil.', '2016-11-16 08:19:39'),
(5353, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_6_0 rv:6.0; en-US) AppleWebKit/532.14.7 (KHTML, like Gecko) ', 'Odit saepe reiciendis a. Non ut incidunt sit accusantium quia sit. Ut eum qui odit et et vel voluptatum. Sit veniam officiis labore delectus reiciendis voluptas voluptate.', '2002-01-01 05:35:24'),
(5376, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_6_7 rv:2.0; sl-SI) AppleWebKit/534.7.3 (KHTML, like Gecko', 'Et facilis quae omnis architecto. Recusandae deleniti nostrum omnis magnam. Tempora enim aut aperiam rerum. Nostrum asperiores voluptatem cupiditate recusandae corporis.', '2018-07-21 11:13:11'),
(5385, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_6_3) AppleWebKit/5321 (KHTML, like Gecko) Chrome/14.0.825', 'Et inventore eos beatae. Fugit recusandae tenetur quasi culpa impedit rerum amet. Nam ut hic delectus vel. Nesciunt voluptate itaque est est cupiditate molestias voluptatibus.', '1974-11-20 02:51:42'),
(5393, 'Mozilla/5.0 (X11; Linuxx86_64; rv:6.0) Gecko/20180730 Firefox/3.6.3', 'Ea molestias voluptate totam. Sunt officiis officiis itaque deleniti. Enim commodi animi excepturi est occaecati maiores et. Quaerat maiores eum dolorem illo ad a.', '1981-04-02 16:47:25'),
(5447, 'Mozilla/5.0 (X11; Linuxi686; rv:5.0) Gecko/20170806 Firefox/8.0', 'Odit ipsum illo debitis perferendis ad expedita. Reprehenderit id ut aut placeat. Quibusdam fuga totam ad. Dolore libero quos nihil et omnis et.', '1973-02-19 23:59:37'),
(5594, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_7) AppleWebKit/5312 (KHTML, like Gecko) Chrome/15.0.845.', 'Quia nihil impedit dolorem enim veritatis cupiditate exercitationem. Qui voluptas omnis rerum deserunt. Et fugiat aut tempora. Rerum voluptatem nihil qui illo officiis cumque.', '2001-08-01 17:31:57'),
(5607, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5342 (KHTML, like Gecko) Chrome/14.0.888.0 Safari/5342', 'Saepe repudiandae deserunt atque est temporibus totam. Eveniet assumenda incidunt maxime cumque asperiores deleniti. Nobis praesentium est quo pariatur.', '2015-05-19 13:02:35'),
(5684, 'Opera/8.10 (X11; Linuxx86_64; en-US) Presto/2.9.161 Version/11.00', 'Explicabo aliquid facilis voluptatibus sint quae facere odit. Harum rerum sunt quod est officiis earum. Blanditiis eum qui sit. Maiores officia perferendis et aperiam.', '2014-06-01 22:57:54'),
(5688, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.01; Trident/4.0)', 'Dicta sit doloribus voluptatibus omnis ut. Tenetur nemo nobis laudantium nihil et ipsum est. Iste dolorem est voluptatem illo at enim. Omnis id possimus temporibus molestiae. Voluptatem omnis pariatur qui unde.', '2008-09-24 08:20:40'),
(5814, 'Opera/9.35 (Windows CE; en-US) Presto/2.9.160 Version/11.00', 'Rerum voluptatibus quisquam doloremque et exercitationem facere. Architecto doloremque rerum placeat aut similique deserunt. Qui nulla cupiditate aut ipsa.', '1985-09-08 17:25:30'),
(5826, 'Opera/9.22 (X11; Linuxx86_64; sl-SI) Presto/2.9.167 Version/11.00', 'Ipsam fugit ea cumque magnam. Autem ut et quidem dolores officiis eligendi provident. Dicta laudantium necessitatibus hic expedita autem dolor.', '1989-04-11 19:54:16'),
(5833, 'Opera/9.12 (X11; Linuxx86_64; en-US) Presto/2.9.180 Version/11.00', 'Non non sapiente modi. Quas nisi non sit. Aspernatur cumque mollitia rem commodi possimus et. A sit autem quam totam fugit. Qui aut blanditiis et amet nihil assumenda cum.', '2001-10-27 21:30:36'),
(5840, 'Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/531.38.1 (KHTML, like Gecko) Version/4.0.1 Safa', 'Iste est ratione voluptatem voluptas. Voluptas repellendus voluptatem enim esse. Labore vitae soluta facilis commodi eius aperiam. Perferendis et voluptatem ut.', '2019-05-19 23:21:26'),
(5883, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 6.0; Trident/3.1)', 'Repudiandae eveniet nihil ipsam error excepturi tenetur. Et libero qui laborum non ea cumque.', '2009-10-01 08:49:59'),
(5949, 'Mozilla/5.0 (Windows NT 6.0) AppleWebKit/5322 (KHTML, like Gecko) Chrome/13.0.826.0 Safari/5322', 'Quibusdam iusto dolorem unde. Eius consectetur aut necessitatibus sapiente. Dolorem eum voluptas perferendis eius voluptatem animi et.', '1985-03-12 07:12:05'),
(5970, 'Mozilla/5.0 (Windows; U; Windows NT 5.01) AppleWebKit/534.21.4 (KHTML, like Gecko) Version/4.0.5 Saf', 'Quis id magni voluptate maiores eaque dolor. Delectus voluptatem eum consequatur explicabo et. Laboriosam quia enim fuga dolorem nobis. Consectetur quia provident quasi numquam ut rerum exercitationem.', '1991-05-26 10:55:22'),
(6014, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_7_1 rv:3.0; sl-SI) AppleWebKit/531.9.1 (KHTML, like Gec', 'Magnam praesentium mollitia eum magnam. Facilis cumque impedit doloremque dolorum quia et nam. Nam similique eius omnis. Omnis quo cumque repudiandae animi quo iure magnam.', '2002-09-28 23:23:28'),
(6142, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_7_3 rv:3.0) Gecko/20120224 Firefox/3.8', 'Omnis illum earum reiciendis. Porro magnam sed ex harum est. Voluptatem veritatis ut possimus eum quidem.', '1978-11-08 21:50:51'),
(6385, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_8_1) AppleWebKit/5361 (KHTML, like Gecko) Chrome/15.0.883', 'Commodi fugit et magnam quos perferendis accusantium non. Voluptatem exercitationem ut beatae qui nisi sed voluptatem. Sit similique architecto aut quo dignissimos.', '1996-03-06 10:36:20'),
(6527, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5350 (KHTML, like Gecko) Chrome/15.0.871.0 Safari/5350', 'Facilis aut maiores a incidunt pariatur. Libero et aperiam minima deleniti similique doloribus ipsa.', '2018-06-06 23:35:56'),
(6701, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_5_2 rv:5.0) Gecko/20190226 Firefox/11.0', 'Pariatur commodi mollitia libero officia et sed distinctio ratione. Minus magni id minima totam fugiat qui maiores quia. Et in ut est pariatur voluptatum ratione. Adipisci ut voluptatem omnis accusamus.', '1978-01-11 09:42:44'),
(6705, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5362 (KHTML, like Gecko) Chrome/13.0.800.0 Safari/5362', 'Quis ut corporis distinctio saepe laudantium earum. Ut eius dolorem in sit dolore eum suscipit. Dolorem omnis dolores dolor reiciendis.', '1974-08-22 13:33:27'),
(6801, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows 95; Trident/5.0)', 'Tenetur vitae asperiores doloremque. Omnis culpa aspernatur itaque porro aut in. Et maiores animi a non delectus. Soluta quas iste a dolorum aut.', '2018-05-12 07:05:39'),
(6805, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_7_6) AppleWebKit/5341 (KHTML, like Gecko) Chrome/14.0.871', 'Aut voluptates dolores porro sit aliquid consequuntur. Illo aspernatur mollitia ipsam enim expedita nesciunt. Tenetur iste et incidunt molestiae vitae ducimus vitae. Provident aut sit officiis incidunt repudiandae autem ad.', '1971-01-17 08:57:20'),
(6886, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.1; Trident/5.0)', 'Omnis sit quis temporibus eveniet. Corporis corporis doloribus illo in.', '2017-03-14 12:09:13'),
(7015, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_9 rv:4.0; sl-SI) AppleWebKit/535.35.2 (KHTML, like Ge', 'Ipsum soluta cupiditate voluptates natus. Sequi totam et aut reiciendis.', '2000-05-27 20:58:48'),
(7094, 'Opera/8.71 (X11; Linuxx86_64; en-US) Presto/2.9.182 Version/10.00', 'Doloribus tempore adipisci necessitatibus facere quisquam. Qui maxime at quis dolore illum autem nobis. Assumenda officiis accusamus maxime possimus facere dolor reprehenderit earum.', '1981-07-25 12:05:20'),
(7101, 'Mozilla/5.0 (Windows 95; en-US; rv:1.9.1.20) Gecko/20170113 Firefox/3.6.2', 'Iste esse eius hic facere voluptas sit sit. A facilis cupiditate iusto id iure. Quia id autem sequi at. Et explicabo asperiores debitis est cupiditate et omnis labore.', '1977-05-26 07:57:55'),
(7105, 'Mozilla/5.0 (Windows NT 4.0; en-US; rv:1.9.1.20) Gecko/20240426 Firefox/9.0', 'At tempore fuga excepturi sit. Eius incidunt molestiae doloremque autem. Et et praesentium qui accusantium maxime qui.', '1995-11-17 13:05:56'),
(7173, 'Opera/8.50 (X11; Linuxi686; en-US) Presto/2.9.189 Version/10.00', 'Non facilis est non non est. Autem minima expedita blanditiis omnis et. Laboriosam aut facere iure. Sit aliquid aut id pariatur aut veritatis alias.', '2017-11-10 12:27:16'),
(7260, 'Mozilla/5.0 (X11; Linuxi686; rv:6.0) Gecko/20230929 Firefox/3.8', 'Dignissimos adipisci rerum qui amet. Ut aut voluptatibus voluptatem. Autem exercitationem facere voluptatem velit accusantium ut.', '1971-06-13 19:08:28'),
(7270, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_7_1) AppleWebKit/5310 (KHTML, like Gecko) Chrome/15.0.8', 'Illum rerum aut corporis expedita ratione pariatur officiis. Est excepturi rem officia molestiae et porro. Porro quaerat iste modi dignissimos est.', '2002-01-22 13:28:55'),
(7317, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5352 (KHTML, like Gecko) Chrome/15.0.825.0 Safari/5352', 'Nemo cumque id consectetur sed et qui ex. Error dolore repellendus cupiditate nobis quod. Sunt tenetur omnis et fugit. Inventore sit nulla debitis praesentium.', '2017-06-06 10:43:12'),
(7384, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows 95; Trident/5.1)', 'Nihil nesciunt incidunt error voluptas qui quibusdam. Beatae repudiandae cumque fugit. Laboriosam quam autem asperiores fuga asperiores dolorum. Ut similique cupiditate modi consectetur excepturi dignissimos.', '2001-04-22 21:24:53'),
(7465, 'Opera/9.95 (X11; Linuxx86_64; en-US) Presto/2.9.182 Version/11.00', 'Beatae at quod qui nihil repudiandae saepe commodi. Doloribus placeat pariatur assumenda ut suscipit laborum et. Sit voluptatem nihil sunt adipisci.', '1986-07-01 03:51:26'),
(7655, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 6.1; Trident/4.0)', 'Consequatur et ut aspernatur voluptatem temporibus ut assumenda vel. Quo non dolorem eaque quasi aspernatur fuga.', '1976-03-08 04:21:13'),
(7659, 'Opera/8.25 (X11; Linuxx86_64; sl-SI) Presto/2.9.180 Version/10.00', 'Quia omnis ea est voluptatibus tenetur temporibus voluptatem. Laudantium nisi nobis voluptatem ut deleniti qui mollitia. Sed cumque eaque et corrupti cum velit.', '1981-07-01 04:19:00'),
(7684, 'Opera/8.42 (X11; Linuxx86_64; en-US) Presto/2.9.167 Version/10.00', 'Fuga expedita ut aliquid alias est. Consequatur mollitia totam quasi. Repellat aliquid dicta dolore ut reprehenderit et praesentium. Voluptatem voluptatem in aperiam qui et ut ut.', '1972-07-19 21:15:12'),
(7698, 'Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/535.36.2 (KHTML, like Gecko) Version/5.1 Safari', 'Laboriosam ut dolores sed sed. Pariatur adipisci impedit et quos. Quisquam facilis est voluptatibus.', '2015-01-09 20:56:47'),
(7717, 'Mozilla/5.0 (X11; Linuxi686; rv:6.0) Gecko/20190610 Firefox/3.6.1', 'Praesentium aut soluta quia unde magnam nisi. Porro amet alias aliquam quia asperiores. Ut eveniet eos dolorem odio.', '2007-09-11 14:56:58'),
(7866, 'Opera/9.83 (Windows 95; sl-SI) Presto/2.9.190 Version/12.00', 'Dolorem ut quis distinctio dolor. Quibusdam sit nisi et maxime. Est enim iure aspernatur expedita ab fugit aut.', '2017-11-10 06:48:32'),
(7894, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_7_5) AppleWebKit/5320 (KHTML, like Gecko) Chrome/14.0.8', 'Et voluptates consequuntur non itaque sint. Maxime aliquid recusandae consequatur illo dignissimos. Est natus vitae ut sequi sed.', '1988-07-21 04:23:19'),
(8055, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)', 'Eaque soluta et rerum debitis est. Eligendi eius quis alias ut et aut. Debitis et culpa omnis et delectus accusamus voluptatem.', '2006-11-03 08:43:19'),
(8096, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 6.2; Trident/4.1)', 'Ipsam reprehenderit vel modi voluptates recusandae placeat. Et minima laudantium voluptates. Sint tempora explicabo dolore eius quisquam maiores quas. Sequi minus in eos blanditiis.', '1983-07-02 16:46:22'),
(8196, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_3 like Mac OS X; en-US) AppleWebKit/532.28.3 (KHTML, like Geck', 'Tempore ut qui a consequatur enim. Fugiat totam deleniti et maxime consequatur non dolorem. Quas vel necessitatibus fugiat consequatur. Qui sunt et consequuntur nisi fugit officia.', '2006-08-01 03:11:39'),
(8236, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_2 like Mac OS X; en-US) AppleWebKit/533.46.7 (KHTML, like Geck', 'Et modi delectus molestiae accusantium itaque a. Rerum sed ut aperiam consequatur aut natus. Qui placeat dolores praesentium.', '1997-05-27 02:47:47'),
(8285, 'Opera/8.60 (Windows NT 6.1; sl-SI) Presto/2.9.162 Version/12.00', 'Sint laborum facilis odit qui ex sit et. Est at ut culpa cum. Mollitia cupiditate laboriosam atque quia non dolore. Eum nobis et et et placeat aut odio.', '1989-02-14 06:20:24'),
(8488, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows 98; Trident/5.0)', 'Sit laborum enim perspiciatis. Facere corrupti eos tenetur consequatur non illo. Consequatur vitae quo et qui laudantium expedita.', '2011-12-06 17:30:48'),
(8683, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 4.0; Trident/4.1)', 'Aut non voluptates deleniti aut. Id error deleniti dignissimos ipsa molestias omnis. Doloribus vel nostrum ut esse.', '1987-12-26 18:27:22'),
(8703, 'Mozilla/5.0 (Windows CE) AppleWebKit/5342 (KHTML, like Gecko) Chrome/14.0.820.0 Safari/5342', 'Blanditiis et magnam in eveniet pariatur enim. Qui recusandae iste sint odio nemo consequatur. Et ducimus dolores at quia. Est repellendus expedita eum adipisci voluptate perspiciatis maiores.', '2022-10-01 11:32:02'),
(8731, 'Opera/9.38 (X11; Linuxi686; sl-SI) Presto/2.9.171 Version/10.00', 'Excepturi odit quod dolore inventore repudiandae rerum eum. Ut sunt quasi qui voluptatibus dignissimos consequatur expedita. Suscipit temporibus provident ex eligendi quia. Asperiores et placeat a fugit laborum.', '2014-01-11 02:29:32'),
(8785, 'Opera/8.37 (X11; Linuxi686; en-US) Presto/2.9.181 Version/11.00', 'Porro similique dolorum ipsa eum in. Corrupti accusantium quos possimus.', '2001-11-13 08:03:25'),
(8853, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_8_5 rv:3.0; en-US) AppleWebKit/535.14.7 (KHTML, like Gecko) ', 'Est ducimus quo veniam. Eius exercitationem nihil vero porro. Itaque quis at temporibus maiores. Reiciendis est aut quod sed.', '2010-05-25 08:29:04'),
(8911, 'Mozilla/5.0 (X11; Linuxx86_64; rv:7.0) Gecko/20130817 Firefox/3.8', 'Odit nisi necessitatibus illum sunt labore at. Sed commodi sit quaerat et ducimus culpa doloremque. Eum cumque qui voluptas quia error sint. Reprehenderit vel qui autem animi.', '1991-04-22 14:12:03'),
(9098, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_5_4 rv:4.0) Gecko/20141209 Firefox/3.8', 'Ratione est ipsam ipsam tenetur voluptas molestiae in. Ut est quasi exercitationem sed. Et et voluptate necessitatibus amet quae tempora nemo. Perferendis dignissimos doloribus esse rerum quia et.', '1971-09-10 09:17:09'),
(9181, 'Mozilla/5.0 (Windows CE; sl-SI; rv:1.9.1.20) Gecko/20230608 Firefox/15.0', 'Dicta quis in voluptas quo laborum delectus nihil nihil. Ullam est libero et nemo molestias quo et. Corrupti porro optio et est.', '1973-02-25 10:27:46'),
(9216, 'Mozilla/5.0 (Windows; U; Windows 98; Win 9x 4.90) AppleWebKit/534.43.4 (KHTML, like Gecko) Version/4', 'Voluptas necessitatibus eum omnis dolor vero eum nihil. Tenetur sapiente quae unde eum cupiditate quia ducimus. Rem enim similique alias. Eveniet optio molestiae labore culpa.', '1979-09-06 03:33:58'),
(9246, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 4.0; Trident/3.0)', 'Rerum minus enim aspernatur perspiciatis omnis rerum. Voluptatibus repudiandae doloremque mollitia atque facere. In placeat inventore quo quia qui excepturi. Quasi aliquid vel libero corrupti dolorum et quisquam. Itaque eaque laboriosam qui vel nesciunt.', '1988-07-16 08:16:40'),
(9448, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 4.0; Trident/5.1)', 'Blanditiis quis qui iste aliquam. Laudantium ut officiis recusandae et. Error quae officia possimus numquam enim est sint. Et nihil culpa dolor aliquid qui. Molestias eum qui consequuntur qui est.', '2017-03-26 08:03:45'),
(9456, 'Mozilla/5.0 (Windows NT 5.0) AppleWebKit/5351 (KHTML, like Gecko) Chrome/13.0.853.0 Safari/5351', 'Similique vero est nam quia excepturi iste. Voluptatem non id consequuntur et ad. Exercitationem sint facilis mollitia explicabo doloremque vel voluptate.', '1989-08-30 19:09:17'),
(9480, 'Opera/8.46 (Windows NT 5.2; en-US) Presto/2.9.164 Version/12.00', 'Atque dolor qui nisi voluptas inventore rerum quas. Facere dolores eos quibusdam. Cupiditate quis mollitia unde et non.', '1983-09-09 11:20:01'),
(9511, 'Opera/9.60 (X11; Linuxx86_64; en-US) Presto/2.9.181 Version/11.00', 'Qui aut dolorem voluptate repellendus. Voluptas quae laborum ut vitae. Accusantium est qui officia odio rerum voluptatem. Excepturi eos et ipsa ad distinctio veniam.', '2022-06-18 14:52:39'),
(9802, 'Opera/8.36 (Windows NT 5.01; sl-SI) Presto/2.9.160 Version/11.00', 'Voluptatem natus sint voluptates. Inventore nisi occaecati ut doloremque. Repellendus iste eveniet doloremque. Qui iusto non recusandae alias.', '2016-07-26 04:02:54'),
(9897, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5320 (KHTML, like Gecko) Chrome/13.0.810.0 Safari/5320', 'Sed laborum aliquid voluptatem omnis. Expedita et sint est ut nesciunt.', '1980-09-18 06:47:47'),
(9942, 'Opera/8.94 (Windows NT 6.0; sl-SI) Presto/2.9.168 Version/12.00', 'Veritatis ut voluptatem sed consequatur in. Perspiciatis vitae nostrum quia distinctio. Est quia officia quia illum suscipit numquam porro. Culpa inventore beatae sint vel architecto quos quod provident.', '1976-05-17 13:33:53'),
(9965, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows CE; Trident/5.0)', 'Et quis quos hic tempore dicta eveniet. Assumenda autem quia non corrupti pariatur et. Labore rem provident in aut.', '2021-04-07 23:05:33'),
(10244, 'Mozilla/5.0 (Windows NT 5.01) AppleWebKit/5342 (KHTML, like Gecko) Chrome/15.0.896.0 Safari/5342', 'Quaerat quidem aliquam dolorem at voluptatem et. Sunt aperiam distinctio sequi rem sint. Eos ex quas eos id non occaecati qui. Culpa totam soluta qui quasi rerum est voluptas.', '2009-03-20 10:06:34'),
(12447, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_7_8 rv:3.0) Gecko/20180102 Firefox/3.6.8', 'Modi minus ea beatae voluptatem tempora sit. Ut temporibus et voluptatem et. Ex est rem ut similique.', '2021-08-06 00:24:23'),
(12719, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5321 (KHTML, like Gecko) Chrome/13.0.849.0 Safari/5321', 'Tempora repellendus distinctio alias exercitationem. Id iste eligendi porro in ipsum voluptates et. Et perferendis sit repellat culpa. Enim ex velit deleniti earum consequatur deserunt voluptas.', '2015-06-11 23:36:09'),
(12846, 'Opera/8.88 (X11; Linuxx86_64; en-US) Presto/2.9.182 Version/10.00', 'Labore amet id similique quia. Sed at incidunt est voluptatem ut. Possimus qui iusto voluptatibus qui. Nihil doloribus incidunt et necessitatibus alias.', '1971-02-28 22:57:40'),
(12924, 'Opera/8.39 (Windows 98; Win 9x 4.90; en-US) Presto/2.9.180 Version/11.00', 'Atque nemo est temporibus qui incidunt ea. Quo est non et sunt. Corporis illum et magnam eligendi eos laborum ut.', '2023-05-05 13:23:35'),
(13494, 'Mozilla/5.0 (X11; Linuxi686; rv:7.0) Gecko/20230226 Firefox/3.6.17', 'Suscipit odit aut eos. Non dolore voluptates quisquam perspiciatis cum aliquid. Eligendi quis cumque necessitatibus voluptatibus voluptatem. Consequatur modi voluptatibus aut aut non error ducimus.', '2000-04-14 06:53:37'),
(15799, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_0 like Mac OS X; sl-SI) AppleWebKit/534.4.6 (KHTML, like Gecko', 'Eaque sequi soluta velit et reprehenderit. Et aliquam a enim quisquam aut. Eaque quia numquam ut ad sequi cumque et rem. Architecto distinctio qui soluta doloribus rerum odit iusto. Eos veritatis minus vero voluptatem distinctio.', '1993-07-08 04:31:48'),
(16248, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows 98; Win 9x 4.90; Trident/3.1)', 'Quibusdam minus voluptatem ratione provident quis aut. Aut error nulla molestiae maxime id voluptas. Consequatur iure alias et.', '1999-07-08 20:20:01'),
(16650, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows CE; Trident/5.1)', 'Ut ut non eius sed id maiores vel voluptate. Aliquid eum harum aliquid amet quod. Sed nihil consequatur molestiae aliquid sunt deleniti. Error non mollitia ratione qui deserunt. Veniam quia ratione error aut nostrum ullam.', '1993-03-06 08:42:40'),
(16682, 'Mozilla/5.0 (X11; Linuxx86_64; rv:5.0) Gecko/20110326 Firefox/3.8', 'Id doloremque ex velit. Voluptatem aliquid ut deserunt quia et. Labore accusamus est atque sit quis eaque. Corporis optio temporibus placeat voluptatem laborum vel qui.', '2007-01-05 04:46:42'),
(16701, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5310 (KHTML, like Gecko) Chrome/13.0.865.0 Safari/5310', 'Autem id explicabo enim asperiores. Hic quas aut tenetur a. Deserunt et voluptatem ut ratione repellendus dolor voluptates.', '1975-04-04 23:46:40'),
(17358, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows 98; Trident/5.1)', 'Modi esse aspernatur quod sit aut iste. Voluptatem adipisci quia inventore laboriosam aut natus asperiores tempora. Molestiae sit et qui expedita tenetur.', '1977-01-26 14:57:31'),
(17599, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows CE; Trident/4.1)', 'Magni est non natus quo libero recusandae. Officia omnis pariatur est culpa voluptas libero tempora maiores. Corporis ut dicta veritatis. Quod quis modi enim. Sit et perferendis adipisci excepturi incidunt voluptatem sint.', '1979-11-28 11:02:29'),
(18911, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 5.2; Trident/5.1)', 'Voluptates voluptatem aspernatur asperiores consectetur illum minus. Aliquid quae dolorem sint quo aut. Ratione quis praesentium blanditiis velit facere exercitationem.', '2010-09-17 12:30:44'),
(19284, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.01; Trident/4.0)', 'Cupiditate nam voluptas et consequatur molestiae. Occaecati sunt sed quia aliquid non accusamus eos sunt. Est natus nostrum laboriosam in dolores qui.', '2008-01-14 05:26:50'),
(19379, 'Opera/9.88 (Windows 95; en-US) Presto/2.9.181 Version/12.00', 'Temporibus laborum ea atque. Totam sint non exercitationem in delectus recusandae dolorem. Dolore et beatae qui enim ut provident vel omnis. Dolores cum sint eos nihil illum est. Temporibus aspernatur ullam quae dolor temporibus.', '2012-03-20 04:24:40'),
(19470, 'Mozilla/5.0 (X11; Linuxx86_64; rv:7.0) Gecko/20151122 Firefox/3.6.13', 'Qui occaecati sequi deleniti cupiditate molestiae et. Nulla id distinctio sint est enim quo.', '2019-10-23 22:01:05'),
(19633, 'Opera/8.77 (Windows NT 5.1; en-US) Presto/2.9.163 Version/11.00', 'Quae maxime cum quaerat in voluptatibus. Dolores consequatur nesciunt voluptatibus eos minima aut. Sit nostrum voluptatem et voluptatum sapiente et qui nulla. Ea dolorem perferendis mollitia voluptas.', '1986-07-23 08:56:55'),
(20742, 'Opera/9.37 (X11; Linuxx86_64; sl-SI) Presto/2.9.185 Version/11.00', 'Amet illum ipsam dolorem dolorem quo repudiandae ut. Velit eveniet saepe reprehenderit aut quia enim.', '2000-10-06 03:40:45'),
(21746, 'Mozilla/5.0 (X11; Linuxi686; rv:6.0) Gecko/20160204 Firefox/14.0', 'Cum aliquid voluptate reiciendis quisquam consequatur odit illum. Eaque id alias tempora ut. Est sed natus sit et quasi quia. Sapiente non aliquam deleniti pariatur facere et.', '1975-12-14 05:54:07'),
(21808, 'Mozilla/5.0 (Windows CE) AppleWebKit/5331 (KHTML, like Gecko) Chrome/13.0.855.0 Safari/5331', 'Porro est esse ipsa. Quia ex perspiciatis praesentium consequuntur autem.', '1992-12-10 15:32:15'),
(21818, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_7_9 rv:2.0; sl-SI) AppleWebKit/535.13.2 (KHTML, like Geck', 'Sunt dolorem officia et occaecati dolorem vitae. Illum quidem quam excepturi placeat nemo soluta ut soluta. Maiores temporibus dolorem doloremque nihil.', '2000-11-17 17:32:08'),
(22896, 'Opera/9.78 (Windows NT 5.0; sl-SI) Presto/2.9.160 Version/10.00', 'Dolor est et quasi qui quos repellat. Possimus culpa officia optio. Minus aut vel quo animi.', '2003-07-08 07:48:32'),
(24871, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows 98; Win 9x 4.90; Trident/4.0)', 'Et est animi rerum laudantium eum. Hic at enim sed. Nam earum blanditiis voluptatem dicta vitae vel sit minima. Dolores facilis ut harum nesciunt sed et.', '2021-05-21 22:22:27'),
(25956, 'Opera/8.73 (X11; Linuxi686; sl-SI) Presto/2.9.173 Version/10.00', 'Beatae non repellat neque veniam a recusandae tempora sed. Est et occaecati tenetur eum quo ad. Sint nesciunt aperiam quas earum nihil perferendis deleniti.', '1974-11-22 20:06:01'),
(27079, 'Mozilla/5.0 (Windows; U; Windows NT 5.01) AppleWebKit/531.25.5 (KHTML, like Gecko) Version/4.0.3 Saf', 'Culpa quidem assumenda dolores illum. Repudiandae inventore repellendus quisquam laboriosam unde aliquam. Ut placeat tempore ab harum. Nobis pariatur est et eveniet culpa doloremque qui.', '2011-02-17 09:23:02'),
(27122, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_7_9) AppleWebKit/5340 (KHTML, like Gecko) Chrome/13.0.8', 'Nobis est similique illo et ipsa placeat id. Ut nostrum omnis id ipsam ut. Illo aut pariatur et aut vitae et fugiat. Impedit alias eos tempora recusandae. Est molestiae aut quis.', '2014-09-17 12:37:37'),
(27473, 'Mozilla/5.0 (Windows 95; en-US; rv:1.9.0.20) Gecko/20210423 Firefox/7.0', 'Minima libero excepturi qui corporis ea alias qui. Tenetur quae quod qui est aut maxime.', '1995-04-03 09:21:18'),
(27535, 'Mozilla/5.0 (Windows NT 6.0; en-US; rv:1.9.0.20) Gecko/20160521 Firefox/3.8', 'Eos quasi similique aperiam ipsa blanditiis reprehenderit. Repudiandae praesentium consequatur incidunt tenetur natus corrupti fugit. Ipsa suscipit vitae magni repellat aut vero earum. Esse in omnis placeat aut voluptates non ullam.', '2007-05-29 07:36:17'),
(27549, 'Mozilla/5.0 (Windows NT 5.0) AppleWebKit/5362 (KHTML, like Gecko) Chrome/13.0.811.0 Safari/5362', 'Optio dolores eos ratione magnam id. Qui suscipit vero quam magnam. Cumque aut iste aut recusandae dolorem tempore recusandae. Officia facere laborum dolorem sed sunt commodi ut rerum.', '2006-07-11 04:05:13'),
(27888, 'Mozilla/5.0 (Windows; U; Windows NT 5.01) AppleWebKit/532.7.6 (KHTML, like Gecko) Version/4.0.5 Safa', 'Velit beatae architecto explicabo hic sapiente eos ut aut. Accusantium laborum maiores voluptate beatae voluptatum aut illum. Qui aliquid optio sint laborum eius fugit neque. Explicabo possimus culpa nam sequi beatae.', '2003-03-03 15:40:06'),
(28455, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 4.0; Trident/3.1)', 'Aut enim et doloremque consequatur minus. Omnis voluptates quam eos. Sapiente voluptatem ratione est est quaerat voluptates. Quibusdam odio et ut rerum.', '1997-07-07 05:16:39'),
(28720, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_7_6 rv:4.0; en-US) AppleWebKit/532.33.6 (KHTML, like Gecko) ', 'Eligendi vel provident dolore et minus quia. Earum dolores laboriosam ea est. Quia temporibus suscipit et eaque. Expedita qui veniam est. Cupiditate at rerum aperiam tempore enim quia.', '2021-10-20 07:22:58'),
(30115, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_5 rv:6.0) Gecko/20200128 Firefox/3.6.18', 'Rerum provident assumenda omnis unde a. Provident laboriosam quia cum et rerum. Laboriosam omnis eum est alias enim placeat doloremque. Fugiat ut amet sit eum. Voluptas sint voluptatem suscipit ipsum voluptas.', '1977-03-04 19:14:22'),
(30153, 'Mozilla/5.0 (Windows NT 4.0; sl-SI; rv:1.9.1.20) Gecko/20240715 Firefox/3.6.16', 'Neque ullam praesentium quo aliquid. Molestiae totam eveniet accusamus repellendus. Omnis architecto in consequuntur sapiente dolor. Est sapiente a ut est nulla cumque.', '1999-10-30 19:39:59'),
(30479, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows 98; Trident/5.0)', 'Libero voluptatum aut adipisci voluptatum dolorem fuga. Ex voluptatem reprehenderit excepturi voluptates fugit harum id. Quas modi enim officiis minus. Eaque aut a hic omnis aut cupiditate debitis perferendis.', '2013-04-07 21:50:03'),
(31274, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 6.0; Trident/3.0)', 'Quam debitis eius voluptatem id qui eligendi. Vitae quia non fugiat vel deserunt. Rerum odio inventore debitis.', '2011-09-03 07:06:18'),
(32267, 'Opera/9.80 (Windows NT 5.0; sl-SI) Presto/2.9.187 Version/12.00', 'Libero et libero et quam amet. Doloremque non quia esse ratione quia rerum et.', '1991-01-09 04:52:55'),
(33130, 'Mozilla/5.0 (X11; Linuxx86_64; rv:5.0) Gecko/20110531 Firefox/3.6.12', 'Laudantium debitis earum sed nam qui quia. Qui aspernatur iure minus qui voluptatum laborum.', '1986-07-21 14:01:01'),
(33251, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows 95; Trident/4.0)', 'Illum et sed vel distinctio ab quos dolorem. Et sit ea perspiciatis placeat sunt voluptatibus. Architecto et dolores veniam a. Nihil nisi sit dolor iste.', '2005-02-23 12:40:19'),
(33265, 'Opera/8.40 (Windows CE; en-US) Presto/2.9.189 Version/11.00', 'Vel deleniti eligendi adipisci ad consequatur. Voluptates quae amet est et debitis voluptatem voluptate est. Vel quia eum qui harum facilis est. Blanditiis sunt et est sint repellendus.', '1993-03-28 16:14:32'),
(33301, 'Opera/8.94 (Windows CE; en-US) Presto/2.9.167 Version/12.00', 'Aut optio rerum et eligendi distinctio. Et similique ad illo quia. Distinctio assumenda ut laboriosam dolorem velit voluptatem aspernatur omnis.', '2006-07-08 12:31:48'),
(33504, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_2 like Mac OS X; en-US) AppleWebKit/534.48.4 (KHTML, like Geck', 'Maxime nihil sit ab vitae voluptatem deleniti. Et possimus asperiores in necessitatibus iure quo. Voluptatum qui porro saepe dolor sit eos sapiente.', '2000-04-16 20:29:28'),
(33910, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_7 rv:5.0) Gecko/20160317 Firefox/3.6.2', 'Quidem voluptatibus labore omnis sapiente voluptatibus ullam amet. Autem in aliquam nihil suscipit. Quibusdam illum sit non autem rerum cum adipisci. Reprehenderit a laborum fugit tempora.', '2001-05-13 20:31:29'),
(33915, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_7_6 rv:3.0; en-US) AppleWebKit/533.34.4 (KHTML, like Gecko) ', 'Facere ut laboriosam nihil nihil eos id neque. Omnis nesciunt quis et nisi architecto voluptatem omnis. Ipsa dolor cupiditate vel accusantium quia laboriosam.', '1985-08-05 17:42:20'),
(34501, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_1 rv:4.0; sl-SI) AppleWebKit/534.3.3 (KHTML, like Gecko)', 'Dignissimos aliquid aut nulla molestiae doloribus id. Tenetur deserunt voluptatum sit repudiandae quaerat. Esse quibusdam autem officia unde.', '2008-06-02 11:26:44'),
(34821, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows CE; Trident/3.0)', 'Tenetur molestias qui dolores ut ad quos qui. Quia ducimus eos culpa deserunt delectus molestiae possimus. Nobis ab doloremque sed fuga consequatur dicta. Fugit sunt eum officiis veniam.', '2003-09-28 11:39:51'),
(35342, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_7_0 rv:6.0; sl-SI) AppleWebKit/534.47.7 (KHTML, like Ge', 'Quis error et fugiat vero quam. Non laborum est aut voluptatum et a. Alias sit ipsum vero mollitia ipsa.', '1983-09-05 23:08:38'),
(36424, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_2 like Mac OS X; sl-SI) AppleWebKit/533.4.4 (KHTML, like Gecko', 'Eius aspernatur ea quis placeat laboriosam in. Est aut eos deleniti est fugiat. Ex exercitationem dolor odit consequatur vero fuga.', '2013-01-18 09:17:28'),
(36466, 'Mozilla/5.0 (X11; Linuxx86_64; rv:5.0) Gecko/20190224 Firefox/3.8', 'Dicta ad facilis et ut fuga officiis. Saepe sit adipisci tempora eligendi provident explicabo impedit. Labore aut ipsa id exercitationem velit aspernatur hic. A harum sunt excepturi aliquam.', '1984-03-06 02:22:12'),
(36629, 'Mozilla/5.0 (X11; Linuxi686; rv:6.0) Gecko/20240407 Firefox/3.8', 'Distinctio sit et facilis voluptatem dolor sapiente rem. Quo hic quia quos necessitatibus amet voluptas. Corporis sit dolorem dolor non quasi expedita.', '2022-10-21 18:09:28'),
(40130, 'Opera/9.75 (Windows NT 5.01; en-US) Presto/2.9.186 Version/12.00', 'Omnis magni aliquam repudiandae vel numquam quia facilis. Quia excepturi non eum porro et eos. Voluptatem et exercitationem id neque et porro eveniet. Aut nobis occaecati aliquam nihil.', '1976-01-12 15:47:20'),
(40501, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_6) AppleWebKit/5352 (KHTML, like Gecko) Chrome/15.0.828.', 'Repudiandae odit magni rerum. Voluptas alias id debitis impedit consequatur. Ut aut ut natus tenetur. Mollitia doloribus quia illum quia.', '2007-08-20 08:15:52'),
(40999, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows 98; Trident/4.0)', 'Incidunt aut voluptatem voluptas saepe voluptates. Corporis alias consequatur dolor et saepe explicabo eius. Rerum harum et nostrum iste fuga ducimus at. Temporibus neque non est eius ut perspiciatis explicabo. Nihil vel ipsum sed ea quidem.', '1988-07-25 11:12:51'),
(42349, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_3 like Mac OS X; en-US) AppleWebKit/534.46.4 (KHTML, like Geck', 'Aut praesentium esse qui consequatur. Velit et fugit et rerum. Maiores et libero quos iste.', '1984-05-15 22:32:23'),
(42514, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.2; Trident/3.1)', 'Veritatis ab cumque magnam dolorem iusto reiciendis ut quo. Eius voluptatibus et veritatis sit. Nihil temporibus labore corporis deserunt culpa laborum. Reiciendis consequatur labore aut voluptas similique aspernatur. Sit praesentium sunt voluptatem molestias enim impedit ullam.', '2017-10-10 17:25:12'),
(42553, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_8_9 rv:5.0) Gecko/20141022 Firefox/3.8', 'Sint quaerat saepe qui et tempore architecto ea. Maiores itaque eveniet dolorum alias non perferendis assumenda. Ut soluta ut odio necessitatibus. Quam non et error animi placeat repellendus.', '1993-04-11 00:00:36'),
(44551, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows 98; Trident/5.0)', 'Sunt soluta praesentium nostrum itaque quisquam quia labore in. Fuga iusto veritatis tempora natus repellendus aut nobis. Sunt repellat voluptate ut magni perferendis sit dolorum. Ut nesciunt eligendi quisquam animi temporibus impedit ut.', '1995-03-12 16:28:47'),
(45157, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_3 like Mac OS X; en-US) AppleWebKit/531.35.3 (KHTML, like Geck', 'Voluptatibus eveniet placeat sunt dicta soluta esse praesentium. Neque nam occaecati temporibus maxime et nisi velit delectus. Aut corrupti sint omnis est doloremque sit perferendis assumenda. Porro velit eaque et assumenda perferendis in qui placeat. Ut officiis asperiores vel minus.', '2005-04-01 00:31:35'),
(45179, 'Mozilla/5.0 (X11; Linuxi686; rv:7.0) Gecko/20220918 Firefox/3.6.19', 'Eos facere corrupti tempora. Delectus omnis sint esse deleniti ea ea enim. Tenetur itaque fugiat at culpa.', '1984-02-14 15:21:08'),
(46213, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_4 rv:2.0) Gecko/20130713 Firefox/3.8', 'Soluta enim quia eveniet. Nihil asperiores nulla possimus quasi quia et. Cumque nisi placeat cumque sint fugit dolores id et.', '1973-04-19 19:55:06'),
(46279, 'Mozilla/5.0 (Windows; U; Windows 98) AppleWebKit/532.37.1 (KHTML, like Gecko) Version/5.0.1 Safari/5', 'Veritatis et id distinctio corporis. Incidunt eos dolores est dolor quia ut qui nobis. Reiciendis dicta itaque sunt exercitationem qui aliquam. Recusandae reprehenderit voluptatem est sit aspernatur commodi.', '1981-05-31 13:53:59'),
(47614, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_6_2 rv:2.0) Gecko/20111104 Firefox/3.8', 'Illo quibusdam nam a asperiores rerum deleniti. Rerum et suscipit rerum et atque aspernatur facilis tempore. Inventore quas commodi recusandae. Quod perspiciatis eos vel odit minus odit.', '1997-05-22 12:33:08'),
(48009, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_0 like Mac OS X; sl-SI) AppleWebKit/533.48.4 (KHTML, like Geck', 'Ea dolores aliquam et tempore iusto. Ratione accusantium aliquam libero eum molestiae. Ex eum quisquam numquam velit iure porro sed.', '1994-07-26 02:20:28'),
(48244, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_6_0 rv:5.0; en-US) AppleWebKit/534.21.4 (KHTML, like Gecko) ', 'Et quo quas minus quia voluptas ut. Quo accusantium quisquam architecto architecto quia quo. Quia sit recusandae iure qui soluta ut non.', '2024-11-11 11:45:45');
INSERT INTO `categories` (`id`, `name`, `description`, `created_at`) VALUES
(48409, 'Mozilla/5.0 (Windows CE) AppleWebKit/5342 (KHTML, like Gecko) Chrome/15.0.861.0 Safari/5342', 'Provident voluptatem aliquam et error magni dolor. Fugit ipsum rerum quo sed voluptate delectus dolor. Fuga odio sint cum illo odit. Molestiae unde qui ullam aliquid non error tenetur. Fugiat et non cupiditate quam dolorem ut quia corporis.', '1982-11-03 22:24:40'),
(48448, 'Opera/9.30 (X11; Linuxi686; sl-SI) Presto/2.9.165 Version/12.00', 'Sunt dolorem aut maiores explicabo recusandae. Ut impedit molestias maiores odio quae. Enim et et qui rem consectetur nam. Et excepturi id alias mollitia et qui natus voluptatem.', '1999-07-13 11:00:07'),
(48496, 'Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/532.10.1 (KHTML, like Gecko) Version/4.1 Safari', 'Assumenda vel enim ad et exercitationem consequatur ab consectetur. Omnis temporibus aperiam repellat praesentium rerum.', '2015-05-28 17:45:45'),
(48631, 'Opera/8.50 (X11; Linuxx86_64; en-US) Presto/2.9.172 Version/12.00', 'Maiores saepe necessitatibus voluptas aut. Ipsam qui voluptates eius perspiciatis facilis.', '1976-07-11 14:20:38'),
(48995, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.1)', 'Deleniti autem officia iste pariatur labore qui qui. Nobis cupiditate ex nesciunt.', '1992-08-11 08:57:56'),
(51206, 'Mozilla/5.0 (Windows NT 5.01; en-US; rv:1.9.2.20) Gecko/20151231 Firefox/8.0', 'Iusto quos repudiandae asperiores et. Debitis dicta voluptatum qui consequatur. Neque debitis ullam omnis sint eius molestiae. Nihil vero omnis culpa voluptatibus numquam nobis accusamus.', '1992-01-12 22:16:24'),
(52287, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_9) AppleWebKit/5342 (KHTML, like Gecko) Chrome/14.0.8', 'Quasi commodi ipsam odit quibusdam sed consequatur. Animi qui amet sunt fuga omnis. Totam sint cumque praesentium iure corrupti et in.', '2014-02-01 03:40:54'),
(52329, 'Opera/9.34 (Windows NT 5.0; en-US) Presto/2.9.179 Version/12.00', 'Non occaecati voluptas sed. Aliquam est iure et alias. Nulla quas quam dolores quia ut possimus. Et id perferendis repellendus illo deleniti sit.', '1976-09-25 04:54:01'),
(52984, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 4.0; Trident/5.1)', 'Ab quia est facilis ad. Iusto rerum aut quisquam non perferendis facilis. Non eos quis dolorem expedita non eum ducimus. Quod nisi quidem quis voluptatem cupiditate. Aut quia rem ea sunt incidunt eos dolor aut.', '2001-06-23 08:07:42'),
(53355, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_7_8 rv:2.0; en-US) AppleWebKit/532.36.3 (KHTML, like Ge', 'Consequatur possimus eaque debitis maiores ratione reprehenderit. Voluptates facilis inventore a odit qui officiis unde nesciunt. Odio omnis est et voluptatem autem. Exercitationem laudantium delectus assumenda aut quia.', '1996-07-18 11:52:54'),
(53557, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_2) AppleWebKit/5350 (KHTML, like Gecko) Chrome/15.0.829.', 'Sequi ipsa quas sint consequatur illo quae vitae. Omnis ut recusandae ducimus maiores quaerat rem. Eum adipisci sed eos sit sed.', '1982-02-03 15:37:55'),
(53706, 'Mozilla/5.0 (Windows NT 5.0; sl-SI; rv:1.9.0.20) Gecko/20120921 Firefox/3.6.1', 'Sint nostrum odio dolores reiciendis hic suscipit eligendi suscipit. Sunt debitis officia quod voluptas dolorem quae.', '1984-08-13 13:30:13'),
(55472, 'Opera/9.34 (Windows NT 4.0; en-US) Presto/2.9.173 Version/12.00', 'Unde laborum quis provident voluptas. Consequatur rerum eveniet iusto suscipit. Iste vel vel quae voluptas. Est sint eum doloremque dolor et optio.', '1972-06-13 19:02:25'),
(55772, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_1 rv:3.0; sl-SI) AppleWebKit/532.14.1 (KHTML, like Gecko', 'Veritatis et voluptas laudantium asperiores. Doloribus dolore eaque placeat magnam. Dolorum animi aut omnis aut dolores.', '1977-07-28 06:32:34'),
(57239, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows 95; Trident/4.1)', 'Voluptatibus suscipit illo consequuntur et sed. Voluptatem praesentium numquam explicabo eos facilis aliquid aut. Et harum molestiae et voluptatem assumenda.', '1976-04-13 02:55:35'),
(58283, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_1 like Mac OS X; en-US) AppleWebKit/532.19.6 (KHTML, like Geck', 'Est quos nemo doloribus dicta iusto dignissimos. Aliquid excepturi temporibus quia. Inventore dolorum laudantium sed sed doloremque. Eveniet voluptatibus quia delectus omnis quo error.', '1973-01-09 19:46:43'),
(58382, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_5_2 rv:5.0) Gecko/20221104 Firefox/4.0', 'Quisquam excepturi asperiores quia ut rerum repellat. Voluptates voluptatem quas doloremque iste sed eum. Eos sint perspiciatis magni sint amet voluptas neque.', '2015-02-12 04:59:58'),
(58467, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 6.1; Trident/5.0)', 'Qui iure saepe eligendi fugiat quibusdam. Ex amet placeat sint quod ut magnam excepturi. Omnis odio doloribus quam sit. Veritatis et provident quos ipsa sit accusantium amet voluptatem. Et necessitatibus qui vitae ipsa exercitationem quibusdam in in.', '2016-10-01 15:33:50'),
(58476, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows 95; Trident/3.1)', 'Dolorem consectetur velit perspiciatis iusto numquam pariatur ducimus. Voluptatibus aut quo ex fugiat et. Vel libero est molestias magnam quo et quas quia.', '1988-11-07 04:13:13'),
(58505, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_8 rv:2.0) Gecko/20170313 Firefox/3.6.12', 'Ut harum esse voluptas non quia aut. Modi quo accusantium fugiat voluptatem. Natus ipsam labore eaque sequi doloribus corrupti minima.', '2019-11-13 16:13:27'),
(58551, 'Opera/9.30 (X11; Linuxx86_64; sl-SI) Presto/2.9.172 Version/10.00', 'Doloremque voluptatibus eaque tempore ea maxime. Minima omnis quia blanditiis sunt minima est. Soluta blanditiis aut voluptatem consequatur aliquam rem maxime. Et ab cumque dolorem officia autem non.', '1993-06-14 12:38:08'),
(59314, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 5.01; Trident/3.1)', 'In labore aliquid repellat inventore alias voluptatem. Perferendis et provident alias labore aut omnis distinctio. Velit fugit quas soluta sed tempore voluptas.', '1993-08-09 03:07:53'),
(60657, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_4) AppleWebKit/5352 (KHTML, like Gecko) Chrome/13.0.8', 'Et doloremque quia laboriosam accusantium. Quisquam eos voluptatem qui numquam voluptatem quia eos quaerat. Nemo officiis voluptatem distinctio et sint voluptatibus voluptas. Velit aperiam culpa in.', '2025-02-27 16:25:11'),
(62130, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_4 rv:5.0) Gecko/20171105 Firefox/3.8', 'Est distinctio enim et ut aliquid. Quam dolore et corrupti. Optio aut sed quo quia voluptas.', '2021-03-08 05:29:11'),
(64695, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/5.0)', 'Et ut maiores maxime ratione at praesentium. Et velit repellat inventore ea non vel consequatur. Totam vel rem suscipit nihil. Ab rerum ut corrupti voluptas.', '2012-08-06 21:53:11'),
(65429, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.01; Trident/3.0)', 'Illo eveniet rem eligendi ipsum enim. Ut deleniti sed eaque non cum.', '2021-04-29 17:20:29'),
(65514, 'Mozilla/5.0 (Windows NT 4.0) AppleWebKit/5362 (KHTML, like Gecko) Chrome/15.0.816.0 Safari/5362', 'Voluptatem amet laudantium aut minus. Distinctio dolore officiis deleniti et sit rem. Iste assumenda harum non molestias et deserunt molestias.', '1974-11-20 09:59:37'),
(66299, 'Mozilla/5.0 (Windows NT 5.2; sl-SI; rv:1.9.2.20) Gecko/20151018 Firefox/3.8', 'Consequatur natus excepturi autem distinctio asperiores assumenda aliquid. Labore est qui vitae ipsum magnam saepe. Temporibus qui exercitationem laboriosam et enim explicabo. Amet architecto modi dolores aut non.', '2023-12-17 18:16:32'),
(66956, 'Mozilla/5.0 (Windows 98; Win 9x 4.90; en-US; rv:1.9.0.20) Gecko/20140809 Firefox/3.8', 'Soluta qui vitae deserunt et nostrum doloremque ut. Nobis dolorum debitis non ullam ut. Incidunt deserunt aut ea.', '1970-04-08 16:05:31'),
(67579, 'Opera/9.86 (X11; Linuxx86_64; en-US) Presto/2.9.190 Version/12.00', 'Ex quia iusto itaque illum et amet. Nemo quaerat id dolorum nihil et. Ab dicta deserunt et sunt possimus aperiam illo. Repellat sed quia harum modi consectetur ipsam sed nemo.', '1992-09-09 00:52:16'),
(67700, 'Opera/8.86 (Windows NT 5.1; en-US) Presto/2.9.160 Version/10.00', 'Dolorem nemo beatae praesentium hic cumque assumenda. Et quia dolorum quos corporis.', '1978-02-14 16:35:44'),
(68380, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows 95; Trident/5.0)', 'Optio est magni harum ut exercitationem quo. Aut voluptatibus sunt et aut porro quo corrupti. Tempora enim error aut autem cupiditate asperiores.', '2012-12-01 08:54:54'),
(69331, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5360 (KHTML, like Gecko) Chrome/14.0.868.0 Safari/5360', 'Eum neque qui et quos et ex. Debitis nihil est ut eligendi odio sunt. Nesciunt vero similique sit dolore rem ad eveniet. Quo voluptas est a quaerat.', '2006-07-03 06:11:10'),
(69812, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows 95; Trident/5.1)', 'Blanditiis omnis voluptas quia enim. Asperiores inventore reprehenderit voluptatem sit. Hic beatae aut nulla ea nulla in eius. Quo molestiae dolore sit qui id omnis.', '1998-05-27 06:29:19'),
(70991, 'Mozilla/5.0 (Windows 98) AppleWebKit/5361 (KHTML, like Gecko) Chrome/14.0.828.0 Safari/5361', 'Aliquid commodi iste et qui. Ducimus accusantium autem rerum error tempore sequi velit eos. Praesentium odit quas aspernatur dolores et laudantium.', '1970-02-21 05:50:55'),
(72018, 'Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/532.34.7 (KHTML, like Gecko) Version/4.0.3 Safa', 'Quia magnam ab occaecati dolorem quam sit. Autem facilis facere deserunt eum omnis. Omnis soluta necessitatibus ut rerum iste.', '1972-05-09 03:20:06'),
(72377, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5360 (KHTML, like Gecko) Chrome/14.0.852.0 Safari/5360', 'Cumque minima ab eum voluptatibus. Consequatur praesentium est commodi vero libero voluptatem. Vitae aut rerum voluptas a explicabo aut provident. Sapiente pariatur aut qui repudiandae placeat cum qui.', '2018-08-26 12:19:22'),
(72462, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_0 like Mac OS X; sl-SI) AppleWebKit/534.44.5 (KHTML, like Geck', 'Id eos eum minus quisquam laboriosam. Voluptas quo inventore sit eligendi voluptatum et. Sint recusandae optio qui accusantium. Id explicabo non ea voluptas deserunt. Rerum quia et cumque.', '1970-04-13 18:59:27'),
(72846, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_6_8) AppleWebKit/5360 (KHTML, like Gecko) Chrome/14.0.863.0 ', 'Aspernatur nesciunt aut fugiat ut. Consequuntur dolorem ex veritatis eveniet ullam quam sit quasi. Et atque in quos nihil dolore temporibus. Nesciunt iure fugiat aut molestiae ad voluptatem error.', '1974-04-09 05:24:15'),
(73681, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_7_3 rv:3.0) Gecko/20220807 Firefox/13.0', 'In rem tempore aut corporis eum qui. At adipisci distinctio porro at animi explicabo. Velit eos ea dolor enim et eligendi.', '2010-01-04 04:50:25'),
(74163, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows CE; Trident/5.0)', 'Vel dignissimos eaque animi cumque voluptatum ab. Dolore omnis quo sint soluta rerum in sed. Consectetur placeat nobis dolores quia molestiae culpa. Possimus aliquid praesentium nihil et dicta.', '1992-10-12 17:50:44'),
(74603, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_2 rv:5.0; sl-SI) AppleWebKit/534.8.6 (KHTML, like Gec', 'Minus quidem consequatur nesciunt voluptatibus libero. Reiciendis maxime explicabo accusantium perferendis omnis eos et non. Cupiditate ad nobis libero exercitationem qui qui eveniet. Nobis omnis quia repellat et nesciunt aliquid modi.', '1987-05-28 23:04:46'),
(75769, 'Mozilla/5.0 (X11; Linuxi686; rv:5.0) Gecko/20100831 Firefox/3.8', 'Mollitia et aperiam totam modi nam similique. Iusto consequatur voluptate nesciunt omnis soluta placeat. In consequatur dolores amet dicta. Laborum aliquid exercitationem neque enim aliquam dicta.', '1998-01-25 13:26:23'),
(75963, 'Opera/9.10 (X11; Linuxi686; sl-SI) Presto/2.9.182 Version/10.00', 'Velit quasi sunt dolore. Impedit tempora esse et asperiores quasi et. Sed soluta facere vel quasi ab deleniti laborum tempora. Cumque similique quod voluptatem.', '1970-08-04 14:22:00'),
(76291, 'Opera/8.10 (Windows 95; sl-SI) Presto/2.9.184 Version/11.00', 'Qui accusamus eius qui totam velit enim. Sed sunt ad et placeat quaerat. Provident nostrum necessitatibus quo laboriosam et nihil.', '2014-05-01 21:39:37'),
(76453, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows 98; Trident/5.1)', 'Quam officia dolores ullam rem. Suscipit eius nulla rem tempora corrupti aut exercitationem provident. Reprehenderit natus totam quod asperiores.', '1996-05-06 07:49:27'),
(76619, 'Mozilla/5.0 (Windows NT 5.2; en-US; rv:1.9.0.20) Gecko/20250113 Firefox/12.0', 'Quaerat sed ut sint laborum. Aut aut eveniet sapiente veritatis aliquid. Omnis nobis nemo sapiente asperiores nostrum. Amet corrupti odit qui.', '1987-11-26 07:44:40'),
(76648, 'Mozilla/5.0 (Windows 95) AppleWebKit/5360 (KHTML, like Gecko) Chrome/15.0.822.0 Safari/5360', 'Doloribus culpa labore sint dolor. Quo architecto blanditiis illum iusto nihil sapiente qui enim. Perspiciatis totam minima minus ipsum ullam ratione architecto.', '2005-01-21 17:34:27'),
(76712, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_8_5 rv:6.0; en-US) AppleWebKit/531.34.1 (KHTML, like Ge', 'In est expedita sapiente eos. Necessitatibus est quae est eius atque eveniet consequatur. Repellat dicta et omnis.', '2013-12-14 01:54:06'),
(76719, 'Opera/9.48 (Windows NT 5.0; en-US) Presto/2.9.188 Version/10.00', 'Mollitia doloremque asperiores qui eius magnam quod. Est nam modi asperiores neque esse. Et voluptates explicabo inventore.', '2010-12-04 08:20:48'),
(77199, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.1; Trident/3.0)', 'Necessitatibus beatae dolor explicabo ut. Dolore unde sed harum odio perferendis ut quia quas. Ab illo necessitatibus eius maxime. Id autem qui dolorum nostrum repellat repellat magni harum.', '1999-01-28 00:01:21'),
(77477, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.0; Trident/5.0)', 'Et ipsum quis magni eaque minus iusto blanditiis. Doloremque reprehenderit quae ut ut qui consequuntur. Corporis perspiciatis id corporis ratione non id.', '2018-07-18 08:48:56'),
(82297, 'Opera/9.91 (Windows CE; sl-SI) Presto/2.9.185 Version/10.00', 'Ad eum harum rerum exercitationem praesentium maiores. Voluptatum ut doloremque cumque eveniet distinctio. Qui sunt enim et sit reiciendis. Dolores quia consequatur et non ut qui.', '1996-07-05 04:56:06'),
(82961, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_7_0) AppleWebKit/5350 (KHTML, like Gecko) Chrome/14.0.8', 'Excepturi praesentium eum et et unde qui sunt. Laborum eum aliquam maiores ab sed et minus. Est nihil fuga consequatur nesciunt magnam inventore quos.', '2006-07-05 16:52:14'),
(83638, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/5.0)', 'Quia natus harum maxime eveniet. Laudantium cumque odit sunt. Eveniet consequatur a vel provident. Explicabo maxime ut ab suscipit. Nihil eos eos autem quia rerum quibusdam.', '1985-01-10 19:40:47'),
(84564, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_5 rv:4.0) Gecko/20110108 Firefox/3.8', 'Quia reprehenderit quia aliquid facere voluptatum. Deleniti explicabo dicta delectus eaque nemo.', '1970-01-05 15:39:36'),
(84722, 'Mozilla/5.0 (Windows CE; en-US; rv:1.9.0.20) Gecko/20150919 Firefox/7.0', 'Beatae soluta earum sequi qui. Quod fuga asperiores quibusdam unde. Aut quia quis sequi rerum dolore. Ducimus porro iste dolorem eos sed nesciunt ducimus animi.', '2003-02-01 15:43:33'),
(84936, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_8_6) AppleWebKit/5330 (KHTML, like Gecko) Chrome/15.0.899.0 ', 'Optio voluptas similique distinctio eaque error deserunt. Saepe praesentium consectetur unde nihil et minus. Sequi laboriosam tenetur qui natus vel rem. Nihil sequi labore qui doloremque eos quas non odio. Quis aspernatur veritatis voluptatum quia reprehenderit mollitia harum.', '1995-08-01 05:14:52'),
(85273, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows 98; Win 9x 4.90; Trident/3.1)', 'Quia pariatur veniam delectus quia. Deleniti blanditiis mollitia error molestiae molestiae distinctio doloremque. Deserunt vitae autem quia iste. Corrupti aut molestiae a alias non assumenda ut.', '2016-06-02 08:58:32'),
(86328, 'Mozilla/5.0 (Windows 95; en-US; rv:1.9.2.20) Gecko/20141124 Firefox/3.6.6', 'Esse qui nihil molestiae eveniet sed suscipit ad. Provident aperiam vero ullam ea porro commodi. Earum aperiam ut debitis.', '1996-08-04 08:03:24'),
(86489, 'Mozilla/5.0 (Windows CE) AppleWebKit/5331 (KHTML, like Gecko) Chrome/13.0.892.0 Safari/5331', 'Sed et vitae iste itaque quo minus. Vero officia iste ipsum eos nulla eum voluptas. Dolorum alias ad cum deserunt.', '1972-09-18 13:40:06'),
(86589, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5352 (KHTML, like Gecko) Chrome/15.0.887.0 Safari/5352', 'Beatae amet possimus sed cumque. Similique odit quo non qui et sit culpa.', '1997-06-09 23:03:05'),
(87463, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows 98; Win 9x 4.90; Trident/5.0)', 'Quibusdam ipsum et atque consequatur odio reiciendis illo. Non ut possimus sed. Soluta rerum eaque repellendus.', '2015-04-10 23:15:57'),
(88202, 'Opera/9.71 (X11; Linuxi686; en-US) Presto/2.9.173 Version/12.00', 'Eos et aut aspernatur corporis sit sed. Voluptates error neque quam rerum quae dolor. Laboriosam animi et sit soluta sed blanditiis.', '1999-10-06 22:18:29'),
(88432, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_7_6 rv:4.0) Gecko/20160712 Firefox/3.6.20', 'Nostrum enim alias aspernatur officiis voluptatibus adipisci expedita. Veritatis consequatur qui iste velit blanditiis consequatur reiciendis. Sunt et impedit adipisci ipsum.', '1975-12-20 13:02:42'),
(89687, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5320 (KHTML, like Gecko) Chrome/15.0.845.0 Safari/5320', 'Veniam voluptatum id dolorum itaque. Rerum qui fugiat excepturi alias. Aliquid atque optio quisquam dolores eligendi. A ipsa velit magnam rem iste.', '2002-02-26 22:25:26'),
(90679, 'Mozilla/5.0 (Windows NT 6.0) AppleWebKit/5340 (KHTML, like Gecko) Chrome/14.0.833.0 Safari/5340', 'Eos aut aut est vel. Quia sit ex porro nihil temporibus quidem. Debitis repudiandae vero dolorum architecto optio ad natus. Illum impedit natus ad quae.', '1976-03-06 22:43:48'),
(91049, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_0 like Mac OS X; en-US) AppleWebKit/532.19.3 (KHTML, like Geck', 'Voluptate sunt tempore aut. Ducimus dolores porro qui. Laudantium nemo dolor temporibus veniam repellat id quia.', '2022-10-08 15:59:43'),
(92689, 'Opera/8.93 (X11; Linuxi686; sl-SI) Presto/2.9.163 Version/11.00', 'Consequatur veritatis autem cupiditate quo dignissimos quae ratione molestiae. Magnam unde dolor dolor eos aut sed provident. Dolorem quaerat incidunt nobis beatae explicabo nesciunt magnam. Repellat id laborum voluptatem asperiores.', '2004-09-16 03:14:15'),
(93077, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/3.0)', 'Odit nobis impedit vitae vitae nemo ipsa cumque maxime. Facere nostrum quaerat ex voluptas eveniet provident. Facere perferendis voluptatem ex accusantium et. Laudantium vel non minima aut quaerat dolorem.', '1988-04-04 04:44:57'),
(93915, 'Opera/9.57 (Windows NT 5.01; sl-SI) Presto/2.9.185 Version/12.00', 'Et est molestiae aut atque ea. Iste ullam culpa doloribus ut quod totam et. Fugit est eveniet modi numquam distinctio cumque voluptas est. Vel in quia reprehenderit quibusdam laboriosam recusandae ipsa.', '2014-07-16 13:46:29'),
(93964, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_7_2) AppleWebKit/5360 (KHTML, like Gecko) Chrome/14.0.8', 'Ea architecto quis et ipsa enim quos exercitationem. Totam quaerat sed ducimus nam ex fuga rem atque. Fugit distinctio aut quis distinctio ullam esse.', '1991-06-02 21:33:15'),
(94093, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.01; Trident/4.1)', 'Laborum voluptas vel facilis libero id. Fugiat odio voluptas odit non voluptatem ut est. Temporibus quasi voluptate neque impedit facere ab atque. Sit fugit qui ex sed enim fuga. Enim et unde et cum dignissimos enim et.', '1982-11-04 01:50:25'),
(94307, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_8_9 rv:3.0) Gecko/20221222 Firefox/3.6.15', 'Nesciunt quisquam vel illum ea perferendis. Et assumenda voluptas consequatur cupiditate aut et id. Optio architecto rerum ut. Dolores voluptas quod vero inventore adipisci occaecati sit. Suscipit asperiores eum et.', '1985-01-10 09:45:30'),
(95400, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_6_9) AppleWebKit/5362 (KHTML, like Gecko) Chrome/15.0.818', 'Natus aliquam qui in beatae. Eum est deleniti alias enim. Aspernatur odit velit iure tempora ut qui corrupti. Error odio a placeat et deserunt.', '1977-06-03 10:45:27'),
(96029, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5350 (KHTML, like Gecko) Chrome/15.0.829.0 Safari/5350', 'Dolor et deleniti vero eligendi et et quae. Amet quos voluptatibus dolorem aut nostrum molestiae. Quae nihil non necessitatibus quidem ex sit libero.', '2017-01-04 11:33:34'),
(96633, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_0 like Mac OS X; sl-SI) AppleWebKit/533.42.3 (KHTML, like Geck', 'Impedit ab quibusdam ut nobis aliquam ea perferendis. Sequi perferendis aut id aliquam beatae ut praesentium. Est ut eveniet assumenda eveniet.', '2016-04-14 15:16:46'),
(96994, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_5_4 rv:5.0; sl-SI) AppleWebKit/532.17.1 (KHTML, like Gecko) ', 'Repudiandae deleniti dolores sunt consequatur mollitia consequatur soluta. Id veritatis enim natus animi. Molestias reiciendis facere praesentium sequi. Iusto officia nemo asperiores praesentium. Ut tempora aut aliquam vero eum sunt.', '2010-04-15 22:03:29'),
(97618, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_3 like Mac OS X; en-US) AppleWebKit/534.47.7 (KHTML, like Geck', 'Est amet aliquam ut est repellendus. Reiciendis debitis sed laboriosam consequatur. Dolorum dicta ea omnis corrupti praesentium ea explicabo.', '2006-12-19 07:46:11'),
(97840, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5330 (KHTML, like Gecko) Chrome/15.0.816.0 Safari/5330', 'Dolores delectus et molestias veniam. Officiis dignissimos blanditiis ea nihil at hic et. Consequuntur quis laboriosam fugit. Nihil dicta recusandae quidem. Quod sit ut excepturi aliquid aliquid sint pariatur.', '2019-05-24 02:34:49'),
(99156, 'Mozilla/5.0 (Windows NT 5.2; en-US; rv:1.9.0.20) Gecko/20111009 Firefox/3.6.8', 'Quam exercitationem nam aut deserunt. Placeat beatae nulla voluptatibus similique commodi autem qui unde. Dolorum quibusdam similique natus error qui minus ut.', '2019-12-06 21:15:36'),
(99184, 'Mozilla/5.0 (Windows NT 6.0; en-US; rv:1.9.2.20) Gecko/20110805 Firefox/3.8', 'Soluta aspernatur est qui dolor rerum quaerat dolor. Cumque illum nesciunt iure quisquam laboriosam. Culpa perspiciatis provident similique dicta voluptatem. Praesentium vel earum nulla sit maxime non totam saepe.', '2022-08-23 21:08:21'),
(99770, 'Mozilla/5.0 (Windows CE; en-US; rv:1.9.2.20) Gecko/20221216 Firefox/9.0', 'Dolores ullam eos id nihil fuga rerum commodi. Totam repellendus pariatur placeat mollitia aut. Vero accusamus doloribus fugiat cum reiciendis. Dicta totam placeat dignissimos eum est soluta sapiente. Reiciendis et autem qui enim.', '2013-12-09 10:23:26'),
(99787, 'Opera/9.93 (X11; Linuxi686; sl-SI) Presto/2.9.184 Version/10.00', 'Error aperiam qui ut exercitationem maxime sint ex. Aliquam deleniti possimus expedita et autem voluptas aut et. Ea omnis quis nesciunt qui. Itaque architecto quia sint voluptas.', '1984-01-25 20:28:15'),
(99918, 'Mozilla/5.0 (X11; Linuxi686; rv:7.0) Gecko/20110728 Firefox/3.6.17', 'Sed sit et ea saepe laborum inventore in culpa. Molestiae libero et veniam culpa. Repellendus quaerat harum eius ea ut et eius maxime.', '2020-10-03 12:14:45'),
(107077, 'Opera/8.54 (Windows CE; en-US) Presto/2.9.162 Version/12.00', 'Et temporibus ipsam cupiditate ullam qui. Magnam pariatur excepturi aliquid odio.', '2005-10-02 10:59:47'),
(111193, 'Opera/8.90 (X11; Linuxi686; sl-SI) Presto/2.9.169 Version/11.00', 'Numquam harum sequi ab repellendus suscipit. Repellendus iste aut sequi nisi qui vel sunt autem. Consequatur fuga sit perspiciatis illo.', '2000-07-23 17:43:31'),
(115877, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0)', 'At repellat magnam adipisci sed omnis enim voluptatibus. Deserunt aut itaque non tempore nihil fugiat numquam fugiat. Quia aspernatur dolores molestias quae. Velit dolores dolor alias enim voluptatem assumenda.', '1996-07-26 11:57:42'),
(124893, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_9 rv:5.0; sl-SI) AppleWebKit/534.3.5 (KHTML, like Gecko)', 'Non itaque ducimus illo ullam voluptates. Perspiciatis velit doloremque et recusandae. Dolores quia architecto non neque.', '1985-11-01 07:59:25'),
(128153, 'Opera/8.26 (X11; Linuxi686; sl-SI) Presto/2.9.190 Version/10.00', 'Voluptatibus perspiciatis nulla ea necessitatibus. Odit a sed repudiandae a et nihil. Nam assumenda et cum rem. Est praesentium nisi itaque reiciendis facere ut.', '2008-12-04 18:23:40'),
(131347, 'Opera/8.12 (X11; Linuxx86_64; en-US) Presto/2.9.179 Version/10.00', 'Tempore iusto eos ex cupiditate voluptas. Ea corrupti dicta aperiam quo et facere. Quia sunt blanditiis vel dolores praesentium occaecati consequatur. Voluptatem natus voluptate corrupti aut aut animi odio.', '2000-05-31 16:30:06'),
(137870, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows 98; Win 9x 4.90; Trident/3.1)', 'Ut beatae voluptatibus voluptas quidem quia consequuntur. Vero amet at dolorem culpa. Non voluptatem enim sit numquam. Non accusamus officia tenetur repellendus unde.', '2003-03-07 21:48:39'),
(143572, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.2; Trident/5.1)', 'Eveniet aut natus provident nam molestiae voluptatem. Consequatur et distinctio necessitatibus voluptas est.', '1983-02-04 13:07:01'),
(153547, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_2 like Mac OS X; sl-SI) AppleWebKit/531.43.2 (KHTML, like Geck', 'Dolorem fugit accusamus minus ut voluptate temporibus. Doloribus et et itaque. Totam totam quia consectetur dolorem qui veritatis vel. Placeat fugit ut reiciendis quae at magnam aliquam.', '2014-07-28 00:16:22'),
(165408, 'Opera/9.22 (Windows NT 5.1; en-US) Presto/2.9.163 Version/10.00', 'Sit non vel ipsum. Commodi totam ex eos est voluptas quo autem. Voluptas reprehenderit suscipit repellendus molestiae voluptatem quam sit perspiciatis. Blanditiis est nostrum nam nostrum.', '2000-12-08 20:28:53'),
(181222, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_0 like Mac OS X; sl-SI) AppleWebKit/532.39.7 (KHTML, like Geck', 'Dolor enim provident dolorem fuga. Et eius ipsum ipsa est. Quia saepe rerum commodi nesciunt ipsum omnis ipsum. Saepe facilis omnis vel dolores est molestiae quia.', '1980-10-18 17:47:03'),
(185313, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_1 like Mac OS X; en-US) AppleWebKit/533.10.7 (KHTML, like Geck', 'Qui est asperiores cupiditate ut. Laudantium accusamus eos explicabo dignissimos. Repudiandae quas aspernatur ipsa repudiandae aut praesentium impedit ipsa. Earum modi non est recusandae sunt.', '2021-05-27 12:00:38'),
(187371, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.2; Trident/3.0)', 'Qui et dolores quaerat animi et. Rem maiores quod excepturi reprehenderit. Vitae quia et autem laudantium aliquid rerum in. Rerum ducimus in rerum velit ut.', '1999-03-25 10:27:26'),
(197881, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_1 rv:4.0) Gecko/20170108 Firefox/3.8', 'Nesciunt qui quisquam a tempora est optio sed. Illo a autem voluptate et. Non in error repellendus ut aut illum.', '1985-04-11 09:34:53'),
(202080, 'Mozilla/5.0 (Windows NT 6.0; sl-SI; rv:1.9.2.20) Gecko/20130921 Firefox/3.8', 'Sint voluptatem ut distinctio quia. Consequatur corporis vitae nulla dolorem. Tempora quod saepe aut placeat. Molestias praesentium officiis facere nostrum.', '2011-09-05 01:19:52'),
(204050, 'Mozilla/5.0 (X11; Linuxx86_64; rv:6.0) Gecko/20131015 Firefox/3.6.5', 'Labore sint omnis at aut autem eum voluptas. In consequatur nobis voluptatem inventore maiores ut voluptatum. Ex aliquid dolorem beatae dolor. Ab tempora eaque repudiandae.', '2024-11-01 05:05:48'),
(213161, 'Mozilla/5.0 (Windows NT 6.2; sl-SI; rv:1.9.1.20) Gecko/20230513 Firefox/3.6.16', 'Expedita illo eligendi architecto quo sint corrupti est sint. Velit sunt non et consequatur. Minima excepturi occaecati enim distinctio sapiente. Eligendi quos eos et rem. Hic ea expedita id consequatur quam voluptatem.', '1980-06-27 22:08:45'),
(227740, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_7_6) AppleWebKit/5360 (KHTML, like Gecko) Chrome/13.0.879.0 ', 'Ut eos adipisci voluptas velit totam ut et ut. Vero aut at saepe omnis. Veritatis ut voluptate rerum. Aut ipsum et id.', '1994-06-24 01:57:34'),
(238582, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5322 (KHTML, like Gecko) Chrome/14.0.807.0 Safari/5322', 'Modi odio ipsam et nam eum. Suscipit qui quam rerum et eveniet consectetur. Et aut eius itaque dolore possimus.', '2004-10-14 17:36:46'),
(247958, 'Opera/8.34 (X11; Linuxx86_64; sl-SI) Presto/2.9.164 Version/10.00', 'Eum accusantium magnam nostrum quisquam vel. Culpa quas enim hic sed et ut. Quibusdam atque in quia rerum voluptatem. Voluptatum labore debitis velit in aliquam.', '1985-11-28 04:49:46'),
(249137, 'Opera/9.26 (X11; Linuxi686; en-US) Presto/2.9.168 Version/12.00', 'Ut voluptatem nihil aperiam ut quod sit rerum vitae. Repellat voluptatem id ducimus quia veritatis pariatur. Rerum exercitationem autem ducimus. Sed voluptate deserunt quis voluptate.', '1996-09-01 21:10:09'),
(257949, 'Opera/8.51 (X11; Linuxx86_64; en-US) Presto/2.9.181 Version/12.00', 'Aspernatur nemo aut consequatur aperiam voluptatem numquam. Sit corporis tempore saepe laborum enim. Quisquam dolor pariatur ipsam aut. Consequatur officiis voluptatem autem qui qui nemo unde.', '1990-06-04 10:59:53'),
(258025, 'Mozilla/5.0 (Windows NT 5.01; en-US; rv:1.9.1.20) Gecko/20210829 Firefox/3.6.17', 'Illum dolores iusto et. Dolores sunt qui sunt itaque ut eaque architecto ut. Quos ratione enim et ut ut sed quae corporis. Modi nihil praesentium commodi quia aliquam et.', '2001-08-10 16:53:28'),
(265063, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.2; Trident/5.1)', 'Maiores cumque nihil quam iste et illum. Consequuntur et rerum nihil. Dolores fugit commodi quo quidem quia. In repudiandae sed id culpa.', '2018-10-20 23:51:44'),
(270686, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_6_8 rv:4.0; en-US) AppleWebKit/534.48.4 (KHTML, like Gecko) ', 'Facilis alias expedita est sit. Dignissimos ea odio ullam eveniet maiores labore. Quod totam magni et repellendus eaque qui alias.', '2013-10-08 10:15:50'),
(280636, 'Opera/8.95 (X11; Linuxx86_64; en-US) Presto/2.9.164 Version/12.00', 'Ut quae illum tempore. Omnis dolor inventore mollitia velit iure. Consequatur aut consequatur exercitationem aut dolores. Dolorum voluptatem similique aut sunt et deserunt nisi quaerat.', '2006-04-26 17:22:06'),
(292795, 'Opera/8.41 (X11; Linuxx86_64; en-US) Presto/2.9.164 Version/12.00', 'Quia quasi repudiandae soluta quae. Minus quae qui ratione dolor praesentium. Magnam sed dolorum est accusamus.', '1971-12-28 04:26:47'),
(293644, 'Mozilla/5.0 (Windows NT 6.1; sl-SI; rv:1.9.0.20) Gecko/20120203 Firefox/3.6.10', 'Nostrum sit qui tempora consectetur molestiae laboriosam officiis. Dolore quidem laborum adipisci molestiae amet rerum. Sed tenetur officiis quos expedita at.', '2015-08-08 07:29:26'),
(300049, 'Opera/9.10 (Windows NT 5.1; en-US) Presto/2.9.187 Version/11.00', 'Quaerat ut pariatur odio quis. Explicabo cumque alias debitis sit quas sed. Commodi modi et id et et rem nulla. Omnis et et non beatae at corporis.', '1994-03-31 05:29:33'),
(311174, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0; Trident/5.1)', 'Ea doloribus culpa dicta quia. Voluptatem ducimus et cupiditate perspiciatis aspernatur eligendi in. Cum consectetur nam eaque aliquid.', '2022-06-09 09:06:18'),
(320725, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5340 (KHTML, like Gecko) Chrome/15.0.863.0 Safari/5340', 'Nihil delectus voluptas neque minus vitae ducimus. Ex enim earum impedit et. Et qui aut aspernatur ad explicabo. Et quibusdam fugit rem ducimus ipsa voluptatem.', '2001-08-30 23:47:24'),
(324356, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5361 (KHTML, like Gecko) Chrome/14.0.834.0 Safari/5361', 'Quo ut molestiae et id quae autem. Sapiente eum numquam natus facilis. Voluptatem aut provident velit molestiae non. Ratione tenetur velit non quo cumque soluta qui incidunt.', '1979-06-30 08:15:43'),
(324507, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_2 like Mac OS X; en-US) AppleWebKit/531.5.4 (KHTML, like Gecko', 'Autem ab consectetur et neque nostrum. Quis voluptate in laboriosam sit consectetur rerum et. Consequatur est deserunt dicta officia hic et. Exercitationem ut voluptatem laboriosam.', '1985-07-21 05:20:49'),
(336356, 'Mozilla/5.0 (Windows NT 4.0) AppleWebKit/5351 (KHTML, like Gecko) Chrome/14.0.858.0 Safari/5351', 'Explicabo doloribus maiores veritatis non. Nemo fugiat doloremque adipisci officiis repellendus. Fuga quo et quasi. Libero deleniti quis explicabo id deleniti fugit. Earum natus repellendus id ipsum natus et consequatur.', '2009-03-31 18:51:08'),
(337122, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.0; Trident/5.1)', 'Quis vel qui totam eveniet. Dolorem dolore assumenda exercitationem distinctio. Facilis voluptates iste amet corrupti fugiat optio animi. Vitae officia veniam non dolorem blanditiis aperiam quasi.', '2012-06-15 16:25:50'),
(339119, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_7_7 rv:4.0; sl-SI) AppleWebKit/535.27.5 (KHTML, like Gecko) ', 'Officiis nostrum debitis aspernatur quibusdam molestiae nostrum provident non. Corporis similique iste dicta omnis harum iste quae. Possimus non harum perspiciatis ut doloribus et temporibus perspiciatis.', '2022-07-02 17:45:51'),
(340081, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_3 rv:4.0) Gecko/20170330 Firefox/3.6.6', 'Expedita dolor eos id et a. Fugiat consectetur dignissimos sint perferendis facere dicta. Reiciendis fugiat eveniet et maiores et.', '2002-10-14 05:01:07'),
(348913, 'Opera/9.42 (X11; Linuxi686; sl-SI) Presto/2.9.165 Version/11.00', 'Eaque officiis et est tempora autem in. Quibusdam doloribus quia tenetur sed quibusdam. Fugiat dolorem aut laborum qui expedita nostrum.', '1999-06-14 14:07:27'),
(350021, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_1 like Mac OS X; en-US) AppleWebKit/535.27.6 (KHTML, like Geck', 'Aut ex eaque quasi quisquam quibusdam commodi quia. Voluptas autem aut est praesentium.', '1991-06-03 20:42:19'),
(351514, 'Mozilla/5.0 (Windows; U; Windows 98) AppleWebKit/534.38.2 (KHTML, like Gecko) Version/4.0 Safari/534', 'Quasi provident corrupti vitae eum officia est maxime et. Dolor quia qui consectetur odit. Est voluptas fugiat beatae ex quis eaque eveniet.', '2011-04-19 03:56:47'),
(352580, 'Opera/9.32 (Windows 98; Win 9x 4.90; en-US) Presto/2.9.184 Version/10.00', 'Maxime occaecati molestias animi sunt. Velit iure illum quia similique quam ullam. Facilis corporis et magnam dicta qui.', '1970-08-23 15:40:51'),
(359390, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 6.1; Trident/5.1)', 'Ad aperiam eum amet repudiandae est. Totam velit earum unde. Error aut quia amet quia molestias omnis. Accusantium suscipit fugiat cupiditate ut vel. Neque ea magni et ut sequi voluptatem iusto.', '2007-04-01 07:32:11'),
(370870, 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/5322 (KHTML, like Gecko) Chrome/13.0.830.0 Safari/5322', 'Occaecati et consequatur ut commodi saepe ut. Voluptates consequatur et unde doloribus sed. Id sed atque rem officiis consequatur. Iusto est sint sit.', '1995-03-24 05:55:42'),
(376643, 'Mozilla/5.0 (X11; Linuxi686; rv:5.0) Gecko/20240613 Firefox/3.6.4', 'Nisi voluptatum deserunt deleniti ut. Dolorem corrupti aut maxime reprehenderit et corrupti et. Illo esse quis autem nihil incidunt voluptatum. Dolor voluptatum quis perspiciatis consequatur architecto expedita.', '1970-04-15 15:19:37'),
(378508, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows 98; Win 9x 4.90; Trident/5.0)', 'Perferendis voluptatum voluptatem nulla esse cum ipsa harum. Minima assumenda quo id possimus qui velit. Cumque quia sed placeat consectetur. Aliquam doloremque dolorem voluptas.', '1977-05-22 21:21:42'),
(390395, 'Mozilla/5.0 (X11; Linuxx86_64; rv:7.0) Gecko/20110212 Firefox/12.0', 'Quas eos sed illo rem molestias. Nostrum autem ab est ut sit. Quisquam similique amet qui dolores nam ut deleniti est. Occaecati sed fuga debitis rerum quas ex.', '2019-09-25 14:49:18'),
(395920, 'Mozilla/5.0 (X11; Linuxi686; rv:6.0) Gecko/20151011 Firefox/3.8', 'Debitis dolore repellat itaque nostrum illum et. Veniam sit eum libero recusandae sint. Modi est error animi illo quam tempore voluptas.', '2001-05-11 20:23:09'),
(396026, 'Mozilla/5.0 (Windows; U; Windows NT 5.01) AppleWebKit/531.41.1 (KHTML, like Gecko) Version/4.0.2 Saf', 'Quia enim sunt aut incidunt ut perferendis autem consectetur. Nesciunt ab tempore quod ut. Enim praesentium voluptatem qui fugit sed non.', '2007-04-01 15:19:50'),
(400727, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_3 rv:6.0; en-US) AppleWebKit/533.8.5 (KHTML, like Gecko)', 'Tempore incidunt velit non occaecati. Quidem consequuntur libero est atque.', '2003-04-06 20:15:06'),
(408040, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.0; Trident/5.1)', 'Aut quas ducimus illo molestiae aut quisquam quia. Mollitia sed dolorum eum minima est blanditiis est.', '2021-03-28 05:23:35'),
(431103, 'Mozilla/5.0 (Windows; U; Windows 98) AppleWebKit/532.24.2 (KHTML, like Gecko) Version/5.0.4 Safari/5', 'Fuga necessitatibus maiores quis esse nam molestiae. Labore id hic quis. Aut blanditiis alias architecto debitis at labore. Sit consequatur voluptatem corporis. Aut laboriosam qui nisi quia ut.', '1989-04-13 07:22:09'),
(435701, 'Mozilla/5.0 (Windows 98; sl-SI; rv:1.9.0.20) Gecko/20130601 Firefox/3.8', 'Quis odit ducimus ipsa quos architecto totam quos. Voluptatem exercitationem quia quidem dolorem exercitationem quas optio autem. Quis nulla qui voluptatum sit dolores occaecati vitae.', '2005-10-12 07:11:47'),
(437289, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows CE; Trident/3.1)', 'Rerum quod sit voluptates dolor ut. Quae dolorem velit consequatur praesentium quae. Vel cupiditate ut doloribus sequi veritatis assumenda consectetur veritatis.', '2009-02-10 20:28:53'),
(445750, 'Opera/8.31 (Windows NT 6.1; sl-SI) Presto/2.9.181 Version/12.00', 'Voluptas enim non accusantium sed ex. Iusto est amet similique repellat. Qui ad autem quis numquam.', '1995-06-11 16:40:24'),
(447254, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.01; Trident/4.1)', 'Recusandae libero veniam id consequatur et vitae. Possimus hic sint recusandae voluptas. Fugit rerum eius mollitia odit voluptates velit.', '2014-05-13 09:04:02'),
(454417, 'Opera/8.24 (Windows NT 6.1; sl-SI) Presto/2.9.162 Version/12.00', 'Voluptatem quo iure velit odio porro. Libero mollitia est eum fugit facilis. Saepe aperiam et iusto aperiam eius. Exercitationem molestiae quo magni ut corporis distinctio.', '2013-04-09 14:03:18'),
(468428, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5322 (KHTML, like Gecko) Chrome/15.0.852.0 Safari/5322', 'Omnis sunt quia nam temporibus voluptas rerum. Animi iste libero ullam recusandae error. Et quisquam quam nesciunt.', '1975-08-20 20:29:46'),
(471956, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5331 (KHTML, like Gecko) Chrome/14.0.867.0 Safari/5331', 'Ex et qui voluptatem reprehenderit a et. Iure et excepturi quia alias nesciunt. Voluptas facere delectus magnam. Et dolores accusantium ut ipsam voluptatem ut aspernatur ab.', '2023-11-11 04:52:30'),
(484098, 'Mozilla/5.0 (Windows NT 6.0; sl-SI; rv:1.9.1.20) Gecko/20120420 Firefox/3.6.15', 'Alias iste sint esse qui praesentium repellendus. Fugit voluptas ut in excepturi reprehenderit. Unde repellendus amet beatae tenetur quaerat vero vitae. Quas voluptatem ipsam voluptas consequatur ullam aut sed.', '2015-07-24 02:28:19'),
(498296, 'Mozilla/5.0 (Windows NT 5.2) AppleWebKit/5340 (KHTML, like Gecko) Chrome/15.0.830.0 Safari/5340', 'Harum quo et sequi rerum quam labore ut. Sit distinctio reprehenderit rem recusandae earum veniam qui. Saepe aut sed et qui et quis. Aut dolores non eligendi asperiores ullam.', '1983-07-22 23:07:09'),
(499720, 'Opera/9.22 (Windows CE; sl-SI) Presto/2.9.174 Version/11.00', 'Reprehenderit libero eos veniam molestiae. Quos officia sunt sint at illum. Eius id cum vel est ut.', '1975-05-24 03:50:17'),
(500425, 'Opera/9.14 (Windows NT 6.2; sl-SI) Presto/2.9.190 Version/10.00', 'Quo officia facere omnis recusandae ratione cum dolores. Fugit et aut possimus id. Qui eos expedita et sunt labore iste. Est et repudiandae modi assumenda placeat eum sint. Temporibus neque consequatur dolores aliquid soluta.', '1994-02-20 00:11:51'),
(506159, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5350 (KHTML, like Gecko) Chrome/15.0.873.0 Safari/5350', 'Facere et voluptas autem libero cumque. Esse ratione exercitationem reiciendis quasi repellendus deserunt blanditiis nostrum. Nisi culpa numquam modi doloribus illum. A quis sapiente quisquam et voluptatem iure animi.', '2002-03-14 13:39:14'),
(507129, 'Mozilla/5.0 (X11; Linuxi686; rv:6.0) Gecko/20210503 Firefox/3.8', 'Quis itaque suscipit hic nihil rerum officiis cupiditate. Corporis repudiandae distinctio porro voluptatum nulla esse possimus. Ratione aut non eius tempore vitae doloribus. Praesentium ut et dolorem dignissimos dolor numquam optio.', '2005-12-22 23:03:49'),
(508139, 'Mozilla/5.0 (Windows CE) AppleWebKit/5351 (KHTML, like Gecko) Chrome/14.0.830.0 Safari/5351', 'Assumenda blanditiis odit quia rerum. Asperiores hic perspiciatis dolorem occaecati ex. Recusandae dolores similique unde voluptates sunt.', '1978-09-16 14:02:50'),
(512572, 'Mozilla/5.0 (Windows NT 5.1; en-US; rv:1.9.0.20) Gecko/20100728 Firefox/3.8', 'Et consequuntur ea corporis sapiente sit recusandae ut non. Ad ex quia autem sit accusamus cum quasi. Sunt inventore sunt maiores.', '1987-08-03 02:35:07'),
(521324, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.2; Trident/5.1)', 'Quis error necessitatibus qui ut ut dolorem. Et sint amet nihil qui distinctio maxime eum corrupti. Facilis qui qui voluptatem nihil quos illo et. Voluptas enim vel sint impedit et aut nesciunt.', '1978-09-19 20:48:05'),
(524815, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 5.2; Trident/3.0)', 'Magnam distinctio tenetur voluptas modi eum numquam amet. Cum id repudiandae et perspiciatis fuga et culpa. Quia error consequatur illum doloribus est. Animi dolorem quibusdam quis consequatur aut laudantium. Et quis reiciendis voluptas.', '2018-09-02 16:19:29'),
(524958, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_0 rv:2.0; sl-SI) AppleWebKit/531.32.1 (KHTML, like Gecko', 'Occaecati ullam architecto illum occaecati. Accusantium id ducimus et facere ad. Vitae aliquid autem temporibus omnis quos a voluptatibus.', '2007-05-07 08:18:57'),
(525183, 'Mozilla/5.0 (Windows; U; Windows NT 5.01) AppleWebKit/535.1.6 (KHTML, like Gecko) Version/4.1 Safari', 'Distinctio rem exercitationem delectus fugiat fuga et repudiandae. Adipisci error repudiandae vel ducimus unde veritatis. Iste ut qui omnis fuga quod.', '2010-07-18 13:59:59'),
(533449, 'Opera/9.66 (Windows NT 5.2; en-US) Presto/2.9.185 Version/11.00', 'Eligendi iusto quia ducimus similique quia suscipit inventore. Molestias assumenda quibusdam saepe iure id occaecati dicta aut. Qui accusantium placeat aut architecto architecto velit.', '1974-07-01 18:57:59'),
(538975, 'Mozilla/5.0 (X11; Linuxi686; rv:7.0) Gecko/20100113 Firefox/3.6.5', 'Sunt aut dolores sint natus ullam. Nam sint repellendus quia nemo in est. Aliquam odio iusto voluptas minus accusantium ut. Consequatur in amet dicta accusantium placeat vitae vel.', '1972-06-14 09:45:42'),
(543595, 'Mozilla/5.0 (Windows NT 5.01) AppleWebKit/5361 (KHTML, like Gecko) Chrome/13.0.804.0 Safari/5361', 'Ad dolores quibusdam et reiciendis. Quasi recusandae aliquam quisquam a ut ipsam. Qui ducimus est repudiandae sunt voluptatem occaecati quibusdam itaque.', '1983-12-13 20:48:45'),
(546061, 'Opera/8.39 (X11; Linuxi686; sl-SI) Presto/2.9.171 Version/10.00', 'Nulla pariatur nesciunt itaque itaque qui quas. Quos ipsum id error. Veniam exercitationem dolorum doloribus sequi excepturi perferendis. Atque magni et aliquam dolorum iusto eum perferendis.', '2009-02-05 22:48:20'),
(555873, 'Mozilla/5.0 (X11; Linuxx86_64; rv:6.0) Gecko/20170213 Firefox/6.0', 'Id iure ut et aspernatur. Asperiores magni id impedit. Quidem natus est quas sint. Esse quidem accusantium quis nam sit iure eos.', '1976-08-31 21:32:59'),
(561795, 'Opera/8.77 (X11; Linuxx86_64; en-US) Presto/2.9.176 Version/10.00', 'Sint eius quia omnis tempore aut distinctio quis. Harum voluptatibus quo veniam at ipsam. Amet voluptatem fuga ratione debitis. Ut ut sit et corrupti sunt quisquam aut.', '2000-08-20 08:23:10'),
(568447, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_7 rv:5.0; sl-SI) AppleWebKit/534.45.2 (KHTML, like Gecko', 'Debitis aperiam sed explicabo ut aut est maxime ea. Repellat ut dolorum repudiandae ullam consequuntur. Qui incidunt explicabo facere assumenda saepe. Perspiciatis eos voluptate eum optio repudiandae repudiandae dolorum.', '2023-08-25 10:26:42'),
(574701, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_5_7 rv:5.0) Gecko/20160101 Firefox/3.6.20', 'Illo perspiciatis et omnis impedit assumenda ab tempore molestiae. Voluptas perspiciatis eos et deserunt similique nihil id voluptatem. Error excepturi ab nobis dolor accusamus totam. Eaque voluptates ipsum cupiditate veniam vitae aut possimus qui.', '1980-03-07 02:19:25'),
(589720, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5322 (KHTML, like Gecko) Chrome/14.0.813.0 Safari/5322', 'Sit ea nesciunt sint non. Exercitationem impedit ut quo fugit.', '1998-01-05 06:41:40'),
(593664, 'Opera/8.86 (Windows NT 6.1; en-US) Presto/2.9.180 Version/12.00', 'Voluptatem maiores et modi sed. Incidunt fugiat temporibus odit ut. Ut et corporis odio molestiae. Totam quo quia temporibus odio voluptatem.', '1992-01-31 21:20:24'),
(601116, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_5_1 rv:2.0; en-US) AppleWebKit/533.4.2 (KHTML, like Gecko', 'Illo dolorem ea iusto ut vitae animi omnis. In culpa rerum sequi ut illum numquam. Illum quos sapiente culpa et. Atque officiis non quia animi.', '2002-10-14 23:23:33'),
(611308, 'Mozilla/5.0 (Windows NT 6.2) AppleWebKit/5341 (KHTML, like Gecko) Chrome/13.0.894.0 Safari/5341', 'Nisi ut et expedita modi modi. Reprehenderit provident ad nesciunt neque adipisci labore. Repudiandae ratione est beatae nulla dolorum voluptas. Ratione assumenda eveniet rerum omnis.', '1990-02-25 14:39:36'),
(613223, 'Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/532.3.5 (KHTML, like Gecko) Version/5.1 Safari/', 'Est culpa facere non. Voluptate facere facilis qui eos officia dignissimos. Autem consequatur quisquam nulla aut quam.', '1974-10-28 11:28:37'),
(617824, 'Mozilla/5.0 (Windows 98; Win 9x 4.90; en-US; rv:1.9.2.20) Gecko/20190801 Firefox/3.6.19', 'Repellat odio sint voluptatem aspernatur aut eligendi dolor. Unde velit eos sit nostrum. Fuga doloremque explicabo eos eum.', '2024-07-08 17:54:14'),
(623205, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_2 like Mac OS X; sl-SI) AppleWebKit/532.1.4 (KHTML, like Gecko', 'Et odit doloribus repudiandae voluptatem qui. Accusantium earum qui et quia sed. Veritatis id dolores saepe ut.', '1988-12-06 04:40:02'),
(637987, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5311 (KHTML, like Gecko) Chrome/13.0.846.0 Safari/5311', 'Non sit odio perspiciatis inventore rerum at aut. Distinctio quae atque at ipsam fuga. Dolores vel aliquid non ad velit doloribus. Magnam illum quis commodi consequatur non.', '1973-01-17 19:58:51'),
(639274, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5311 (KHTML, like Gecko) Chrome/15.0.862.0 Safari/5311', 'Illum repellat in animi ea ut dolores porro. Neque sunt odio molestiae harum. Qui possimus qui neque laborum vel fugiat et voluptas. Aut ea est commodi tempora ex vero.', '1988-07-05 08:01:58'),
(645465, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_1) AppleWebKit/5351 (KHTML, like Gecko) Chrome/15.0.807.', 'Harum repellendus harum optio odio. Voluptas tempora quisquam provident velit omnis necessitatibus nemo. Consequatur enim molestiae temporibus est cupiditate aut quam.', '2000-05-09 10:27:38'),
(645739, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_1 like Mac OS X; en-US) AppleWebKit/535.49.4 (KHTML, like Geck', 'Soluta quia inventore tempora aut culpa. Omnis ipsa sed voluptatem distinctio sit. Reiciendis blanditiis necessitatibus qui et dignissimos dignissimos assumenda.', '2017-11-03 05:06:23'),
(653274, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_6_7 rv:5.0; en-US) AppleWebKit/534.38.4 (KHTML, like Gecko) ', 'Doloribus iusto et omnis aut dolorem odit reiciendis. Maiores excepturi et repellendus repellat. Temporibus hic ut nemo quisquam et.', '1974-01-08 13:59:56'),
(654338, 'Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/532.34.6 (KHTML, like Gecko) Version/4.0.3 Safa', 'Tenetur accusamus qui voluptate sequi qui ut iste. Doloribus ut ea et in repudiandae rerum rem. Eius consequatur harum mollitia earum sit deserunt et.', '2009-09-10 17:31:02'),
(657685, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows 95; Trident/5.1)', 'Ad commodi reiciendis eius cupiditate veritatis illum. Qui sit odit unde sequi molestias nisi aut. Ratione nihil tempora itaque aut rerum non.', '1971-09-11 12:59:29'),
(660485, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows 98; Win 9x 4.90; Trident/3.0)', 'Omnis magnam temporibus autem perferendis natus quo sequi. Ut consequuntur ipsam ipsa accusamus ipsam est. Voluptate quis magnam numquam magnam soluta.', '1991-06-26 06:56:38'),
(672429, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.0; Trident/5.1)', 'Rerum velit exercitationem eaque. Magnam facilis tempora magni possimus enim assumenda. Saepe possimus eum maxime enim soluta corporis. Est eligendi repudiandae dignissimos dolorem est.', '2001-10-20 02:30:43'),
(682264, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_2 rv:3.0; en-US) AppleWebKit/533.38.2 (KHTML, like Gecko', 'Laboriosam aliquam iusto voluptates. Officia nam ea molestiae ut. Aperiam iusto ex non minima odit.', '1975-05-15 23:24:36');
INSERT INTO `categories` (`id`, `name`, `description`, `created_at`) VALUES
(682725, 'Mozilla/5.0 (Windows CE; sl-SI; rv:1.9.1.20) Gecko/20240607 Firefox/3.6.8', 'Asperiores velit numquam et sit odio. Ipsa occaecati quidem dolor dolorem molestiae tempore sapiente. Praesentium laborum corporis ut nemo nulla rerum. Quaerat veritatis quia et unde quam.', '2002-01-04 05:53:44'),
(685907, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_7_1) AppleWebKit/5350 (KHTML, like Gecko) Chrome/15.0.820', 'Laboriosam saepe impedit assumenda eum odio. At enim ipsum quae fugit et consequatur voluptate. Voluptas distinctio magni dolores dignissimos autem culpa.', '2023-02-09 12:48:33'),
(691829, 'Mozilla/5.0 (Windows NT 5.0) AppleWebKit/5321 (KHTML, like Gecko) Chrome/13.0.801.0 Safari/5321', 'Temporibus praesentium nostrum earum iusto similique iste eos. Fugit officia adipisci alias. Iure beatae rem dolores et.', '2014-07-04 23:19:09'),
(692746, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_5_6 rv:4.0; en-US) AppleWebKit/532.34.7 (KHTML, like Geck', 'Quisquam nihil beatae nihil fuga velit. Quia est fugit ipsa quia.', '1981-08-26 07:30:21'),
(692919, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.1; Trident/3.1)', 'Totam ut ut culpa aperiam doloribus voluptas. Incidunt rerum a nobis ullam ipsa quo excepturi voluptate. Adipisci in eum ea unde ut. Qui maxime voluptas quos quam et aut.', '1977-05-30 16:04:14'),
(697417, 'Opera/9.70 (X11; Linuxx86_64; sl-SI) Presto/2.9.171 Version/11.00', 'Quia autem omnis alias voluptatem consequatur. Repellendus voluptas qui sed molestias qui ut.', '1987-04-27 01:39:50'),
(704914, 'Mozilla/5.0 (Windows 98; Win 9x 4.90) AppleWebKit/5340 (KHTML, like Gecko) Chrome/13.0.836.0 Safari/', 'Quasi aliquid alias qui voluptas. Rerum laboriosam corrupti laudantium vel. Enim alias neque enim doloremque nihil. Nulla quaerat impedit aliquid dolor quia nemo molestiae. Ab eveniet sit et ex nam.', '2008-07-31 05:22:01'),
(708704, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows 98; Trident/4.1)', 'Fugit vero laborum vero neque tempora maxime quia. Aut ab eum qui. Quidem odio deserunt sit neque dolores totam.', '2025-03-19 20:13:34'),
(712328, 'Mozilla/5.0 (Windows 98; sl-SI; rv:1.9.0.20) Gecko/20210421 Firefox/3.8', 'Repellendus vero dolor qui veritatis id neque. Voluptatem sit harum sed et. Possimus voluptatem aspernatur aut pariatur.', '2018-09-30 02:25:39'),
(720813, 'Mozilla/5.0 (Windows NT 5.1; en-US; rv:1.9.1.20) Gecko/20100523 Firefox/3.6.12', 'Corrupti dolor eos laudantium veniam non. Inventore dolorem non nobis soluta saepe. Non dolor qui voluptatem soluta asperiores vero.', '2009-04-20 21:42:26'),
(722248, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_6 rv:5.0; en-US) AppleWebKit/532.36.7 (KHTML, like Ge', 'Numquam voluptas et est enim illo. Quo ut ea hic autem numquam dolorum. Omnis perferendis consequatur aut eius voluptate sed debitis. Unde officiis sed autem aperiam aut modi laborum.', '1974-03-20 22:21:51'),
(722728, 'Mozilla/5.0 (Windows CE) AppleWebKit/5312 (KHTML, like Gecko) Chrome/15.0.827.0 Safari/5312', 'Et voluptatem est quia ipsa deleniti consequatur libero. Aut consequuntur repudiandae non autem similique enim dolores minima. Voluptatem fugit et est eligendi exercitationem. Repellendus consectetur sint ipsam dolorum enim.', '2022-04-05 18:18:58'),
(727521, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 6.0; Trident/3.1)', 'Assumenda dolorem voluptatem dolorem et nisi enim nam. Et consequatur excepturi et ut quos. Et vel quis quaerat quia. Temporibus optio numquam quia aspernatur est eum.', '1971-02-28 07:02:07'),
(736414, 'Opera/8.69 (Windows NT 5.01; sl-SI) Presto/2.9.179 Version/12.00', 'Architecto totam libero distinctio. Laboriosam illum dolorem non voluptas rerum nulla labore ad. Excepturi velit et doloribus. Et ab esse nam impedit consequuntur nihil non error.', '2000-09-09 01:03:43'),
(738460, 'Mozilla/5.0 (X11; Linuxx86_64; rv:6.0) Gecko/20140726 Firefox/3.8', 'Aperiam suscipit accusamus optio. In et voluptatem et dolores qui qui unde. Velit sit iure harum nihil tempora tempore dignissimos. Perferendis est excepturi voluptas vitae nostrum adipisci a.', '1978-03-07 23:39:00'),
(741437, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_6_8 rv:3.0) Gecko/20220210 Firefox/3.6.18', 'Quibusdam sed numquam asperiores. Eligendi voluptatem voluptatum voluptas corrupti dignissimos reprehenderit excepturi. Placeat quaerat qui corporis est itaque aut.', '1998-09-01 20:34:11'),
(744943, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_7) AppleWebKit/5340 (KHTML, like Gecko) Chrome/13.0.8', 'Id ut aut ut. Expedita quis in officia sunt. Maiores esse voluptates qui et.', '1980-01-07 14:27:57'),
(756197, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 4.0; Trident/5.1)', 'Magnam eius libero commodi quibusdam esse impedit. Est libero dolor odit dolores possimus et. Quidem cupiditate dolores vel deserunt et.', '1986-03-06 21:03:26'),
(758747, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 4.0; Trident/3.1)', 'Dolorem eos asperiores libero eligendi ipsum dicta quaerat. Maxime vel deserunt reprehenderit et aperiam aliquid. Alias dolorem quia officiis est. Rerum autem et sit quod.', '2010-09-28 01:53:07'),
(770361, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 4.0; Trident/3.1)', 'Iste qui ea culpa aut eos. Earum deleniti nihil nihil. Ducimus harum dolore in consequatur ipsum. Et incidunt quidem et et.', '2003-08-15 13:42:50'),
(784240, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5361 (KHTML, like Gecko) Chrome/15.0.853.0 Safari/5361', 'Ab itaque quae illum voluptatem molestiae ab sed. Voluptate voluptatem eos aspernatur sed distinctio. Voluptate voluptatum quod ea necessitatibus blanditiis facilis possimus. Suscipit numquam et voluptatem itaque dolorem corrupti sapiente minima.', '2025-02-05 13:50:54'),
(789599, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.1; Trident/5.1)', 'Magnam eligendi cumque provident deserunt. Quis aut cupiditate optio sit error vitae vel. Sunt est neque sunt. Exercitationem accusamus ut facere doloremque. Rerum vero delectus laudantium corrupti quo.', '2009-11-13 20:36:01'),
(790355, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.1; Trident/5.1)', 'Fugiat dolor necessitatibus nostrum ducimus praesentium ipsam totam. Sint ut id laudantium cumque similique ut aut. Omnis fugit rerum qui et vitae rerum.', '2007-02-19 04:16:25'),
(810081, 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/5340 (KHTML, like Gecko) Chrome/15.0.895.0 Safari/5340', 'Alias expedita odio sequi amet omnis est. Iste eveniet nemo exercitationem explicabo commodi. Aut cumque dolor quia tempore corporis unde et.', '1975-09-03 07:40:17'),
(818715, 'Opera/9.81 (X11; Linuxi686; en-US) Presto/2.9.179 Version/12.00', 'Eos aspernatur sint reiciendis dolorum modi. Aut non id blanditiis dolore.', '2003-06-17 17:31:07'),
(822465, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5321 (KHTML, like Gecko) Chrome/15.0.886.0 Safari/5321', 'Error nam magnam fugiat accusantium. Ullam a praesentium ipsam. Asperiores repudiandae qui dolor nulla.', '2019-04-05 17:01:26'),
(829926, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5341 (KHTML, like Gecko) Chrome/15.0.867.0 Safari/5341', 'Incidunt incidunt amet et molestiae. Consectetur accusantium rem deserunt. Doloremque ut enim tempora quia unde.', '2020-05-08 13:30:23'),
(881316, 'Opera/9.32 (X11; Linuxx86_64; en-US) Presto/2.9.164 Version/12.00', 'Recusandae id doloremque dolores quis quod vel voluptatum. Delectus temporibus error pariatur et sed praesentium aut tenetur. Laudantium saepe nulla dicta cumque nihil. Quia cum quisquam qui minima velit.', '1987-05-02 05:25:30'),
(885389, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5341 (KHTML, like Gecko) Chrome/15.0.863.0 Safari/5341', 'Eum deleniti quam voluptate ea. Enim quibusdam quo voluptas quia. Asperiores praesentium doloribus ut sit.', '1979-05-23 20:55:42'),
(886270, 'Opera/8.21 (Windows NT 6.0; sl-SI) Presto/2.9.165 Version/11.00', 'Neque est assumenda quidem veritatis porro dolorum mollitia. Similique porro explicabo voluptatem explicabo aut aut. Reprehenderit exercitationem qui eveniet maxime error eum quia. Itaque sed sunt ut cupiditate est pariatur itaque consequatur. A est quis aut veniam id.', '2016-05-04 13:10:07'),
(886311, 'Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/535.35.5 (KHTML, like Gecko) Version/4.1 Safari', 'Sunt quia maiores quasi velit. Mollitia voluptates illum iure molestias. Quibusdam architecto eum excepturi temporibus sed et. Rerum sunt voluptatibus velit at mollitia in repudiandae.', '2016-07-28 06:10:59'),
(890367, 'Mozilla/5.0 (Windows 95) AppleWebKit/5342 (KHTML, like Gecko) Chrome/15.0.869.0 Safari/5342', 'Consequatur et quas eius perferendis voluptas hic mollitia. Fugiat earum adipisci odio mollitia molestias non qui dignissimos. Odit quis quia et odit eaque illo tempore.', '1989-11-18 13:07:34'),
(903378, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5310 (KHTML, like Gecko) Chrome/13.0.848.0 Safari/5310', 'Voluptatum et molestiae neque aut aliquam. Soluta sunt sit qui eum quam quia omnis. Natus libero quisquam id alias voluptatem cumque esse. Quos non nesciunt magni saepe qui eligendi deleniti.', '1993-01-29 09:21:42'),
(924419, 'Mozilla/5.0 (X11; Linuxi686; rv:5.0) Gecko/20150209 Firefox/14.0', 'Pariatur ut et cumque consequatur perferendis et. Necessitatibus ut minus saepe vel quis delectus. Ut cupiditate ut in qui rem mollitia quia itaque. Labore quia est et minima iste repudiandae minus impedit.', '2019-05-10 17:50:53'),
(928199, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5310 (KHTML, like Gecko) Chrome/15.0.819.0 Safari/5310', 'Dolorum voluptatem similique illum magni. Ipsam rerum a aliquam repellat molestiae veniam officia. Iusto officiis dicta unde distinctio est.', '2002-05-21 05:57:37'),
(945056, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.2; Trident/4.1)', 'Nihil voluptate quo corrupti enim. Inventore perspiciatis quia dolore consequatur recusandae. Ipsam autem fugiat minus dolor nesciunt ipsam atque. Fuga ea iste iure et tempora quae.', '2009-01-04 01:19:51'),
(947231, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 6.2; Trident/5.0)', 'Qui corrupti rerum quis ipsa aut. Recusandae consequatur omnis impedit sed sit. Sunt consectetur repellendus alias debitis dolor. Atque et recusandae voluptas hic. Quaerat quidem dolores unde temporibus dolor.', '1985-01-13 19:42:59'),
(948355, 'Mozilla/5.0 (X11; Linuxi686; rv:5.0) Gecko/20130117 Firefox/3.8', 'Officiis ut eum reiciendis laborum libero. Sunt sit deleniti illum molestiae. Odio nam eaque soluta tempora eos. Illo placeat deserunt quis aut eveniet harum.', '2018-05-26 23:31:27'),
(951147, 'Mozilla/5.0 (X11; Linuxx86_64; rv:7.0) Gecko/20140703 Firefox/3.8', 'Excepturi optio ad omnis deserunt eaque. Architecto consequatur voluptas deleniti sit eos. Repudiandae et totam ipsum eligendi neque.', '1989-03-28 18:04:14'),
(965109, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_7_0 rv:3.0) Gecko/20190405 Firefox/15.0', 'Suscipit qui vel quo voluptatum magnam ea delectus. Sequi voluptatem illum quo. Aperiam earum et tempora sint dolore deserunt.', '2014-01-01 06:48:30'),
(980625, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.01; Trident/5.1)', 'Cum in porro vitae in vitae. Aut assumenda nesciunt quas vitae quas. Nobis ducimus rerum qui labore. Qui sit exercitationem non quia dolor.', '1990-08-13 15:20:51'),
(982432, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_7_5) AppleWebKit/5341 (KHTML, like Gecko) Chrome/13.0.854', 'Et ea molestiae distinctio. Ipsa et ut et voluptates deleniti quis qui. Fugit ullam ex laudantium iure quibusdam deserunt exercitationem. Dignissimos iusto omnis ratione qui ipsam.', '2005-10-14 20:08:58'),
(986527, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows 95; Trident/4.0)', 'Maiores enim minus doloribus debitis beatae voluptate. Necessitatibus laborum sit beatae eum quo. Nisi nam labore quia non alias.', '2004-12-18 20:56:35'),
(986805, 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/5330 (KHTML, like Gecko) Chrome/15.0.844.0 Safari/5330', 'Provident tempora beatae eaque dolores. Quas ut odit molestiae necessitatibus. Autem quis voluptatibus odio sint officiis voluptatem ducimus. Iste asperiores et voluptatum nihil quo.', '1997-02-04 20:08:37'),
(996847, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 6.2; Trident/5.0)', 'Quos ut minus aliquam aut harum. Autem nobis illo qui incidunt unde possimus. Sint et qui qui magnam esse.', '2016-05-03 16:10:23'),
(999998, 'Opera/8.54 (X11; Linuxx86_64; en-US) Presto/2.9.186 Version/10.00', 'Sit hic tempora est fugit libero et tempore. Qui dolore non aut culpa modi aperiam. Vitae pariatur accusamus et placeat quis tempore. Ut esse et voluptatum ea dolores expedita dolor. Perferendis neque voluptatem impedit quidem et sunt dolorum et.', '1983-03-03 12:28:27'),
(1030967, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_6) AppleWebKit/5352 (KHTML, like Gecko) Chrome/14.0.835.', 'Tenetur libero qui excepturi est. Dignissimos quae est asperiores minima. Sapiente enim magnam eum. Soluta est odit autem perferendis dolores. Rem suscipit consequatur sint sit ipsam incidunt ullam.', '1974-11-16 15:27:11'),
(1065409, 'Opera/8.79 (Windows NT 4.0; en-US) Presto/2.9.162 Version/10.00', 'Cupiditate veniam sunt omnis saepe cum sit. Vel laudantium et itaque consequatur et sunt. Dolor inventore nihil ab et aut.', '2022-02-23 22:57:02'),
(1083697, 'Opera/9.92 (X11; Linuxi686; sl-SI) Presto/2.9.178 Version/12.00', 'Sit ut omnis qui at. Eaque vel expedita sit sequi atque magni asperiores. Animi et non maxime minima. Id itaque adipisci voluptatem iste explicabo odit.', '1998-10-29 13:53:18'),
(1119202, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5361 (KHTML, like Gecko) Chrome/14.0.852.0 Safari/5361', 'Non enim dolor quas voluptas. Deserunt in voluptas dolorem error qui voluptas. Et qui commodi non. Occaecati sunt sit magnam quo et dolor.', '1984-09-05 21:02:12'),
(1124650, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_8_3 rv:5.0) Gecko/20250429 Firefox/3.6.5', 'Fuga id sed ea et eum et fugiat eum. Atque numquam accusantium consequatur alias aut iusto ex eos.', '2014-11-01 21:55:25'),
(1177082, 'Mozilla/5.0 (Windows NT 5.2) AppleWebKit/5351 (KHTML, like Gecko) Chrome/13.0.860.0 Safari/5351', 'Ipsum labore rerum dolorem aut est. Rerum architecto molestias suscipit tenetur dolores velit velit sit. Id saepe soluta consequatur eos voluptates voluptatem quia sit. Repudiandae maxime veniam sit excepturi reiciendis non quam.', '2008-07-20 07:58:06'),
(1215738, 'Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/532.42.7 (KHTML, like Gecko) Version/5.0.3 Safa', 'Velit numquam voluptatibus earum illum voluptatem. Aliquid quidem iure assumenda enim repellat voluptates quo. Dicta sed unde praesentium. Molestiae esse quas non eum officiis.', '1972-01-31 06:43:38'),
(1342745, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 6.0; Trident/4.1)', 'Numquam perferendis est recusandae aut. Error temporibus dolorem necessitatibus porro. Sit voluptates at labore.', '1985-05-13 10:58:38'),
(1370032, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_6_1 rv:4.0; en-US) AppleWebKit/535.47.6 (KHTML, like Geck', 'Impedit repudiandae vel eligendi doloribus accusantium voluptates. Quae repellendus repudiandae rerum et. A numquam atque illum dicta magni dolor. Sint placeat reprehenderit sequi iusto id nihil dolor.', '1976-07-09 20:28:24'),
(1449790, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5310 (KHTML, like Gecko) Chrome/14.0.867.0 Safari/5310', 'Ut officiis enim repellat et. Asperiores sunt saepe consequatur et aut in qui optio. Ratione quaerat et ducimus.', '2011-07-01 18:58:06'),
(1491843, 'Mozilla/5.0 (Windows; U; Windows 98; Win 9x 4.90) AppleWebKit/535.45.7 (KHTML, like Gecko) Version/5', 'Consequatur aut et accusamus minus dolorum. Molestias ut ut necessitatibus est. Suscipit repudiandae quis quia et ut.', '1976-01-12 02:51:45'),
(1502379, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_8_0) AppleWebKit/5361 (KHTML, like Gecko) Chrome/15.0.8', 'Perspiciatis recusandae dignissimos omnis quod quibusdam. Aspernatur eos blanditiis atque eos. Eum a voluptatem deleniti maiores et rerum.', '1987-08-09 15:30:31'),
(1535776, 'Mozilla/5.0 (X11; Linuxx86_64; rv:5.0) Gecko/20180323 Firefox/3.8', 'Rerum id quia qui aliquid molestiae aliquid possimus laborum. Officiis maiores perferendis illo recusandae voluptatem delectus et. Omnis labore eum aut ut.', '1974-03-11 15:50:28'),
(1539286, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_7_3 rv:2.0; sl-SI) AppleWebKit/532.38.5 (KHTML, like Ge', 'Id fugit ea odit. Inventore officia voluptatibus consequatur soluta dicta autem. Distinctio ea quo omnis perspiciatis sunt consequatur. Omnis consequatur et porro rem eligendi qui.', '2015-01-02 07:56:55'),
(1612725, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 5.1; Trident/5.1)', 'Dolorem qui et dignissimos. Nobis et omnis omnis perspiciatis iusto. Dicta nostrum ullam dolorum mollitia modi ex dolores.', '1995-10-31 11:31:13'),
(1638374, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_7 rv:2.0) Gecko/20141116 Firefox/3.6.1', 'Et dolor sint est sit amet. Omnis inventore et maxime. Voluptatem modi assumenda eos quod unde alias.', '1984-07-10 22:13:59'),
(1673533, 'Opera/8.35 (X11; Linuxi686; sl-SI) Presto/2.9.188 Version/12.00', 'Fugiat quas qui tempore beatae debitis. Sunt sed perferendis autem. Ipsam sunt nostrum consequatur quibusdam quam quisquam laudantium accusantium. Quas voluptate eum quo est similique impedit.', '1976-02-24 22:24:24'),
(1726856, 'Mozilla/5.0 (Windows NT 6.2; sl-SI; rv:1.9.0.20) Gecko/20150207 Firefox/13.0', 'Eveniet veritatis nihil architecto rerum. Ex sequi quia repellat distinctio rerum. Maxime aliquam quo quo ipsum deserunt tenetur. Sunt fugiat veniam repellendus perferendis.', '2022-05-30 20:57:27'),
(1785701, 'Mozilla/5.0 (X11; Linuxx86_64; rv:7.0) Gecko/20150103 Firefox/3.8', 'Et error assumenda enim quis dolor quis quo. Laudantium blanditiis repellendus numquam a quas. Qui ut excepturi nemo molestiae voluptatem tenetur. Architecto sint rerum fugit culpa ad maiores.', '2011-01-21 12:52:49'),
(1788974, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5321 (KHTML, like Gecko) Chrome/15.0.879.0 Safari/5321', 'Sed non aut perspiciatis dolores consectetur quis. Maxime optio fuga quis est et. Eos ratione consequatur et neque.', '1993-09-23 04:42:21'),
(1792881, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_2 like Mac OS X; sl-SI) AppleWebKit/531.43.6 (KHTML, like Geck', 'Aspernatur enim ab quo minima. Sed dolor rem architecto ad deserunt quis sunt rerum. Magni et commodi eos quo sit est laborum. Omnis qui omnis optio aut non et.', '1986-01-06 16:43:48'),
(1810616, 'Mozilla/5.0 (Windows NT 6.0) AppleWebKit/5361 (KHTML, like Gecko) Chrome/15.0.870.0 Safari/5361', 'Sed voluptatem deserunt assumenda dicta quia placeat. Id aliquam recusandae odio dolore. Fugit id sint molestiae tempora maxime eius. Et quis vel quae molestias voluptatem.', '2023-08-25 15:40:35'),
(1859697, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows 98; Win 9x 4.90; Trident/5.1)', 'Nemo aut iusto quia id ratione fugit est. Porro qui placeat repudiandae omnis dolorem omnis voluptas. Fugiat ex consequatur laborum blanditiis iste dolor neque dolorem.', '2023-02-14 07:32:00'),
(1921385, 'Mozilla/5.0 (Windows NT 6.1; en-US; rv:1.9.2.20) Gecko/20170821 Firefox/3.8', 'Ab eos dolore ducimus ea qui molestias maiores. Aut neque molestias omnis dolores. Quis atque fugit qui quis soluta.', '1992-01-13 17:14:05'),
(1979400, 'Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/532.37.6 (KHTML, like Gecko) Version/4.0.1 Safa', 'Sint quia veniam qui totam. Quos sed beatae tenetur neque. Et occaecati et iure aspernatur.', '2012-10-07 14:29:38'),
(1982587, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_0 like Mac OS X; en-US) AppleWebKit/534.24.2 (KHTML, like Geck', 'Numquam et illo ut sit autem. Accusantium eos error maxime et. Quae enim facere aut fugiat veniam debitis consequatur.', '1976-07-25 11:09:46'),
(2058949, 'Mozilla/5.0 (Windows; U; Windows NT 5.01) AppleWebKit/535.15.2 (KHTML, like Gecko) Version/4.1 Safar', 'Laborum a et fuga quibusdam perferendis deleniti aut. Perspiciatis modi voluptatem voluptatum earum et sit qui est. Distinctio cumque praesentium sed rerum voluptas et aperiam itaque. Possimus dolor sapiente consequatur fuga.', '2019-06-10 12:13:58'),
(2108304, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_0 rv:2.0; sl-SI) AppleWebKit/532.7.2 (KHTML, like Gec', 'Ex pariatur occaecati ratione eos blanditiis ut et qui. Quidem impedit blanditiis rerum ipsum. Dolor vel cumque consequatur cum. Sapiente et tempora dolores iste et. Et natus corporis blanditiis aut et totam.', '2014-01-18 03:15:14'),
(2149260, 'Opera/8.46 (Windows NT 6.0; sl-SI) Presto/2.9.161 Version/11.00', 'Ex dolorum repellendus ea autem eveniet et. Aut consequuntur nihil in qui. Qui dolorum expedita quisquam ipsum ut et. Blanditiis dolorem autem ipsum a quo quidem.', '1973-10-15 17:37:12'),
(2195245, 'Opera/8.32 (Windows NT 5.1; en-US) Presto/2.9.189 Version/12.00', 'Deleniti culpa vitae nihil unde nulla quam. Nihil ea consequatur modi ratione. Veniam omnis voluptas ullam explicabo. Ducimus tenetur ad ratione a aliquid consequatur et.', '2006-09-03 13:31:34'),
(2260187, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5361 (KHTML, like Gecko) Chrome/13.0.826.0 Safari/5361', 'Nobis ullam ut pariatur sint perspiciatis. Sequi et delectus dicta error velit sequi. Laborum fugit pariatur non nihil.', '2010-11-13 06:52:21'),
(2353579, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/3.1)', 'Rerum tempore id non omnis beatae error. Autem dolorem voluptatum molestias magni vel sint velit. Quasi ab ea soluta ipsum ut doloribus.', '1994-12-13 06:36:49'),
(2499908, 'Mozilla/5.0 (Windows 98) AppleWebKit/5331 (KHTML, like Gecko) Chrome/14.0.893.0 Safari/5331', 'Doloremque impedit impedit qui voluptatem iste. Aut inventore unde rerum aut rem quaerat nisi. Nam sit repellat vel earum. Beatae eum iure sint error.', '1985-03-27 13:07:26'),
(2535791, 'Opera/9.94 (X11; Linuxx86_64; en-US) Presto/2.9.162 Version/10.00', 'Recusandae repudiandae eos et neque consequatur delectus nam. Magni esse omnis adipisci a.', '1983-08-09 06:28:00'),
(2758852, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.2; Trident/3.0)', 'Odit dolores aut aut eligendi illum impedit. Ipsum quia itaque voluptatem ratione voluptatum mollitia consequuntur iure. Reiciendis quia dolores placeat doloremque velit maiores rerum consequuntur. Consequatur fuga quam iure tempora quis. Dignissimos accusantium vero officiis libero dolorum.', '1996-11-10 13:21:12'),
(2776376, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5341 (KHTML, like Gecko) Chrome/14.0.869.0 Safari/5341', 'Libero nulla ut quod architecto repudiandae aut impedit est. Maiores dolores sed odit. Deleniti sed fugit et perspiciatis cumque ab velit. Vel quidem consequuntur autem expedita reprehenderit voluptatem recusandae. Cupiditate error alias blanditiis sit.', '1987-02-21 23:51:59'),
(2830202, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_6_9 rv:2.0) Gecko/20180822 Firefox/13.0', 'Dolorem officiis illo officiis. Molestiae consequatur laudantium veniam harum.', '1984-04-08 21:43:56'),
(2847782, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows 98; Trident/5.1)', 'Incidunt eius rem neque consequuntur ipsa fugiat. Et minima ut adipisci autem nostrum et. Asperiores voluptates autem dolore quis et autem suscipit occaecati. Qui earum quo dolorem ipsa.', '1983-01-08 12:29:20'),
(2876655, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows 98; Trident/4.1)', 'Qui aut quo esse sit tempora non voluptate vel. Voluptatem dolor commodi doloribus sint officiis tempora possimus. Voluptatibus sed totam earum asperiores qui. Deleniti sit error rem id sit. Blanditiis magni quos corrupti.', '2024-01-26 19:08:07'),
(2886541, 'Mozilla/5.0 (Windows 98) AppleWebKit/5351 (KHTML, like Gecko) Chrome/14.0.834.0 Safari/5351', 'Voluptatem nulla deleniti aspernatur. Nostrum et porro sit. Commodi eius qui ut.', '1972-11-26 23:51:53'),
(3129198, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_8_0) AppleWebKit/5351 (KHTML, like Gecko) Chrome/14.0.8', 'Perferendis ab aut quas enim quos maxime et fuga. Illum at consequuntur non qui. Qui eos inventore aut occaecati nisi.', '2017-12-28 07:43:20'),
(3241208, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 6.2; Trident/3.1)', 'Non non laudantium sint debitis id. Et quo et rerum sit veritatis. Praesentium enim ea quos qui et. Quasi soluta architecto necessitatibus architecto et. Enim reiciendis est enim repellat reiciendis non.', '1981-07-01 10:37:37'),
(3258366, 'Opera/8.58 (Windows NT 5.01; sl-SI) Presto/2.9.180 Version/11.00', 'Incidunt saepe nostrum pariatur id aut. Cupiditate et veritatis sint maxime dignissimos eligendi. Velit tenetur quidem suscipit aut dolore expedita quam.', '1984-02-06 09:54:27'),
(3488928, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows 95; Trident/4.1)', 'Expedita voluptas repudiandae eum autem deserunt tempora quo. Quod facere natus fugiat qui voluptas amet quam. Soluta maiores ut ipsa quia quibusdam ut tempora recusandae.', '1992-01-17 12:24:19'),
(3533854, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_6_1) AppleWebKit/5360 (KHTML, like Gecko) Chrome/15.0.818.0 ', 'Voluptatem harum commodi consectetur omnis et quis. Optio est incidunt enim fugiat qui sint et eos. Nisi molestiae tempora voluptas voluptatibus quaerat numquam blanditiis consequatur.', '2018-01-28 07:01:47'),
(3720351, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 4.0; Trident/3.1)', 'Delectus amet blanditiis ut velit a quia omnis voluptas. Perferendis iusto quas debitis consequuntur animi. Itaque asperiores aspernatur facere quia delectus. Vero repellendus velit aut mollitia laudantium eaque porro ex.', '2000-11-11 04:34:50'),
(3727297, 'Mozilla/5.0 (Windows; U; Windows 98) AppleWebKit/532.8.3 (KHTML, like Gecko) Version/4.0.4 Safari/53', 'Reprehenderit itaque nemo officiis architecto fugiat sed. Eligendi quo tenetur quis ducimus sunt dolorem. Tempore enim alias reprehenderit.', '2021-08-09 08:06:54'),
(3769760, 'Mozilla/5.0 (X11; Linuxi686; rv:5.0) Gecko/20150228 Firefox/4.0', 'Est laborum praesentium assumenda eos vel. Qui ex qui ipsam et recusandae. Et omnis beatae veniam dolor unde harum accusamus. Cupiditate inventore tempora placeat reprehenderit est laboriosam.', '1986-06-15 00:09:16'),
(3838306, 'Opera/8.13 (X11; Linuxx86_64; sl-SI) Presto/2.9.188 Version/11.00', 'Sit qui voluptatem distinctio illum quia natus. Quis ullam qui occaecati magni nesciunt. Occaecati et enim quia doloremque in modi dignissimos saepe. Labore nemo qui qui cumque ut iusto possimus.', '1993-02-24 20:18:18'),
(3843298, 'Opera/8.26 (Windows NT 6.2; en-US) Presto/2.9.163 Version/12.00', 'Corporis itaque voluptatem dignissimos commodi. Hic et et atque ea. Consequuntur unde necessitatibus ut esse voluptatibus quasi.', '2019-10-03 18:25:47'),
(3909925, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.01; Trident/3.1)', 'Sed est laudantium voluptatibus magni ex vitae. Possimus qui incidunt magni quos animi ut. Occaecati modi et fugit quidem beatae laudantium. Corrupti ea id veniam totam id quod repellendus.', '1970-04-04 16:12:55'),
(3956282, 'Mozilla/5.0 (Windows 98; en-US; rv:1.9.1.20) Gecko/20210504 Firefox/3.8', 'Commodi magnam voluptate corporis necessitatibus. Enim est voluptas praesentium. Voluptatem deleniti quis voluptate dolores temporibus harum qui.', '1993-03-17 21:15:12'),
(3962888, 'Opera/9.75 (X11; Linuxi686; en-US) Presto/2.9.166 Version/10.00', 'Hic hic voluptas quisquam vel rerum ut. Quia ut et aut vel. Rem corrupti quod et aut et cupiditate. Impedit eaque aut ratione officia veritatis veritatis.', '2001-03-05 18:10:42'),
(4166377, 'Opera/9.10 (Windows NT 5.2; en-US) Presto/2.9.161 Version/10.00', 'Eius distinctio repellendus modi voluptate. Neque natus qui aut qui corrupti qui. Ab qui suscipit adipisci iure.', '2000-05-15 18:02:36'),
(4171573, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_3 like Mac OS X; en-US) AppleWebKit/533.36.2 (KHTML, like Geck', 'Repellat sint qui explicabo voluptatum qui aut. Quam et error quisquam non. Natus eum similique commodi et culpa voluptatum.', '2022-12-18 19:44:12'),
(4261783, 'Opera/8.88 (Windows CE; sl-SI) Presto/2.9.172 Version/11.00', 'Non non repellendus et ipsam tempora ipsam. Aut eveniet sequi placeat quis. Molestias numquam molestiae animi officia.', '1993-03-01 14:05:43'),
(4304316, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_1 like Mac OS X; en-US) AppleWebKit/532.34.1 (KHTML, like Geck', 'Eaque veniam id iste soluta nobis. Omnis fugit eos velit qui laudantium odit. Corrupti reprehenderit quia qui quidem accusamus.', '1993-05-22 03:00:28'),
(4374128, 'Mozilla/5.0 (Windows NT 5.0; en-US; rv:1.9.2.20) Gecko/20110510 Firefox/3.6.17', 'Omnis molestiae saepe molestias consequatur molestias eum et. Rerum voluptatum et repellendus et enim cum. Magni dolores dolores perspiciatis mollitia nostrum id ut corporis. Officia et qui beatae illo.', '1989-01-12 22:24:01'),
(4441504, 'Opera/8.77 (Windows NT 6.2; en-US) Presto/2.9.187 Version/12.00', 'Nisi et aliquid quidem aspernatur. Sed sit illo recusandae quia.', '1981-02-15 16:00:15'),
(4532208, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 5.0; Trident/5.1)', 'Enim sunt vitae quasi magnam. Quis sit at exercitationem aliquid neque dolores. Magni quibusdam est impedit adipisci. Qui omnis laborum quasi quo.', '1991-04-03 20:50:07'),
(4607273, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_2 like Mac OS X; sl-SI) AppleWebKit/531.33.3 (KHTML, like Geck', 'Fugit voluptas modi aliquid ut optio ut atque. Ut corporis molestias odio eum et est. Quisquam velit blanditiis aperiam recusandae magnam aut hic. Quas quia velit harum dicta animi.', '2013-01-29 18:26:15'),
(4841668, 'Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/531.3.2 (KHTML, like Gecko) Version/5.0.4 Safar', 'Rerum enim sed ea nihil quia qui soluta culpa. Consequatur suscipit minus eos enim sit. Laborum sint voluptas architecto ut est et. Tempore voluptate dolor et et facere. Temporibus consequatur quo sunt minima quas.', '1994-10-06 00:33:37'),
(4853477, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_9) AppleWebKit/5350 (KHTML, like Gecko) Chrome/14.0.8', 'Est sunt nisi consequatur inventore. Neque est quaerat iure sed dolorum accusamus. Iste nostrum nihil aperiam unde debitis ipsam. Consequuntur voluptatem harum cupiditate est aut et quia error.', '2023-07-06 11:46:21'),
(4858134, 'Mozilla/5.0 (Windows 98; Win 9x 4.90; en-US; rv:1.9.2.20) Gecko/20220630 Firefox/3.8', 'Ipsum rem fuga voluptatibus earum. Animi repellat et earum maxime. Blanditiis officiis dolores unde eveniet.', '2015-03-31 21:01:41'),
(5185109, 'Opera/8.39 (X11; Linuxx86_64; en-US) Presto/2.9.177 Version/12.00', 'Officiis debitis aut necessitatibus sed velit. Aspernatur tenetur nihil quia omnis voluptate. Nisi eum maxime odit magnam velit totam.', '2012-11-01 02:35:46'),
(5201147, 'Mozilla/5.0 (Windows NT 5.01; en-US; rv:1.9.1.20) Gecko/20130310 Firefox/3.6.9', 'Porro enim sit nam et excepturi itaque laboriosam ipsum. Occaecati quo ut saepe eligendi eaque rerum ullam. Corrupti quibusdam et aperiam debitis placeat asperiores et. Corporis at voluptatem velit rerum dignissimos. Inventore qui nisi quasi quia est et non.', '2011-01-24 08:42:59'),
(5261750, 'Mozilla/5.0 (Windows NT 5.01) AppleWebKit/5331 (KHTML, like Gecko) Chrome/15.0.803.0 Safari/5331', 'Omnis quos veniam ut perferendis voluptatem. Quibusdam minima qui rem amet quam et sit dolores. Omnis alias voluptatem at et perferendis.', '1991-06-08 07:06:56'),
(5432149, 'Mozilla/5.0 (Windows NT 5.01; en-US; rv:1.9.2.20) Gecko/20220310 Firefox/13.0', 'Doloribus et minus inventore quibusdam veniam vero. Soluta blanditiis libero dignissimos magnam sit libero culpa. Labore impedit exercitationem corporis omnis iusto minus recusandae.', '2015-09-11 23:05:35'),
(5499820, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5330 (KHTML, like Gecko) Chrome/14.0.858.0 Safari/5330', 'Rem ipsam officia rerum tenetur adipisci nulla. Et nihil eveniet voluptatem quis. Ut atque sint repellat fugiat quas explicabo alias.', '1994-03-17 08:43:33'),
(5530367, 'Opera/8.82 (X11; Linuxx86_64; en-US) Presto/2.9.166 Version/12.00', 'Voluptates nulla consequatur facere voluptates sit. Dolor saepe illum est voluptates quia aut voluptates. Accusantium asperiores ullam sapiente nemo nulla.', '1971-02-21 12:06:02'),
(5533009, 'Mozilla/5.0 (X11; Linuxx86_64; rv:6.0) Gecko/20121213 Firefox/3.6.20', 'Non sunt distinctio iste qui explicabo modi voluptatem. Iusto perferendis ut beatae harum autem velit vel. Rem sit sequi eaque dolorem sequi assumenda.', '1972-05-30 16:17:35'),
(5671022, 'Opera/8.21 (X11; Linuxx86_64; sl-SI) Presto/2.9.170 Version/10.00', 'Et eius ipsam maxime vero. Aut qui dolorem omnis rerum et omnis corrupti. Voluptatem amet maxime quis voluptatem. Et error voluptatem veniam suscipit doloribus et.', '1985-03-24 00:59:41'),
(5693202, 'Mozilla/5.0 (Windows; U; Windows CE) AppleWebKit/532.39.6 (KHTML, like Gecko) Version/5.0 Safari/532', 'Quia officiis est tempora sed labore. Fugit vero voluptate suscipit recusandae eum dolor. Suscipit et dolorem animi quam dolorem dignissimos hic. Iste praesentium ullam id aut recusandae nesciunt praesentium.', '1988-01-11 17:09:09'),
(5851292, 'Mozilla/5.0 (Windows NT 5.1; sl-SI; rv:1.9.2.20) Gecko/20231203 Firefox/12.0', 'Et aut est reiciendis praesentium. Fugit itaque est quisquam minima et voluptate. Iusto est itaque nesciunt sit omnis perspiciatis commodi. Et assumenda ut voluptas esse rerum et.', '2002-05-25 09:21:41'),
(5863773, 'Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/535.20.1 (KHTML, like Gecko) Version/5.0 Safari', 'Esse laboriosam consequatur rerum quae. Ea nisi autem optio debitis. Totam eveniet quaerat dolore nam dolores ut. Fugit distinctio porro enim. Id et voluptate non dicta natus illum.', '1992-10-07 08:19:35'),
(5910341, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_8_5 rv:5.0; en-US) AppleWebKit/533.40.7 (KHTML, like Gecko) ', 'Ut eum quia quo. Quas accusantium rem aliquid et dolor esse quia. Repudiandae qui placeat tempora quasi. Qui ut esse libero voluptas.', '2017-05-15 15:42:05'),
(6173691, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_0 rv:2.0; sl-SI) AppleWebKit/533.20.3 (KHTML, like Gecko', 'Numquam natus est sequi repellendus quibusdam voluptatum earum. Sint omnis assumenda ut voluptatum officia repellat. Sit sunt iure culpa voluptatem quidem corrupti nostrum.', '2023-04-04 18:30:41'),
(6220283, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows 98; Trident/3.1)', 'Sit voluptatem voluptatem a ut atque. Repellat commodi voluptate nihil et. Sit est ut ut exercitationem cupiditate eum sunt voluptatem. Necessitatibus provident fugit consequuntur ea modi illum est.', '1981-02-10 20:01:46'),
(6228965, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_7 rv:6.0; sl-SI) AppleWebKit/534.20.1 (KHTML, like Gecko', 'Enim odio qui ut. Molestiae placeat animi ut nihil distinctio iusto aliquam. Quisquam eaque non mollitia saepe. Molestiae animi officia numquam.', '2013-01-06 20:08:27'),
(6337987, 'Mozilla/5.0 (X11; Linuxi686; rv:5.0) Gecko/20180629 Firefox/3.6.20', 'Inventore velit nam minus ab assumenda. Soluta recusandae perferendis consequuntur aperiam aut repellendus eius. Animi ut sit harum totam nisi.', '1973-10-12 20:00:19'),
(6340591, 'Mozilla/5.0 (Windows; U; Windows 98) AppleWebKit/533.21.5 (KHTML, like Gecko) Version/5.0.5 Safari/5', 'Et illum aut modi nihil laboriosam inventore nisi amet. Aut ex quaerat unde. Voluptas vero incidunt unde aut omnis sed voluptate eius. Dolorem minima dolor quidem excepturi rem. Dolorem in in dicta occaecati nobis.', '1979-09-03 23:23:36'),
(6342827, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_8_6 rv:3.0) Gecko/20180730 Firefox/3.6.13', 'Atque et quia laborum similique illo qui rem quae. Quas maiores eius iure non ut facilis. Assumenda praesentium doloremque voluptates reprehenderit illo dolorem unde.', '2000-05-26 21:04:35'),
(6373011, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 5.1; Trident/5.0)', 'Iste voluptate ducimus aliquam. Minus eveniet totam ut vitae. Rerum et eveniet et necessitatibus omnis. Quaerat sunt velit sed quaerat quis.', '1974-01-22 14:59:43'),
(6375170, 'Opera/9.48 (X11; Linuxx86_64; en-US) Presto/2.9.186 Version/12.00', 'Qui excepturi minima saepe et. Aspernatur totam culpa aspernatur delectus ullam voluptatum dicta. Dolores eum accusantium aut dolores voluptas.', '2013-05-12 20:00:06'),
(6401228, 'Mozilla/5.0 (Windows; U; Windows 98; Win 9x 4.90) AppleWebKit/532.35.3 (KHTML, like Gecko) Version/5', 'Reprehenderit molestias molestiae est est dolorum quos vel. Nisi numquam maiores neque mollitia voluptas tempora autem quia. Fuga dolor sunt sunt quibusdam reiciendis quam quidem et. Dolorum officia et fugiat repellat aut et eos.', '2017-01-24 07:38:27'),
(6554670, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows 95; Trident/5.0)', 'Autem voluptatum eum culpa rerum. Aut nam pariatur dolores et distinctio voluptatem. Molestias in hic aut et ut. Repellat sunt omnis quaerat dolorum.', '1984-05-02 12:47:53'),
(6631122, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_2 like Mac OS X; en-US) AppleWebKit/533.18.1 (KHTML, like Geck', 'Laborum consequatur rem et modi fugit. Et dolore iusto beatae eos. Nihil quibusdam velit culpa qui sunt. Libero soluta sunt hic cupiditate ratione similique distinctio. Sed aut et cumque qui.', '2001-07-07 14:06:34'),
(6647367, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows 95; Trident/5.0)', 'Vel qui perferendis adipisci dolores impedit eveniet. Natus quibusdam voluptas aut quod nulla. Ut aperiam fuga distinctio minus dolorem.', '2024-09-15 15:34:15'),
(6706668, 'Mozilla/5.0 (X11; Linuxi686; rv:6.0) Gecko/20191002 Firefox/3.6.1', 'At fugit doloribus magni ut quod. Ut sit officiis voluptatem ut reiciendis et dicta. Sit sequi accusantium corporis quod exercitationem. Quo quod quia temporibus qui et.', '2024-08-04 15:14:09'),
(6746412, 'Opera/8.21 (Windows NT 4.0; en-US) Presto/2.9.176 Version/12.00', 'Et consequatur architecto et consectetur sed est in. Sit ad ut nihil ea. Et adipisci at quam a velit sit repudiandae. Tempore sed sint voluptatem aut repellendus voluptas consequatur. Nesciunt temporibus architecto et praesentium et.', '2015-06-08 22:32:31'),
(6803847, 'Opera/8.75 (X11; Linuxx86_64; en-US) Presto/2.9.176 Version/10.00', 'Ut ipsam qui enim sunt at. Totam repudiandae voluptas illo aut nesciunt illum. A ut neque corrupti ut ducimus reiciendis. Maiores ut quis perspiciatis expedita et praesentium pariatur. Odit id vitae sunt sed.', '1978-09-11 22:55:20'),
(6822004, 'Opera/8.38 (Windows 98; sl-SI) Presto/2.9.175 Version/12.00', 'Velit eveniet dolorum sunt non in ut. Recusandae ipsum porro et repellat aliquid vero autem. Nesciunt distinctio commodi aliquam impedit dolorem repellendus blanditiis reiciendis. Possimus quisquam corrupti delectus eos assumenda placeat voluptas.', '1978-08-27 18:57:48'),
(6862970, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.0; Trident/3.0)', 'Provident quo sit sint nulla voluptatum sed. Quod quia perferendis quis voluptate dicta iure placeat. Veniam reiciendis dolor sapiente laborum. Rerum voluptas at aut vel voluptatem amet enim.', '1992-11-03 07:52:02'),
(7011913, 'Mozilla/5.0 (Windows; U; Windows NT 5.01) AppleWebKit/535.41.7 (KHTML, like Gecko) Version/4.1 Safar', 'Hic porro necessitatibus adipisci consequatur commodi non. Facilis quos voluptatem excepturi accusamus. Corporis eveniet odio voluptas eos quis a sint. Officia velit soluta inventore ipsum. Necessitatibus suscipit rerum fugit quaerat voluptates assumenda voluptatem.', '1975-11-27 21:37:54'),
(7027163, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_2 like Mac OS X; en-US) AppleWebKit/531.7.3 (KHTML, like Gecko', 'Nisi quia corrupti placeat consequatur ipsum. Nisi cum iure sint nesciunt. Perspiciatis dolores consequatur reiciendis architecto explicabo.', '1988-10-07 05:18:22'),
(7055968, 'Mozilla/5.0 (Windows 95; en-US; rv:1.9.2.20) Gecko/20110908 Firefox/5.0', 'Sed ducimus fugit officiis dignissimos. Nihil eveniet possimus et tempore recusandae. Sequi qui ut perferendis qui exercitationem. Deserunt odio unde quia dolores eos perferendis.', '1991-11-13 07:28:31'),
(7060250, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/5.1)', 'Magnam aut sapiente dolores qui. Porro reprehenderit id enim odio non. Sunt id temporibus cum voluptatum excepturi. Aliquid tempora exercitationem doloribus deleniti occaecati iste dolorum.', '2021-04-13 03:27:16'),
(7183746, 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/5310 (KHTML, like Gecko) Chrome/15.0.836.0 Safari/5310', 'Et corporis ab distinctio harum dolorem rerum. Explicabo aut itaque voluptates quo et. Tempora voluptas fugit non.', '2021-06-21 12:25:45'),
(7242754, 'Opera/9.55 (X11; Linuxx86_64; en-US) Presto/2.9.181 Version/10.00', 'Saepe dolores qui omnis provident voluptas assumenda dolores. Est non sed debitis quis non ad. Incidunt deserunt vel consequuntur et rem.', '2010-09-15 19:49:27'),
(7300566, 'Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/531.16.4 (KHTML, like Gecko) Version/4.0 Safari', 'Neque nisi tenetur sed ratione. Exercitationem quis necessitatibus est. Sit et modi corrupti nam ut. Aut eligendi dolorem laboriosam excepturi debitis provident suscipit.', '1994-05-13 12:26:24'),
(7311584, 'Opera/8.50 (X11; Linuxx86_64; sl-SI) Presto/2.9.190 Version/12.00', 'Odio praesentium nobis mollitia nisi rem doloribus. Saepe totam laboriosam itaque voluptatem. Corporis sunt tempora ratione soluta tenetur molestiae vero dolores. Aut tempore exercitationem fugiat laborum deserunt molestiae iure placeat.', '2018-06-13 15:45:13'),
(7360395, 'Opera/8.77 (Windows NT 5.2; sl-SI) Presto/2.9.184 Version/11.00', 'Est voluptas iste laborum sed voluptas. Et saepe labore cupiditate perspiciatis culpa praesentium aliquid. Tempore similique in odio nobis.', '1998-12-01 20:12:18'),
(7407445, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 5.1; Trident/3.1)', 'Sint placeat eos nihil quo dolorem est reiciendis. Et est neque optio et ea dolorem aliquam. Id repellat consequatur voluptates non est. Omnis qui aliquam eligendi earum doloremque. Hic quae repellat dolorem commodi sint ea tempora fugiat.', '1985-06-11 09:06:29'),
(7578775, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5341 (KHTML, like Gecko) Chrome/15.0.806.0 Safari/5341', 'Et voluptatem reprehenderit ut nihil nemo amet atque. Facere eius non necessitatibus laudantium corporis delectus. Provident blanditiis ut voluptates natus dolorum.', '1971-05-06 23:14:55'),
(7598696, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.0; Trident/3.0)', 'Magnam porro quae perspiciatis ipsum quod. Deserunt ducimus et exercitationem quis. Ad cupiditate quia in assumenda voluptas. Corrupti laudantium soluta ipsam sit consequatur ut.', '1993-02-02 20:31:04'),
(7698771, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_4) AppleWebKit/5332 (KHTML, like Gecko) Chrome/13.0.865.', 'Ratione odit eos voluptas accusantium consequatur dignissimos error. Laudantium reiciendis quis vitae modi. Ut quod omnis rerum doloribus nemo. Esse et corporis ut porro voluptatem ea.', '1992-11-02 11:54:50'),
(7770079, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5320 (KHTML, like Gecko) Chrome/15.0.885.0 Safari/5320', 'Enim tempore quia id incidunt ea minus est fuga. Aperiam exercitationem rerum quia quis itaque optio omnis. Id ut quos et rerum sed harum. In dolores eveniet excepturi voluptate autem.', '1990-08-10 20:28:21'),
(7850504, 'Mozilla/5.0 (Windows NT 5.2) AppleWebKit/5322 (KHTML, like Gecko) Chrome/13.0.810.0 Safari/5322', 'Aspernatur omnis dicta perspiciatis quia cum incidunt. Dignissimos modi dolorem aliquid nemo dolorum sit repellendus. Ipsa doloribus quis ipsum eveniet.', '2019-06-01 20:29:25'),
(7880981, 'Opera/8.39 (X11; Linuxi686; en-US) Presto/2.9.184 Version/12.00', 'Velit pariatur illum tempore sint. Omnis dolores odit tenetur. Amet et amet ad possimus exercitationem qui corporis nulla. Perferendis cupiditate inventore officiis id unde culpa sequi sed.', '2008-06-04 09:09:55'),
(7909100, 'Mozilla/5.0 (Windows NT 4.0) AppleWebKit/5350 (KHTML, like Gecko) Chrome/14.0.804.0 Safari/5350', 'Delectus quibusdam molestias delectus rerum vel eveniet vero quia. Sint aut mollitia est quo cupiditate et aliquam. Ad praesentium dolores veniam molestias quia totam.', '1973-05-25 13:45:20'),
(7960843, 'Mozilla/5.0 (X11; Linuxi686; rv:7.0) Gecko/20241125 Firefox/4.0', 'Illo rem corporis ab molestiae perferendis asperiores. Quaerat omnis dolores quas ut. Ut est deleniti aut.', '2010-04-30 17:48:50'),
(8089646, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/3.1)', 'Reprehenderit veniam et est. Sed iste impedit suscipit enim pariatur aut iste. Dolorum enim esse in facere minus eum sit. Natus et inventore voluptas sunt reprehenderit. Assumenda quas fugit aut deserunt dignissimos.', '2016-07-28 20:20:24'),
(8352640, 'Opera/9.96 (X11; Linuxx86_64; sl-SI) Presto/2.9.182 Version/11.00', 'Consequatur in sequi aut. Quasi voluptatem et et officia. Qui optio adipisci sed voluptas non.', '1983-02-10 12:04:08'),
(8363107, 'Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/532.12.5 (KHTML, like Gecko) Version/5.0.4 Safa', 'Et tenetur qui assumenda voluptatem. Quod autem hic quibusdam sapiente dolorem dolores libero rerum.', '2009-09-12 12:40:53'),
(8520685, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_7_7 rv:2.0) Gecko/20180117 Firefox/3.8', 'Nemo cum laboriosam aut inventore laboriosam. Quos explicabo maxime molestiae perferendis vero autem nisi. Vel unde voluptate cupiditate.', '1983-07-09 03:43:30'),
(8669320, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_6_1) AppleWebKit/5331 (KHTML, like Gecko) Chrome/13.0.868.0 ', 'Et quis porro odit ipsam cupiditate aut nisi. Nesciunt commodi voluptas sunt voluptatem sed. Autem quae corporis voluptas illum dolor minima fugit. Qui officiis assumenda sit sit cum nulla aut.', '1973-01-17 20:55:10'),
(8695327, 'Opera/8.36 (X11; Linuxx86_64; sl-SI) Presto/2.9.170 Version/11.00', 'Dignissimos accusamus molestiae ut deleniti quae iusto. Et sapiente vel animi tempore distinctio. Veritatis rerum inventore et occaecati quidem qui. Inventore consequatur voluptatum sit velit sapiente. Est sit id consectetur enim.', '1975-10-06 19:25:13'),
(8833299, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_0 like Mac OS X; sl-SI) AppleWebKit/532.39.4 (KHTML, like Geck', 'Fugiat asperiores natus et aut ipsam reprehenderit. Minima est omnis fuga quasi voluptas et qui. Omnis est deserunt itaque cupiditate.', '1980-03-05 14:55:16'),
(8915354, 'Opera/8.65 (Windows NT 5.01; en-US) Presto/2.9.163 Version/12.00', 'Aut omnis rem veniam dolore sint aut et. Ipsa dolor id est magni rerum recusandae. Aliquid rerum qui quaerat dolor totam aut.', '2013-05-19 05:51:31'),
(8946698, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_7) AppleWebKit/5322 (KHTML, like Gecko) Chrome/15.0.8', 'Occaecati cum aliquam velit suscipit. Reiciendis recusandae quos facilis possimus debitis corporis voluptatem quis. Ducimus mollitia placeat et.', '1999-04-03 23:42:18'),
(9003296, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_0 like Mac OS X; en-US) AppleWebKit/533.38.6 (KHTML, like Geck', 'Aut minus vero cum hic aliquid velit. Quod ea cum non dolor. Dolorem quia temporibus aspernatur tempora. Qui fuga non et quas quis blanditiis.', '1999-02-11 06:53:42'),
(9100130, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5310 (KHTML, like Gecko) Chrome/13.0.864.0 Safari/5310', 'Error eius quaerat ullam molestiae adipisci assumenda. Neque commodi sed adipisci accusamus est consequatur. Qui quibusdam itaque quia totam quos.', '1976-06-23 14:05:40'),
(9187385, 'Mozilla/5.0 (X11; Linuxx86_64; rv:6.0) Gecko/20160218 Firefox/3.8', 'Magnam accusantium in magnam aliquid dolores et est est. Aspernatur qui ad sapiente quaerat nemo aut molestiae a. Est placeat fugit assumenda occaecati expedita quia. Repudiandae exercitationem optio vel vitae est aliquid doloremque.', '2001-03-28 16:43:55'),
(9301822, 'Mozilla/5.0 (X11; Linuxi686; rv:5.0) Gecko/20200716 Firefox/15.0', 'Vel eos consequatur illo reprehenderit suscipit sed magnam voluptatibus. Et nihil accusamus sunt. Ad nobis ut voluptatum quis.', '1990-02-10 13:24:41'),
(9321400, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_0 like Mac OS X; sl-SI) AppleWebKit/533.49.7 (KHTML, like Geck', 'Sed est et nulla quis aliquid incidunt dolor. Iste nam deserunt repellendus itaque. Ut necessitatibus doloremque non.', '1987-04-07 15:23:35'),
(9335865, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.0; Trident/4.0)', 'Omnis magni ut voluptas sint. Debitis odio voluptate quod ut. Pariatur et accusamus perspiciatis non.', '1977-07-05 15:28:42'),
(9501486, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_1 rv:2.0; en-US) AppleWebKit/532.30.5 (KHTML, like Gecko', 'Sint autem itaque provident non commodi iste. Eligendi enim nostrum modi corporis odio.', '2012-08-15 22:14:40'),
(9530334, 'Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/532.18.6 (KHTML, like Gecko) Version/4.0.5 Safa', 'Molestias error dolor ea qui totam ad impedit. Et quo libero deserunt omnis totam eaque. Iure nemo est voluptate iusto molestias. Suscipit molestiae et magni eveniet sapiente. Sed inventore quidem labore numquam sunt iste pariatur.', '2011-11-04 23:45:52'),
(9554287, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8 rv:5.0; en-US) AppleWebKit/534.24.5 (KHTML, like Gecko', 'Exercitationem accusamus nam dolor fuga ea quibusdam. Est perferendis velit sed ut eum ipsam.', '1998-01-02 23:18:29'),
(9649226, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 4.0; Trident/5.0)', 'Nostrum sapiente autem tempore itaque ut nostrum beatae. Repudiandae et ea ducimus minima. Et velit nisi sunt quod. Odit est delectus earum quia. Qui in vitae iste id ut facilis.', '1988-10-31 22:38:25'),
(9660494, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 5.1; Trident/4.1)', 'Suscipit tempora architecto velit impedit. Delectus veritatis sapiente fugit eius dignissimos.', '2001-11-29 15:26:48');
INSERT INTO `categories` (`id`, `name`, `description`, `created_at`) VALUES
(9695865, 'Mozilla/5.0 (Windows NT 5.0; en-US; rv:1.9.1.20) Gecko/20230710 Firefox/3.8', 'At dolore provident necessitatibus distinctio cupiditate eveniet rerum laudantium. Qui et velit ducimus saepe. Quia voluptas ipsam dicta consectetur dolorem aut reiciendis. Velit sit quos cumque aut quasi dignissimos eos. Eum fuga voluptas libero possimus commodi laborum et.', '1988-04-04 12:22:01'),
(9707314, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows 98; Win 9x 4.90; Trident/3.1)', 'Corporis ullam sapiente exercitationem sit molestiae velit hic. Quidem rerum ratione eaque. Saepe consectetur libero aut suscipit quis. Repellat nisi occaecati eveniet sint quia minima.', '1974-11-19 03:00:28'),
(9721639, 'Mozilla/5.0 (X11; Linuxi686; rv:5.0) Gecko/20110518 Firefox/3.8', 'Qui quam eum sint doloribus dolorum fuga. Sint quod dolorem quos saepe voluptatem. Similique dicta suscipit est cumque.', '1986-04-23 07:19:08'),
(9859785, 'Opera/9.24 (Windows NT 6.1; en-US) Presto/2.9.163 Version/10.00', 'Amet cum amet aut. Vero sed a officia omnis dolorem animi. Enim deleniti odio sed corrupti.', '1979-04-04 16:36:04'),
(9876644, 'Mozilla/5.0 (Windows NT 6.2) AppleWebKit/5340 (KHTML, like Gecko) Chrome/13.0.819.0 Safari/5340', 'Velit dicta dicta delectus sit et totam. Ipsa inventore voluptatum ut voluptate assumenda. Iste nulla et non quia. Occaecati doloribus totam aut.', '2016-01-30 00:23:14'),
(9884694, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_7_4 rv:5.0; en-US) AppleWebKit/532.5.1 (KHTML, like Gecko', 'Rerum beatae ullam corrupti assumenda minus dolores deserunt. Hic nesciunt minima iste molestiae cumque repellendus. Et quod ab repudiandae enim.', '2010-06-04 02:46:25'),
(9893976, 'Mozilla/5.0 (Windows NT 5.01) AppleWebKit/5361 (KHTML, like Gecko) Chrome/13.0.885.0 Safari/5361', 'Nam impedit magnam qui omnis. Possimus ullam possimus dolorem qui qui dolorem blanditiis et. Possimus sed accusantium iure veniam iste.', '1994-03-24 07:37:45'),
(12438107, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.1)', 'Et reiciendis eligendi dolor nihil sunt quia ut. Minus modi ipsa aspernatur et amet praesentium. Explicabo dolor aliquid consectetur et similique cumque. Occaecati reprehenderit consectetur dolores et at ducimus.', '2013-08-21 23:28:49'),
(12709475, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_8_1) AppleWebKit/5342 (KHTML, like Gecko) Chrome/13.0.806', 'Fugit rem illo itaque voluptatibus libero nobis omnis. Ipsam amet quis enim mollitia modi nisi neque. Neque velit tempora veniam quis. Corporis dolorem nostrum praesentium autem consequatur.', '2015-01-29 01:23:22'),
(13550700, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_8_1) AppleWebKit/5312 (KHTML, like Gecko) Chrome/15.0.838.0 ', 'In id est id odio voluptatibus. Harum velit porro corrupti debitis aut. Totam soluta autem quo beatae mollitia libero placeat.', '1983-11-02 08:13:46'),
(13731578, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.2; Trident/4.1)', 'Ut nesciunt adipisci mollitia enim tenetur hic voluptatum. Qui nulla ipsa qui voluptatem accusamus distinctio aut vitae. Ullam velit qui qui harum perferendis deleniti similique. Architecto delectus voluptatem sit delectus. Sed mollitia qui et necessitatibus.', '2018-04-27 17:30:33'),
(13745346, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_0 like Mac OS X; en-US) AppleWebKit/533.46.1 (KHTML, like Geck', 'Aperiam ab quibusdam eaque sequi eos voluptas. Officiis tenetur est dolore rerum. Minima optio sequi ad omnis magnam minus assumenda.', '1977-03-12 14:07:07'),
(14188515, 'Opera/8.10 (Windows NT 6.0; en-US) Presto/2.9.181 Version/12.00', 'Sint quo repellendus et. Sequi eos enim impedit. In qui quo consequatur enim mollitia.', '2014-09-01 04:08:34'),
(14918688, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.0; Trident/5.1)', 'Vero quisquam aspernatur neque sit nemo voluptatem suscipit rem. Iure exercitationem eveniet rerum. Omnis ad natus commodi suscipit adipisci illum quos.', '1970-09-07 16:46:38'),
(15296200, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 5.01; Trident/3.0)', 'Sit sint rerum est voluptatibus dolorem. Sunt sit eum error in magni officia. Ducimus vel dicta delectus est esse. Voluptas quibusdam ad dolores impedit. Labore quibusdam totam blanditiis molestiae quas iure deserunt.', '2018-08-16 14:29:39'),
(18165329, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.2; Trident/3.1)', 'Facere aperiam nihil quod ipsam a. Repellendus aspernatur temporibus architecto explicabo quia aut. Tenetur et ea et ipsum totam omnis. Et sed non enim aut.', '1995-07-12 17:58:57'),
(18248408, 'Mozilla/5.0 (X11; Linuxx86_64; rv:5.0) Gecko/20221104 Firefox/3.6.14', 'Praesentium saepe animi est dolores sit dolorem quidem. Eveniet eos suscipit id sit. Atque illo fuga quia labore.', '2005-12-01 17:56:16'),
(19138654, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_1 rv:5.0) Gecko/20120113 Firefox/3.8', 'Non alias omnis et qui odio. Ducimus mollitia possimus doloremque est. Est quos dolorem saepe.', '2025-01-24 17:16:54'),
(22005578, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/5.1)', 'Est qui perferendis et dolorum tempore recusandae. Nihil quia aperiam nisi voluptas saepe. Quis aliquam et non delectus. Cum consequatur non est consequatur.', '1998-01-16 16:24:08'),
(22671417, 'Opera/8.12 (Windows 98; sl-SI) Presto/2.9.160 Version/11.00', 'Sed in tenetur dolor est adipisci. Tempora consequatur impedit sit quod rerum et hic. Nisi quia eligendi enim expedita pariatur ut omnis. Ut architecto sequi et consectetur est laborum nihil. Iusto cupiditate maxime magni rem tempore temporibus illo est.', '2024-12-12 10:20:59'),
(22784466, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows 95; Trident/3.1)', 'Fugiat iusto unde ad unde sed quidem ut. Minus saepe non error. Aspernatur omnis sint sint repellendus dignissimos et et.', '2022-10-30 06:54:28'),
(23042803, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5320 (KHTML, like Gecko) Chrome/13.0.829.0 Safari/5320', 'Rerum dolor eius qui sint possimus temporibus vel neque. Occaecati possimus ratione necessitatibus quasi labore est molestiae. Quos quae ab aperiam est.', '1981-07-16 08:22:06'),
(23700583, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_2 like Mac OS X; sl-SI) AppleWebKit/533.19.1 (KHTML, like Geck', 'Dignissimos nesciunt voluptatum et inventore. Modi quis et dolorum numquam mollitia voluptate. Excepturi expedita neque quae maxime et. Sequi vitae ut corrupti eum.', '2018-10-20 23:26:49'),
(25450346, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows CE; Trident/3.0)', 'Facilis sint reprehenderit possimus qui debitis. Mollitia quaerat voluptatem in sit exercitationem cum et. Aut et voluptatem nihil et. Non et reprehenderit aut est est quod.', '2009-03-16 21:45:10'),
(26641454, 'Mozilla/5.0 (X11; Linuxx86_64; rv:6.0) Gecko/20240907 Firefox/3.8', 'Eos totam itaque sunt nihil velit iste sit. Est quis officia dolorum nulla blanditiis sit aspernatur adipisci. Ut facere nihil iste quod. Laborum a velit praesentium voluptatem odio cupiditate.', '1984-12-29 12:47:59'),
(29263546, 'Opera/9.23 (Windows 98; Win 9x 4.90; en-US) Presto/2.9.163 Version/10.00', 'Omnis temporibus eum dolor veritatis. Aut est ducimus velit quam voluptatem eligendi vel. Facilis et molestiae quo sed voluptatem vel veritatis.', '1994-04-01 07:19:36'),
(30269892, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 6.2; Trident/4.1)', 'Non amet quidem unde quis in. Qui placeat magnam earum ut libero. Mollitia sunt sapiente quia nesciunt et tempora est. Impedit dolore iste ipsa ea non eligendi.', '1981-03-02 19:34:24'),
(31267929, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows 98; Trident/5.1)', 'Ut laudantium ea consequatur voluptatem vel. Et iusto aut natus cupiditate eos. Id nihil ut fugiat quia. Ut quis omnis aut autem.', '2024-09-23 19:20:30'),
(32015823, 'Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/532.40.7 (KHTML, like Gecko) Version/4.0.4 Safa', 'Distinctio eum quo ut nisi. Rerum consequatur et sapiente unde rerum. Et voluptatem et dolor consequatur illo. Ipsum sed maxime iusto optio.', '1987-07-12 19:07:02'),
(33192947, 'Mozilla/5.0 (Windows NT 6.2) AppleWebKit/5362 (KHTML, like Gecko) Chrome/15.0.899.0 Safari/5362', 'Est qui minus ullam veritatis eos autem culpa. Occaecati molestias necessitatibus deserunt. Dignissimos ad distinctio qui sunt quos ut dolorum.', '1984-09-17 18:56:28'),
(34649406, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5351 (KHTML, like Gecko) Chrome/15.0.879.0 Safari/5351', 'Ducimus nihil voluptates architecto impedit aut asperiores repellendus. Quia blanditiis praesentium ipsam vitae ut. Quo hic quos sit quasi exercitationem. Earum aliquam asperiores adipisci.', '1984-01-14 22:20:09'),
(34740455, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows 95; Trident/3.1)', 'Error qui quam magnam aperiam quae omnis facilis. Et laborum dolorem ullam pariatur. Nam reprehenderit ut dicta libero. Praesentium et nesciunt numquam ipsum qui iusto eos.', '2025-02-18 10:30:10'),
(35041883, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_6_2 rv:5.0) Gecko/20250412 Firefox/3.6.12', 'Voluptatem odio nemo id natus eos. Incidunt eum dolor expedita laborum incidunt. Est et debitis impedit voluptas totam voluptatibus.', '2022-01-15 16:19:19'),
(35916731, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0; Trident/5.1)', 'Enim autem libero perspiciatis totam molestiae eveniet vel velit. Repellendus voluptatibus reprehenderit dolorem vitae voluptatum quia distinctio delectus.', '1973-12-09 00:19:22'),
(36015756, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_3 like Mac OS X; sl-SI) AppleWebKit/533.15.6 (KHTML, like Geck', 'Et libero quia amet sed corporis nisi. Cumque neque ut pariatur voluptatem explicabo. Sunt ut est id quia. Expedita minus quo qui.', '2002-05-02 08:38:55'),
(36901952, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_5_3) AppleWebKit/5310 (KHTML, like Gecko) Chrome/15.0.873', 'Aliquid minus sed aliquam quae quia laboriosam commodi. Fugit distinctio quis quis. Porro sit fugit at. Laudantium animi eum quia velit ratione dignissimos.', '2013-02-20 16:57:02'),
(37101801, 'Opera/8.63 (Windows NT 5.1; en-US) Presto/2.9.190 Version/11.00', 'Dicta modi officia perspiciatis ipsa alias. Molestiae ducimus sint quam.', '2019-12-09 02:59:55'),
(38962871, 'Opera/9.13 (X11; Linuxi686; sl-SI) Presto/2.9.162 Version/10.00', 'Distinctio at ut fugit reprehenderit corporis. Laboriosam dolorem dicta ex iste sit aliquam illo. Dolores voluptatibus consequatur possimus.', '1972-08-22 02:47:09'),
(39505499, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_7_1) AppleWebKit/5311 (KHTML, like Gecko) Chrome/15.0.861.0 ', 'Et aliquid officia delectus aliquid quod nam. Saepe ipsa doloribus et delectus non magnam. Voluptatem repellendus eaque labore voluptas. Nostrum excepturi facilis iste illo provident ipsa.', '2000-01-03 19:52:36'),
(40564071, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.1; Trident/3.0)', 'Corporis velit omnis veritatis consequuntur. Dolore repudiandae perferendis recusandae ullam sunt laudantium provident. Reiciendis asperiores cumque tempore et. Voluptatem hic ea quod quis atque nihil ut maxime.', '2004-01-20 01:50:21'),
(40837288, 'Opera/9.84 (X11; Linuxx86_64; sl-SI) Presto/2.9.189 Version/10.00', 'Ad consequatur possimus voluptas culpa quod. Quo enim nihil aut quod iure non in. Ipsam officiis sed ut in doloremque.', '1981-11-22 06:37:21'),
(41255602, 'Mozilla/5.0 (X11; Linuxx86_64; rv:5.0) Gecko/20120519 Firefox/3.8', 'Nemo enim consectetur fugiat iste. Perspiciatis est corrupti voluptatem. Nostrum sit voluptatem aut. Voluptas officiis saepe in nulla voluptatum.', '1981-12-10 13:34:00'),
(41279004, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.1; Trident/5.0)', 'Ut quis aut labore dolores repudiandae. Qui veniam explicabo asperiores veniam tenetur est. Neque fuga exercitationem minus non.', '1998-02-03 04:32:13'),
(41826542, 'Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/535.1.3 (KHTML, like Gecko) Version/4.0.2 Safar', 'Numquam ut ut ipsum. Enim animi in recusandae veniam nam accusamus.', '1974-03-10 23:59:25'),
(42513310, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_6_4 rv:2.0) Gecko/20160720 Firefox/3.6.7', 'Aut nostrum officia ut dolor sit rerum aut. Non omnis repudiandae dicta sit sunt.', '1986-10-22 02:59:56'),
(43050550, 'Mozilla/5.0 (Windows 98; Win 9x 4.90) AppleWebKit/5320 (KHTML, like Gecko) Chrome/14.0.879.0 Safari/', 'Voluptate repellat impedit ea facilis. Perferendis fugiat quos in velit placeat omnis nam.', '1980-01-09 22:23:50'),
(43293551, 'Opera/9.55 (Windows CE; sl-SI) Presto/2.9.168 Version/12.00', 'Cum quidem beatae aliquam dolore et qui amet. Sint aut quis doloribus impedit et. Magnam provident qui quia eveniet. Consequuntur enim necessitatibus est et eius debitis beatae.', '1976-12-21 14:33:32'),
(44121974, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 6.2; Trident/3.0)', 'Ut illum est quis ut voluptas. Sint totam veritatis sit rem id. Eligendi modi quas consectetur culpa. Illum eos ratione sunt.', '2013-05-09 07:35:25'),
(44645016, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5320 (KHTML, like Gecko) Chrome/14.0.855.0 Safari/5320', 'Enim autem nihil aliquam autem. Pariatur voluptas totam nemo laboriosam modi quia quia. Qui doloremque et dolorum. Nihil suscipit fugiat ut perferendis tempora.', '2012-01-08 15:33:38'),
(44823062, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_0 like Mac OS X; sl-SI) AppleWebKit/532.33.5 (KHTML, like Geck', 'Quis aspernatur fuga quod qui hic. Sequi quae provident delectus aut reiciendis impedit. Et quidem quasi reprehenderit necessitatibus sequi. Soluta non voluptatum molestiae at.', '2002-04-15 06:08:14'),
(45290414, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_0 like Mac OS X; sl-SI) AppleWebKit/535.21.6 (KHTML, like Geck', 'Fuga voluptatibus ut ut repudiandae ducimus saepe. Omnis quasi consectetur commodi consequatur sint.', '1982-02-09 16:12:18'),
(45690038, 'Opera/9.94 (X11; Linuxi686; sl-SI) Presto/2.9.185 Version/11.00', 'Doloremque qui neque dolor consequatur quasi dolor dolores. Cupiditate aut iste voluptatem voluptates nihil repellendus maxime. Aut alias dolor quis nulla. Repellat earum aut ea nisi.', '1974-03-06 22:38:55'),
(46489742, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_5 rv:2.0; sl-SI) AppleWebKit/535.47.3 (KHTML, like Ge', 'Qui illo quae officiis asperiores ducimus. Provident possimus ipsum quos. Magni sunt quia non.', '1990-02-14 05:40:00'),
(46673590, 'Opera/8.18 (Windows 95; sl-SI) Presto/2.9.188 Version/11.00', 'Cumque mollitia natus assumenda consequuntur. Iusto adipisci architecto modi. Aliquid beatae debitis est dolorem fugiat. Sapiente iste perspiciatis corporis id amet aut in quasi. Deserunt recusandae corporis reprehenderit repellat.', '1973-06-25 22:20:53'),
(47476926, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 5.01; Trident/4.1)', 'Ad est similique autem omnis accusamus ut. Aliquid et minima explicabo enim rem fugit. Aliquid non occaecati sed nesciunt odio enim molestiae. Quod voluptates quibusdam est voluptatum.', '2025-01-06 15:12:29'),
(48003022, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_6_4 rv:2.0; sl-SI) AppleWebKit/531.45.5 (KHTML, like Gecko) ', 'Ut error vel et odit. Ea nihil ad culpa quae. Porro ad voluptatem et facere sit sunt qui et. Molestiae ea laudantium ab qui aliquam.', '2021-11-01 05:33:22'),
(49926279, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 5.2; Trident/4.0)', 'Et consequatur quis veniam quia nemo voluptas ex. Qui doloribus numquam corporis voluptate sunt commodi. Provident quaerat sint in eveniet ut.', '1979-03-20 18:45:18'),
(50061278, 'Mozilla/5.0 (X11; Linuxi686; rv:7.0) Gecko/20211108 Firefox/9.0', 'Ex repellat quia qui distinctio ducimus placeat reiciendis. Omnis omnis fuga alias ducimus.', '2009-07-02 19:59:46'),
(50694612, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5361 (KHTML, like Gecko) Chrome/14.0.838.0 Safari/5361', 'Non adipisci labore dolore voluptas repudiandae. Non explicabo sed non. Consequuntur suscipit culpa commodi.', '1988-06-28 19:50:20'),
(50935297, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 5.0; Trident/4.1)', 'Assumenda sed et veritatis totam saepe autem labore est. Sint optio eum recusandae fugiat nesciunt est. Quasi voluptates quaerat magnam repellendus cupiditate totam a voluptas.', '1979-07-28 02:32:45'),
(50963722, 'Opera/8.57 (X11; Linuxx86_64; en-US) Presto/2.9.190 Version/12.00', 'Dolorum laudantium quam dolorum distinctio error dolorum reprehenderit. Ducimus consectetur pariatur eius quam. Cum est sit voluptatum repudiandae repellendus.', '2012-04-10 03:04:42'),
(52008132, 'Mozilla/5.0 (X11; Linuxi686; rv:6.0) Gecko/20160917 Firefox/3.8', 'Iusto hic quis in optio tempora voluptas. Distinctio et fugit quis repellat non et ipsa. Temporibus voluptatem dolores ut voluptatibus et. Culpa voluptas quia consequatur voluptates et nobis.', '1994-10-04 02:40:04'),
(52149216, 'Opera/8.33 (X11; Linuxx86_64; en-US) Presto/2.9.178 Version/12.00', 'Aspernatur corporis quo hic magnam et unde. Ad nulla in non atque quae. Ducimus delectus molestias rerum eos porro temporibus numquam.', '1975-09-21 02:31:36'),
(52212938, 'Mozilla/5.0 (Windows; U; Windows 98) AppleWebKit/535.38.3 (KHTML, like Gecko) Version/5.0.4 Safari/5', 'Cum sunt ut exercitationem. Fugiat et beatae dolorem ullam. Hic distinctio ullam nemo ab vel repellat autem.', '1986-03-19 21:27:06'),
(52977505, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_5_3) AppleWebKit/5330 (KHTML, like Gecko) Chrome/15.0.857.0 ', 'Et ratione rerum ex aut mollitia recusandae. Id deleniti eos dolorem quas.', '2002-05-04 23:51:14'),
(54102293, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_5_9 rv:2.0; en-US) AppleWebKit/534.11.2 (KHTML, like Geck', 'Animi sit enim vel molestias eius saepe ipsam nulla. Et deserunt consectetur quo hic. Qui id delectus dignissimos omnis. Voluptatem fuga inventore pariatur occaecati. Quis veniam non minus facilis.', '2013-08-01 18:21:14'),
(54354578, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5342 (KHTML, like Gecko) Chrome/15.0.855.0 Safari/5342', 'Quam consequuntur sed aperiam quia iure laborum hic perferendis. Et asperiores aspernatur quo vel quis iste. Reiciendis dolores placeat qui amet.', '2021-01-14 13:51:36'),
(56277138, 'Opera/8.34 (X11; Linuxx86_64; sl-SI) Presto/2.9.168 Version/10.00', 'Non tenetur in quia neque excepturi placeat totam. Sint assumenda consequatur aut assumenda omnis. Nulla provident porro omnis ullam ut.', '1989-07-30 15:46:08'),
(56678017, 'Mozilla/5.0 (X11; Linuxi686; rv:5.0) Gecko/20141216 Firefox/15.0', 'Necessitatibus sit odit enim suscipit. Odit suscipit dolorem sequi suscipit ipsa sed quia. Rerum molestiae sapiente blanditiis adipisci ut eum.', '1989-04-28 20:09:20'),
(60329688, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows CE; Trident/5.1)', 'Odio expedita officia ratione rem dolorum velit. Voluptas ipsum temporibus autem. Est et aut est repellendus itaque.', '1990-05-07 05:48:54'),
(60827739, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_3 like Mac OS X; sl-SI) AppleWebKit/535.46.3 (KHTML, like Geck', 'Cumque doloribus qui rerum pariatur sequi sit aliquid. Molestiae odit qui officia. Laborum quis nostrum veritatis et officia.', '2016-01-14 05:00:22'),
(60883656, 'Mozilla/5.0 (X11; Linuxx86_64; rv:6.0) Gecko/20140225 Firefox/3.8', 'Perspiciatis architecto non impedit necessitatibus quod sint illo ut. Quis vero minima aut dicta. Perferendis et repellendus ex sit officia rem.', '2014-05-09 11:55:25'),
(60984196, 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/5361 (KHTML, like Gecko) Chrome/15.0.800.0 Safari/5361', 'Dolores animi et blanditiis earum. Quia tempore illum atque ab. Molestiae ut est sint et quos.', '2018-07-31 03:42:03'),
(62071223, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_6_6 rv:5.0) Gecko/20240216 Firefox/4.0', 'Vel quia et et similique saepe. Quia repellat doloremque nemo doloribus beatae ipsa. Ea omnis nesciunt error eveniet aut. Excepturi qui dolorem neque eum.', '2013-08-06 22:41:52'),
(63061212, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_3 like Mac OS X; en-US) AppleWebKit/533.41.3 (KHTML, like Geck', 'Aut repellendus id fuga ea facere. Qui voluptas recusandae quia. Et distinctio aliquid quasi blanditiis rerum eos et. Aut qui incidunt natus ipsum voluptatum.', '1995-04-26 12:10:08'),
(63147884, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows 98; Trident/3.1)', 'Eum necessitatibus quis dolor non. Deserunt nam soluta dolorem et et molestias corrupti sit. Id ut ipsam nulla maiores voluptate est est unde. Nulla ut sit ab impedit sunt quasi nulla.', '1996-05-11 13:19:21'),
(63430888, 'Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/533.7.7 (KHTML, like Gecko) Version/4.1 Safari/', 'Omnis consequatur dolor ipsum doloribus ut. Amet illo et nihil aspernatur quisquam eaque. Dolorum atque suscipit natus veniam eum labore rerum. Eligendi dolorem minima non nisi.', '2007-08-28 15:28:25'),
(63580252, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 6.2; Trident/4.0)', 'Accusantium unde eveniet totam sunt. Ipsum vel ut quam qui perspiciatis voluptates eos. Magnam tenetur necessitatibus sunt perferendis consequuntur esse sed. Est consequatur esse dolores nostrum in.', '1986-05-26 10:51:56'),
(63937526, 'Mozilla/5.0 (Windows NT 5.0) AppleWebKit/5361 (KHTML, like Gecko) Chrome/15.0.850.0 Safari/5361', 'Porro non ex unde. Impedit tempore animi enim adipisci.', '2011-07-28 01:58:10'),
(64935427, 'Mozilla/5.0 (Windows NT 6.0; sl-SI; rv:1.9.1.20) Gecko/20140120 Firefox/3.8', 'Dignissimos velit veniam in fuga. Hic voluptatum est vel.', '2008-05-14 18:08:28'),
(65420514, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_8_5 rv:5.0) Gecko/20110902 Firefox/3.6.15', 'Qui molestiae ipsam aut suscipit. Reiciendis facere facilis non illo. Velit consequatur quo harum et sequi. Sint eos ut non occaecati aperiam rerum doloribus in.', '1972-04-10 16:56:55'),
(66431623, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5362 (KHTML, like Gecko) Chrome/14.0.862.0 Safari/5362', 'Sint error repellendus pariatur aut et ullam ut. Reprehenderit et nihil iusto pariatur cum qui eveniet. Libero et quia qui sint inventore esse est.', '2003-04-07 14:49:15'),
(68199508, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_8_6) AppleWebKit/5310 (KHTML, like Gecko) Chrome/14.0.824', 'Itaque occaecati facere ut sint omnis totam. Reiciendis rerum repellendus sequi inventore labore. Ut non quis ut illo quis ex. Consequuntur ut cum ea vero.', '1976-08-25 09:22:29'),
(68610485, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_5 rv:5.0) Gecko/20200516 Firefox/3.8', 'Quae porro dolor maxime velit velit voluptatem et. Qui aliquid facere rerum labore non explicabo distinctio. Officia labore commodi et facilis amet omnis incidunt. Delectus velit aliquid deleniti voluptates minus.', '2007-08-12 14:38:12'),
(69541933, 'Mozilla/5.0 (Windows 98) AppleWebKit/5320 (KHTML, like Gecko) Chrome/14.0.825.0 Safari/5320', 'Vel asperiores optio eos aut architecto qui quo. Doloribus soluta quas nihil et perferendis molestias non. Perferendis quod laboriosam maxime possimus optio et. Quibusdam optio non nam provident nisi cum delectus sint.', '1994-02-20 00:10:32'),
(69810799, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_7 rv:2.0; en-US) AppleWebKit/534.41.4 (KHTML, like Gecko', 'Libero ut adipisci reiciendis tenetur ut. Et quae excepturi accusantium commodi non. Aut non illo libero et ad cumque unde est.', '1982-08-17 21:05:27'),
(70357706, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows 98; Win 9x 4.90; Trident/4.0)', 'Ut ipsa et facilis voluptatem repellat vitae. Laudantium eaque illum architecto. Qui ut animi tempore fugit sed aspernatur. Ea et deserunt rerum nihil nobis. Ut nisi aspernatur et blanditiis ipsa optio non.', '2014-06-07 14:15:05'),
(72381864, 'Opera/9.55 (X11; Linuxx86_64; en-US) Presto/2.9.178 Version/12.00', 'Voluptatem est alias vero ut suscipit. Ullam libero suscipit et fugit et recusandae. Voluptas qui voluptatem saepe. Excepturi molestiae aut porro placeat.', '1971-01-17 09:33:22'),
(73002600, 'Mozilla/5.0 (Windows; U; Windows NT 5.01) AppleWebKit/532.11.4 (KHTML, like Gecko) Version/4.0 Safar', 'Id ratione illum ipsa pariatur assumenda. Magnam ullam voluptas at eius placeat non cum. Saepe ut odit dolores saepe. Ratione neque a fugit eveniet vitae tempore deserunt.', '2009-05-04 06:49:17'),
(74206539, 'Opera/8.89 (Windows 95; en-US) Presto/2.9.173 Version/10.00', 'Tenetur dolorum sed libero porro doloribus sed. Non dignissimos vitae cumque dolore aliquid labore sed hic. Nesciunt vero corporis optio harum ut quidem vel.', '2018-09-13 22:18:28'),
(74482289, 'Mozilla/5.0 (Windows NT 5.0; en-US; rv:1.9.1.20) Gecko/20180919 Firefox/3.8', 'Est voluptatibus odio sequi et omnis aperiam consequatur. Iste quod eaque natus mollitia. Consequatur expedita expedita aut harum tempora. Eveniet beatae ut ullam voluptatem officiis odit quia id.', '1984-11-24 06:19:08'),
(77001403, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.1; Trident/3.1)', 'Eveniet et optio voluptas natus non. Qui consequuntur quia hic necessitatibus architecto. Dolores optio quibusdam ex quisquam dolore voluptate repudiandae. Nam tempora eligendi maxime deleniti.', '2020-11-23 03:18:50'),
(77338660, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.0; Trident/3.0)', 'Voluptatem debitis voluptates magnam distinctio aliquid cupiditate sint. Sequi labore hic quisquam officiis atque cum assumenda. Nobis laboriosam qui doloribus ipsum ducimus voluptas aliquam. Odit alias unde enim provident ullam. Id eos in et et veniam voluptatibus.', '1980-03-27 03:14:38'),
(78132352, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.01; Trident/4.1)', 'Voluptatem consectetur aspernatur officiis corporis molestias. Officiis nam quisquam labore repellendus. Id ut culpa reprehenderit commodi. Debitis praesentium ipsam et tenetur aperiam et dolorem.', '1984-02-15 20:30:04'),
(78294935, 'Mozilla/5.0 (Windows NT 6.2) AppleWebKit/5352 (KHTML, like Gecko) Chrome/14.0.825.0 Safari/5352', 'Consequuntur pariatur quia nobis dolor voluptatibus. Aut qui nihil quidem quia ipsam quidem. Voluptas consequatur beatae corporis debitis nihil.', '1974-11-17 11:17:48'),
(79000659, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_8_6 rv:4.0) Gecko/20230513 Firefox/3.8', 'Culpa voluptatem enim ut corporis hic dolore. Rerum aut sint ducimus. Ipsa animi et voluptas quae possimus. Et quae repellat voluptas est officia qui consectetur.', '1981-04-28 22:43:53'),
(79338339, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.2; Trident/3.1)', 'Ut dolorem suscipit aut at. Velit omnis doloribus praesentium hic. Qui ut non dolor eius earum.', '2014-02-18 16:28:38'),
(80323215, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_3) AppleWebKit/5312 (KHTML, like Gecko) Chrome/14.0.8', 'Consequatur dolore est rerum ut enim autem. Quidem dolorum magni vel dolorum ea dicta et cum. Aut quis tempora et laborum nisi quia. Et accusamus at repellat odio maiores est dolorum autem.', '2021-04-08 02:19:50'),
(80953295, 'Opera/8.33 (X11; Linuxx86_64; en-US) Presto/2.9.176 Version/11.00', 'Non quaerat deserunt sunt est optio nulla. Nemo distinctio inventore excepturi voluptatem. Eum est nam quibusdam soluta alias. Sint accusantium magnam expedita earum. Vitae laboriosam exercitationem recusandae sed alias laudantium.', '1995-01-19 19:30:08'),
(81358175, 'Opera/8.24 (Windows NT 5.0; en-US) Presto/2.9.178 Version/12.00', 'Et aperiam repudiandae quas explicabo. Veniam debitis et dicta a sit possimus. Perferendis mollitia nulla odit consectetur officia ut et. Ut molestiae ab tempora numquam et iure inventore dicta.', '2007-09-05 18:33:25'),
(82255636, 'Opera/9.49 (X11; Linuxx86_64; en-US) Presto/2.9.169 Version/10.00', 'Recusandae perspiciatis tempore laboriosam nesciunt pariatur quo consequuntur sed. Nesciunt eligendi vitae non hic consequatur adipisci voluptatum. Voluptatem enim soluta a enim aut.', '1983-09-10 10:48:55'),
(83353512, 'Mozilla/5.0 (Windows NT 5.0; sl-SI; rv:1.9.0.20) Gecko/20141112 Firefox/3.8', 'Aut earum non ducimus consequuntur repellendus fugiat voluptas. Beatae voluptas illo eligendi assumenda.', '2009-03-18 06:30:23'),
(83602629, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_7_4 rv:6.0; en-US) AppleWebKit/532.19.5 (KHTML, like Gecko) ', 'Unde ratione et repellat in nam quia. In exercitationem sint inventore impedit quia rerum qui.', '2024-10-31 02:24:05'),
(83799227, 'Mozilla/5.0 (Windows; U; Windows NT 6.0) AppleWebKit/533.19.2 (KHTML, like Gecko) Version/4.0.5 Safa', 'Quibusdam atque iusto harum alias corrupti vel facere. Quos odio labore dolorem repellat. Vitae aut dolores et sunt veritatis.', '2005-05-30 11:08:21'),
(84644575, 'Opera/9.53 (Windows 98; Win 9x 4.90; sl-SI) Presto/2.9.188 Version/11.00', 'Repellat dolorem ut aut est harum. Voluptas cupiditate sunt tenetur et illo delectus est laboriosam. Aperiam et in esse aut et sunt quam.', '1977-04-29 13:52:14'),
(84655827, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5361 (KHTML, like Gecko) Chrome/14.0.859.0 Safari/5361', 'Eveniet ut sed dolore aut. Impedit esse id consequuntur culpa est iste assumenda. Quisquam aut est aspernatur et.', '2022-06-13 04:09:13'),
(84866091, 'Opera/8.80 (Windows NT 5.0; sl-SI) Presto/2.9.170 Version/12.00', 'In quisquam ut officia iure reprehenderit eum ut. Consequuntur nulla expedita quia et est ut. Accusamus voluptatum nesciunt quidem. Architecto temporibus excepturi est fugit voluptatibus cum laudantium.', '2023-09-12 20:40:44'),
(85055950, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows 98; Trident/4.0)', 'Minus molestias quod quas nobis non non. Dolores ipsum non dolorum molestiae eligendi unde autem consequatur. Cumque nihil aperiam veniam architecto. Assumenda et et aut rerum omnis provident et. Adipisci dolor aspernatur aut necessitatibus aut.', '2000-01-10 13:06:21'),
(87352579, 'Opera/9.30 (X11; Linuxx86_64; sl-SI) Presto/2.9.180 Version/10.00', 'Maiores veniam quibusdam facilis nulla eos. Explicabo odit non et. Qui libero voluptate dicta dignissimos. Et eveniet est iste natus alias porro iusto.', '1974-05-26 00:12:50'),
(88411574, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows CE; Trident/5.1)', 'Et ut dicta neque non ab ipsum. Nihil sit omnis ut autem. Et porro expedita magnam rem. Neque a consequatur quaerat et quo voluptas. Cupiditate exercitationem ut labore quia minima architecto temporibus temporibus.', '1973-04-27 16:57:28'),
(88807578, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_7_1) AppleWebKit/5360 (KHTML, like Gecko) Chrome/14.0.891', 'Laborum pariatur eaque in. Eum delectus sint autem. Veniam eligendi debitis magnam aliquam hic quae esse eum. Saepe labore unde et delectus qui quia est.', '2024-07-12 07:32:05'),
(90783849, 'Opera/9.63 (Windows NT 6.2; en-US) Presto/2.9.180 Version/12.00', 'Hic expedita quos architecto voluptatem enim. Sapiente natus et corporis quia. Doloremque quisquam eligendi maiores sit illo facilis animi. Aut similique doloribus reiciendis culpa neque temporibus.', '2015-02-11 23:53:41'),
(90981838, 'Opera/9.34 (Windows 98; Win 9x 4.90; sl-SI) Presto/2.9.170 Version/11.00', 'Consequuntur repellat mollitia culpa in et quidem. Cupiditate dolorem in illum aut perspiciatis. Excepturi et placeat rerum itaque debitis. Nisi fugit aut quae quasi.', '1971-05-25 07:49:31'),
(91473744, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5322 (KHTML, like Gecko) Chrome/14.0.855.0 Safari/5322', 'Eos commodi debitis autem quia labore. Eum a porro vel molestiae deleniti architecto. Et cupiditate ratione nemo molestiae non sint voluptas.', '2018-07-22 09:20:39'),
(92005577, 'Mozilla/5.0 (Windows CE; sl-SI; rv:1.9.0.20) Gecko/20130731 Firefox/3.6.11', 'Porro voluptatum harum dolores inventore quis laboriosam molestiae. Sint optio unde enim voluptas ut.', '2005-01-24 06:14:57'),
(92552118, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_8_9 rv:3.0) Gecko/20121109 Firefox/3.8', 'Harum aperiam animi voluptates deleniti aut veniam at. Aut vero dolore debitis omnis vel. Enim qui voluptatem aut sit. Est cumque hic nostrum quibusdam ut consequatur.', '1977-04-09 20:24:12'),
(92721873, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_1 rv:2.0) Gecko/20230421 Firefox/3.8', 'Consequuntur excepturi consequatur nisi unde. In voluptas est quaerat quasi quos consequatur veritatis. Voluptatum eius ut repudiandae aut vel omnis consequuntur.', '2016-02-06 09:14:12'),
(94902618, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.2; Trident/3.1)', 'Temporibus pariatur beatae porro. Amet velit ab commodi. Non debitis animi perferendis quo voluptate quam corrupti pariatur. Maiores omnis aut dolorem sed ut sunt tempore. Et nostrum quaerat quo quisquam vel et.', '2021-01-01 14:30:15'),
(96013251, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_5 rv:4.0; en-US) AppleWebKit/531.12.6 (KHTML, like Ge', 'Rem velit est atque magnam placeat expedita et distinctio. Maiores odit tempora quam voluptatibus cupiditate. Ut laboriosam dicta doloremque ad quia qui. Ullam eaque hic iure sed cumque aut fuga.', '1975-04-26 08:03:11'),
(97196696, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows 95; Trident/5.1)', 'Unde veniam non itaque ipsum. Quia sit quisquam et. Labore voluptatem dolor dicta. Est autem natus cupiditate.', '1998-10-20 14:48:42'),
(98089229, 'Mozilla/5.0 (Windows 98; sl-SI; rv:1.9.1.20) Gecko/20230918 Firefox/3.6.2', 'Alias maxime eius qui dicta et et qui. Et omnis assumenda ipsum molestiae. Recusandae voluptatem quod et veniam nam.', '2011-04-15 23:42:09'),
(98131432, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_8_8 rv:5.0) Gecko/20140104 Firefox/3.8', 'Et quas architecto et esse perspiciatis necessitatibus voluptas. Quisquam tempora neque dolorem dolores qui. Nihil deserunt sapiente aut quae rerum. Voluptas iusto non placeat est beatae non.', '2023-03-08 09:59:01'),
(98552171, 'Opera/9.18 (X11; Linuxx86_64; en-US) Presto/2.9.186 Version/11.00', 'Sint sequi earum sapiente quo aut excepturi nemo. Laboriosam excepturi est provident excepturi quo rerum. Ex voluptatem in rerum delectus accusamus neque adipisci.', '1974-09-17 13:20:58'),
(98673218, 'Mozilla/5.0 (X11; Linuxx86_64; rv:6.0) Gecko/20250228 Firefox/3.6.9', 'Qui praesentium cum iure exercitationem fugit atque illum. Temporibus aut eos quia iste. Quibusdam qui quod quis vitae.', '2004-02-12 06:33:23'),
(99530239, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_8_8) AppleWebKit/5342 (KHTML, like Gecko) Chrome/15.0.899.0 ', 'Provident fuga labore aut vel alias odio. Deserunt atque et sit molestiae recusandae aliquid molestiae.', '1973-04-26 15:56:13'),
(99586123, 'Mozilla/5.0 (Windows NT 5.01) AppleWebKit/5342 (KHTML, like Gecko) Chrome/14.0.895.0 Safari/5342', 'Eos odit et dolorem architecto. Explicabo placeat quaerat eos ut non nam. Voluptatem voluptas est optio ut.', '1976-01-21 13:49:54'),
(99589441, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_3 rv:4.0) Gecko/20210705 Firefox/3.6.10', 'Quo esse dolorum quos est et. Ut voluptas ea libero culpa. Omnis neque commodi ea voluptatum nisi et est consequatur. Nihil dolores quaerat aut inventore. Earum eius deserunt fuga et deleniti deserunt.', '1980-09-16 16:00:35'),
(101436422, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 6.2; Trident/3.1)', 'Sunt earum beatae quis sit enim commodi sint. Rerum est molestiae eos facere et sunt. Similique voluptatum cumque eos sunt expedita quam odio optio.', '2015-04-22 06:09:39'),
(117781616, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_1 rv:4.0) Gecko/20161208 Firefox/3.6.17', 'Fuga exercitationem nisi quam ad excepturi et ut voluptatum. Occaecati nesciunt porro alias aut in. Est blanditiis et veniam fuga culpa id. Voluptas a expedita consequatur ex omnis. Quia autem nisi aliquam cum quaerat vero.', '2023-04-12 16:13:22'),
(121778766, 'Mozilla/5.0 (Windows NT 6.0; en-US; rv:1.9.1.20) Gecko/20121028 Firefox/3.8', 'Optio tempore cum voluptates commodi excepturi assumenda molestiae architecto. Ratione at ab et est est. Assumenda repellendus nulla officia architecto rerum.', '2013-03-27 20:39:07'),
(122406944, 'Opera/9.99 (Windows NT 4.0; sl-SI) Presto/2.9.190 Version/11.00', 'Sed est deleniti est corrupti dolorem. Nihil doloribus ipsam excepturi eos ut omnis perferendis. Accusamus cupiditate numquam deleniti consequatur nulla.', '1972-11-10 04:49:07'),
(127143195, 'Mozilla/5.0 (Windows NT 5.1; sl-SI; rv:1.9.2.20) Gecko/20200930 Firefox/3.6.10', 'Totam non quis et quidem earum. Cupiditate vitae delectus voluptatem sunt temporibus hic. Et qui aut ut odit expedita qui qui dignissimos. Dignissimos perspiciatis nihil vel commodi eligendi.', '2003-01-06 03:07:21'),
(138786739, 'Opera/8.86 (Windows NT 5.0; sl-SI) Presto/2.9.180 Version/11.00', 'Molestias et qui sint omnis. Atque ratione doloribus voluptas ratione sit qui tenetur. Et nostrum et harum corrupti odit maxime. Aspernatur et aliquam provident nulla ut.', '1971-04-07 15:56:15'),
(149304540, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_1 like Mac OS X; sl-SI) AppleWebKit/534.7.6 (KHTML, like Gecko', 'Deserunt aut adipisci consequuntur fugit. Sed neque fugit ipsam enim. Molestias velit dicta pariatur. Quia est consequatur dignissimos nesciunt repellat.', '2015-05-29 21:07:32'),
(152071530, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.0; Trident/5.1)', 'Voluptatibus magni dolores culpa est repellendus et repudiandae aspernatur. Harum corporis sunt animi. Enim dolorem vero voluptatibus. Similique sit quam adipisci.', '1988-12-10 09:31:57'),
(152550417, 'Mozilla/5.0 (X11; Linuxx86_64; rv:7.0) Gecko/20180111 Firefox/3.8', 'Voluptate aut quia dolores distinctio id sapiente. Amet corrupti fugit quibusdam facilis ut odit. Inventore illo recusandae eos autem. Assumenda voluptas fuga doloribus expedita rerum corrupti.', '1999-09-23 16:14:20'),
(158785975, 'Opera/8.42 (X11; Linuxi686; sl-SI) Presto/2.9.169 Version/12.00', 'Doloremque at quam delectus sit praesentium eveniet et. Ut facilis corporis vitae et saepe. Sed doloribus commodi est voluptas. Nesciunt asperiores consequatur sint dicta minima est.', '1994-05-20 17:26:11'),
(160577025, 'Mozilla/5.0 (Windows NT 4.0) AppleWebKit/5351 (KHTML, like Gecko) Chrome/13.0.826.0 Safari/5351', 'Voluptas sit repellendus voluptas. Ipsam corporis atque vero at optio adipisci unde. Ratione nesciunt quia commodi laborum eos tenetur ipsa. Qui sapiente veritatis sit aut. Officia id fuga voluptatem ea.', '1992-07-12 19:38:35'),
(165477603, 'Mozilla/5.0 (Windows NT 6.1; en-US; rv:1.9.1.20) Gecko/20240830 Firefox/10.0', 'Rerum quas non eaque dolorem molestias. Quaerat nam at animi. Aspernatur aliquid natus eos doloremque similique.', '2016-05-18 18:10:32'),
(174349305, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 6.2; Trident/5.1)', 'Aut dicta architecto voluptas. Molestiae accusamus laudantium aspernatur vel. Reiciendis numquam quos ut aut.', '2009-12-24 05:27:33'),
(176418030, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_6_4) AppleWebKit/5330 (KHTML, like Gecko) Chrome/13.0.863', 'Doloribus a consectetur nisi molestiae. Velit aspernatur dolorum quae dolore voluptatem. Vel id facere inventore odio rerum.', '2015-06-01 01:15:53'),
(179288044, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_8_7 rv:2.0; en-US) AppleWebKit/533.47.1 (KHTML, like Geck', 'Fuga sunt cupiditate eos veritatis porro harum. Aliquid iusto consequatur consectetur dolore. Non totam odit et beatae sit quidem nemo.', '1979-09-18 11:17:19'),
(179782082, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.0; Trident/3.0)', 'Voluptas tenetur et repellendus nam dolorem quis. Aut sit ut reprehenderit dolorem dicta earum optio perspiciatis. Aut atque quae quaerat molestiae recusandae.', '2008-11-13 02:20:32'),
(181733193, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5352 (KHTML, like Gecko) Chrome/13.0.854.0 Safari/5352', 'Quae blanditiis voluptatem nisi dignissimos necessitatibus. Tempore officiis facere quia non. Voluptatibus corrupti praesentium sed facere qui delectus earum.', '2006-04-30 06:06:48'),
(207346634, 'Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/535.21.7 (KHTML, like Gecko) Version/5.0.1 Safa', 'Sapiente est non neque repellat est alias. Quaerat architecto iure consequuntur ab ut. Nulla libero ratione molestias. Deleniti qui et in iure eaque et.', '2016-08-23 00:35:00'),
(216058396, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 4.0; Trident/4.0)', 'Veritatis atque sed sequi. Aperiam molestiae et iusto excepturi. Aut quia impedit magnam voluptatibus qui. Cumque amet perspiciatis aut quo quo porro.', '1998-10-08 04:51:08'),
(217189432, 'Mozilla/5.0 (X11; Linuxx86_64; rv:7.0) Gecko/20240807 Firefox/15.0', 'Distinctio assumenda in ad nisi accusantium enim soluta. Unde porro voluptatem neque reiciendis est dolores. Nesciunt in in et ex et. Sunt quibusdam dolorem atque tempora minima. Accusamus qui saepe voluptatem aut corporis ullam assumenda labore.', '1982-07-04 04:04:55'),
(223072294, 'Mozilla/5.0 (Windows NT 6.2; en-US; rv:1.9.0.20) Gecko/20130404 Firefox/9.0', 'Est et exercitationem velit quam nihil. Sit quo labore rerum. Delectus dicta commodi facilis aut.', '1971-12-18 02:49:23'),
(228882737, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_1) AppleWebKit/5360 (KHTML, like Gecko) Chrome/15.0.829.', 'Temporibus sint at occaecati qui adipisci accusantium itaque. Velit quia atque illo voluptatem. Iusto esse ipsa aliquam in cum quia.', '2024-05-21 00:05:18'),
(230457674, 'Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/532.45.4 (KHTML, like Gecko) Version/5.0.4 Safa', 'Commodi similique aut modi eos. Quod recusandae aliquam itaque quia quia qui sed. Error minima consequatur sunt amet. Qui unde eos rerum eum.', '1970-06-05 07:27:40'),
(231317166, 'Opera/9.30 (Windows NT 6.1; en-US) Presto/2.9.167 Version/11.00', 'Quo ducimus repudiandae saepe. Fugit dolorum voluptatem nobis perferendis. Voluptatem ullam nesciunt eum perspiciatis. Natus harum quam qui numquam sapiente nihil.', '1970-11-21 08:16:39'),
(241390102, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5340 (KHTML, like Gecko) Chrome/15.0.823.0 Safari/5340', 'Autem fuga inventore esse libero necessitatibus. Dolores voluptatem doloremque laborum ea. Itaque labore enim voluptate et debitis ut animi fugiat.', '1990-09-26 22:17:17'),
(241465462, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_7_6 rv:2.0; en-US) AppleWebKit/532.1.3 (KHTML, like Gecko) V', 'Earum harum aut quasi autem praesentium. Maiores aperiam dolorem voluptas eos et. Porro cumque vero cumque modi repellendus ut. Voluptas hic aut sed magnam non ex sunt.', '2023-07-28 22:33:19'),
(257401199, 'Opera/9.59 (X11; Linuxi686; en-US) Presto/2.9.172 Version/11.00', 'Et id totam neque voluptates. Molestias voluptas molestiae voluptates consequuntur voluptas illum vel. Eos quia cupiditate velit illum sit tempora.', '1995-10-03 23:10:15'),
(264395856, 'Mozilla/5.0 (Windows NT 5.2) AppleWebKit/5360 (KHTML, like Gecko) Chrome/13.0.896.0 Safari/5360', 'Et molestiae dolores alias quis. Reiciendis iure dolorem sapiente alias reprehenderit accusantium. Vitae quasi at magni ut eum et voluptatem possimus.', '1981-08-23 14:19:09'),
(298153041, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_5) AppleWebKit/5352 (KHTML, like Gecko) Chrome/13.0.8', 'Est quas fugiat ex qui in aut fugiat. Minus aut et voluptas reprehenderit non. Consequatur sunt est et dignissimos eius harum autem dolore.', '1971-10-30 23:42:41'),
(299505591, 'Opera/8.39 (X11; Linuxi686; en-US) Presto/2.9.184 Version/11.00', 'Explicabo ducimus culpa quis ab similique. Nihil nostrum ut asperiores vero hic nesciunt sapiente suscipit. Excepturi vel illo laudantium.', '2018-07-11 17:37:44'),
(312028426, 'Mozilla/5.0 (Windows NT 5.1; en-US; rv:1.9.0.20) Gecko/20171104 Firefox/3.6.14', 'Rerum sint voluptates suscipit asperiores cum. Voluptatem corrupti sint consequatur blanditiis. Perspiciatis reiciendis quis unde magnam rem maxime veritatis et.', '1981-12-17 17:47:43'),
(315907135, 'Opera/8.89 (X11; Linuxi686; sl-SI) Presto/2.9.180 Version/10.00', 'Et ducimus similique eveniet ab qui eaque. Et quod sit voluptate reiciendis. Et illo amet alias temporibus quo molestiae tempora.', '1973-10-20 17:51:02'),
(322148187, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 5.0; Trident/5.0)', 'Qui repudiandae id magni et deleniti. Iure labore laudantium magnam eum odit aliquid ea. Labore officiis sed consectetur reiciendis. Aliquam veniam exercitationem id.', '2001-11-12 02:21:34'),
(324336423, 'Mozilla/5.0 (X11; Linuxi686) AppleWebKit/5320 (KHTML, like Gecko) Chrome/14.0.883.0 Safari/5320', 'Quis voluptatem quo quaerat dolore rerum natus ducimus. Facilis eos eius voluptas voluptatum delectus quasi similique. Optio aperiam dolorem magnam eveniet officia reiciendis. Similique rem quia eos sunt sit sed.', '1972-09-08 10:22:28'),
(334659448, 'Opera/8.80 (X11; Linuxx86_64; sl-SI) Presto/2.9.190 Version/12.00', 'Incidunt sequi pariatur eius doloremque vel et. Ut tempora ut modi provident sed ut.', '2022-02-14 11:03:34'),
(337614705, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_5_8) AppleWebKit/5350 (KHTML, like Gecko) Chrome/13.0.845.0 ', 'Et asperiores consequatur sed illo voluptates suscipit. Voluptas ex laboriosam doloribus error et odit omnis. Vero quas voluptatem reiciendis veniam.', '1980-04-12 06:22:00'),
(339617559, 'Opera/8.57 (X11; Linuxx86_64; sl-SI) Presto/2.9.164 Version/11.00', 'Voluptatem aperiam id quis placeat molestiae laboriosam. At molestiae eveniet adipisci earum. Molestiae et sed reprehenderit.', '1989-06-02 20:45:01'),
(347209169, 'Mozilla/5.0 (X11; Linuxi686; rv:5.0) Gecko/20150302 Firefox/3.8', 'Commodi odit molestias in ea nesciunt. Quam et enim omnis quisquam delectus. Nemo cum optio tenetur dolores aut dolores harum. Sit veritatis qui omnis est.', '1970-01-27 17:27:41'),
(365879778, 'Opera/9.76 (Windows 98; Win 9x 4.90; en-US) Presto/2.9.176 Version/10.00', 'Excepturi dolores nihil deleniti voluptatum. Et corrupti aliquid officiis ex. Ut eum nihil dolorem earum recusandae occaecati eius rerum.', '1994-12-08 03:00:57'),
(380923291, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.2; Trident/3.1)', 'Mollitia nobis omnis saepe ullam. Error aspernatur ut quia minima unde. Quia sint temporibus suscipit.', '2022-08-05 09:26:15'),
(391266459, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows 98; Trident/5.1)', 'Atque sint vel dolorum. Omnis amet voluptatem quibusdam quis voluptatem culpa. Quisquam nihil optio molestias veniam incidunt. Consectetur aut inventore quasi iste ea consequuntur.', '1977-05-25 23:09:39'),
(404849277, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_1) AppleWebKit/5312 (KHTML, like Gecko) Chrome/14.0.839.', 'Facilis autem est debitis modi ipsum harum laboriosam. Quibusdam aliquid voluptatem amet reprehenderit impedit inventore. Quam magni iste neque consequatur et. Consequatur sint in et ex quae dicta ut.', '2010-02-19 02:02:37'),
(412792860, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_3 like Mac OS X; sl-SI) AppleWebKit/533.33.1 (KHTML, like Geck', 'Quibusdam voluptatem perspiciatis voluptatem. Blanditiis maxime qui earum accusamus quo ex. Et et laborum dolores delectus. Dicta blanditiis omnis autem veritatis.', '1989-09-22 07:20:18'),
(423125182, 'Opera/8.91 (Windows 98; Win 9x 4.90; sl-SI) Presto/2.9.189 Version/12.00', 'Cupiditate quidem et et. Exercitationem rerum quia eum aut. Architecto labore eum nihil sed quae. Minus inventore nesciunt numquam molestiae iste dolores.', '2019-10-15 12:39:55'),
(430888334, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows 98; Trident/4.1)', 'Id nam rerum voluptate et nostrum. Earum et et fuga dolorem quia eligendi unde. Pariatur nobis sed autem. Sed iste in sequi omnis cum et consequatur.', '1995-12-23 16:08:07'),
(431849636, 'Mozilla/5.0 (X11; Linuxx86_64; rv:7.0) Gecko/20170912 Firefox/12.0', 'Nam quia aut nesciunt temporibus quia. Aliquam accusantium non voluptas quo laboriosam asperiores rem. Quas sunt cum nam. Dolores aut corrupti voluptatem dolores eius quia.', '1988-09-09 02:56:41'),
(435774876, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.01; Trident/3.1)', 'Rerum nulla quo fuga. Sed deleniti illo commodi praesentium hic veritatis. A doloremque voluptatibus doloribus ut veniam qui sunt. Voluptas rem facilis assumenda ut nulla eveniet molestiae veniam.', '1998-06-05 15:23:55'),
(443332171, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.1; Trident/4.1)', 'Sequi officia qui voluptatibus ut. Consequatur et omnis tempore aspernatur exercitationem dolores nisi. Modi nihil iusto architecto nobis. Tempora pariatur molestiae eveniet.', '2008-11-01 16:03:17'),
(443765922, 'Mozilla/5.0 (X11; Linuxx86_64; rv:7.0) Gecko/20130701 Firefox/14.0', 'Nostrum distinctio maiores ipsa tenetur voluptate dolorem. Culpa aperiam dolorem tenetur labore nihil perferendis dolorem.', '2021-11-11 00:58:45'),
(452520060, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.1; Trident/4.1)', 'Corrupti aspernatur occaecati omnis recusandae. Earum soluta sint enim nam asperiores magni quam nihil. Expedita qui earum impedit ab nostrum delectus et qui.', '2011-12-03 09:56:24'),
(454009544, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_0 like Mac OS X; sl-SI) AppleWebKit/533.2.4 (KHTML, like Gecko', 'Aut sit vero molestiae. Quos quos quis nostrum quos.', '2022-10-01 01:08:20'),
(456729062, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_5_8 rv:5.0) Gecko/20241107 Firefox/3.6.20', 'Et enim nam ducimus. Inventore assumenda consequatur qui eligendi.', '1980-06-11 06:47:20'),
(461714423, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.0; Trident/5.0)', 'Vel voluptatem voluptatibus quo ut cumque voluptate dicta. Hic ut recusandae eius tempora. Atque odio expedita provident aut.', '1982-04-16 21:11:41'),
(462521909, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_5_6) AppleWebKit/5330 (KHTML, like Gecko) Chrome/13.0.886.0 ', 'Aut ea rerum reiciendis rerum commodi corrupti commodi quia. Voluptatem autem veniam qui quisquam ut. Ut in recusandae distinctio.', '2017-01-20 05:53:26'),
(464109742, 'Opera/8.45 (X11; Linuxx86_64; en-US) Presto/2.9.160 Version/12.00', 'Ea iste vero sed voluptatem tempora non sit. Dolor ab dignissimos perspiciatis qui totam dolore libero. Minus cum quos distinctio est reiciendis.', '2021-12-06 04:13:38'),
(466733085, 'Opera/8.83 (Windows NT 5.2; en-US) Presto/2.9.176 Version/11.00', 'Ut magnam consequatur beatae totam quo vel. Ab eius tenetur voluptatem numquam repudiandae. Nobis a cumque dolores omnis aliquid commodi ipsum ea.', '2004-08-30 05:03:35');
INSERT INTO `categories` (`id`, `name`, `description`, `created_at`) VALUES
(474820832, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows 95; Trident/3.0)', 'Quod ab quo eos ea non aliquid numquam dolorum. Voluptatem laborum voluptatem ut.', '1971-11-24 07:07:56'),
(491143532, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows CE; Trident/3.1)', 'Minima dicta vel facere similique ut quo enim qui. Et possimus beatae porro. Suscipit quo nesciunt id doloribus quas doloribus qui.', '1982-07-28 11:20:30'),
(520108001, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_6_2 rv:4.0; sl-SI) AppleWebKit/533.36.4 (KHTML, like Gecko) ', 'Itaque iste iste commodi id qui exercitationem recusandae qui. Consequuntur velit recusandae quas aut. Aliquid at rerum nemo cum.', '2010-10-28 09:54:35'),
(524304716, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.2; Trident/5.1)', 'Aliquid rerum qui officiis deserunt delectus nisi. Neque aliquid necessitatibus blanditiis nam nisi. Sed voluptatem neque quod.', '2021-04-16 04:22:14'),
(531518770, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows 95; Trident/5.1)', 'Ducimus ipsum quo quis. Odio praesentium ut magnam sit et aut eum facilis. Dolor voluptas consequatur veritatis excepturi magnam quas delectus sequi. Est delectus voluptate a tempora.', '1993-11-19 13:42:17'),
(538341619, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_7 rv:5.0; en-US) AppleWebKit/531.3.6 (KHTML, like Gec', 'Minima voluptate vel unde voluptatibus quo consectetur officia eligendi. Vel occaecati molestias nihil. Aut nesciunt ea laborum. Qui non facilis nemo.', '1977-10-27 01:36:27'),
(547332000, 'Opera/8.27 (Windows 98; en-US) Presto/2.9.164 Version/12.00', 'Voluptas in excepturi repellendus enim a qui. Nihil ut molestiae porro aut incidunt facilis explicabo. Praesentium atque dolorem eligendi aut suscipit. Labore occaecati sunt molestias consequatur eius nam nemo.', '2022-09-29 02:03:25'),
(551358793, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_1 like Mac OS X; en-US) AppleWebKit/532.43.5 (KHTML, like Geck', 'Autem sint et et sit. Qui accusantium et et rerum. Tempora repellat voluptatem tenetur et architecto dolores nemo. Itaque nesciunt sunt perspiciatis modi corporis nemo ut possimus.', '2014-04-26 13:27:30'),
(553900055, 'Opera/9.29 (Windows 98; sl-SI) Presto/2.9.163 Version/12.00', 'Accusantium et temporibus rerum laudantium eius. Voluptatibus dolore saepe vitae beatae sit dolore. Est molestiae optio nihil sit aut.', '1987-11-19 16:53:32'),
(554027100, 'Mozilla/5.0 (Windows; U; Windows NT 5.01) AppleWebKit/531.48.7 (KHTML, like Gecko) Version/4.0 Safar', 'Qui tempore error sapiente velit quo. Labore nihil eius autem perspiciatis ipsum dolorem sapiente saepe.', '1979-11-07 18:06:42'),
(566697669, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.01; Trident/4.0)', 'Optio quod perspiciatis voluptatem repellendus distinctio eum. Labore et et nostrum aperiam inventore. Non rerum quo qui maxime in itaque.', '1970-05-29 06:46:31'),
(575134727, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.2; Trident/4.0)', 'Aut qui ut quia in. Qui est animi dicta explicabo voluptatum adipisci id occaecati. Quibusdam enim praesentium eaque cumque ut.', '2014-12-17 11:28:10'),
(593528591, 'Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/532.34.6 (KHTML, like Gecko) Version/4.1 Safari', 'Quae voluptas eum sed deleniti. Et quasi qui consequatur consequuntur non. Quia non consequuntur ut ea inventore tempora.', '2011-10-09 16:27:51'),
(598768937, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 6.2; Trident/5.0)', 'Ut ipsam error qui libero vitae. Consequatur iste voluptas vitae aspernatur voluptatem. Aut quis ex dicta voluptate sit aut sapiente sed.', '2013-02-08 10:53:22'),
(600750342, 'Opera/8.65 (X11; Linuxx86_64; en-US) Presto/2.9.179 Version/10.00', 'Sequi alias illo voluptatibus sequi. Et libero inventore aut quam. Commodi ipsam quidem consequatur ab qui repudiandae doloremque omnis. Dignissimos et sequi fugiat recusandae molestiae. Sit odit corporis ex vero quibusdam eaque.', '2017-01-23 04:35:31'),
(602444389, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows 95; Trident/5.0)', 'Natus commodi impedit expedita incidunt ut earum officiis in. Atque est ad quisquam nulla ut commodi perspiciatis. Eligendi sequi incidunt consectetur distinctio nihil. Sint qui id accusantium id ab ipsam et. Vel qui omnis exercitationem qui illo.', '2002-10-22 02:22:49'),
(603187497, 'Opera/8.26 (X11; Linuxi686; en-US) Presto/2.9.185 Version/12.00', 'Et ea aut vel quia ex ut. Sapiente sunt quibusdam alias ipsa. Officia velit fugiat ut voluptatem sequi dignissimos.', '1995-01-08 04:06:11'),
(610443306, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows 98; Trident/5.1)', 'Occaecati ut necessitatibus eos et quod laudantium. Dolorem suscipit qui voluptatem nobis quam. Cumque aut possimus quos et nulla quia. Harum suscipit reprehenderit quasi iusto et ad eos.', '2020-11-30 00:00:30'),
(612671833, 'Mozilla/5.0 (Windows; U; Windows NT 5.1) AppleWebKit/535.39.3 (KHTML, like Gecko) Version/5.0.5 Safa', 'Hic rerum distinctio sit dolore. Voluptatem nisi non est omnis velit aut rerum. Rerum aliquid aut qui ipsa voluptate et.', '1991-06-25 09:50:33'),
(615101670, 'Mozilla/5.0 (Windows; U; Windows NT 5.01) AppleWebKit/535.6.4 (KHTML, like Gecko) Version/4.1 Safari', 'Illo non dolor molestiae sequi in tempora. Incidunt nulla aut voluptates quia. Et quo eos nostrum enim. Consequuntur ea doloremque fugit.', '1997-07-26 03:31:32'),
(624620433, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.01; Trident/3.0)', 'Sit ut optio vitae numquam. Assumenda et quibusdam architecto. Quisquam sed odit ut nulla qui sunt.', '1993-10-15 19:45:55'),
(629767251, 'Mozilla/5.0 (X11; Linuxx86_64) AppleWebKit/5341 (KHTML, like Gecko) Chrome/14.0.851.0 Safari/5341', 'Culpa sunt non ullam adipisci. Quia ab nisi repellat nobis magnam porro.', '1975-03-11 14:07:02'),
(636867484, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows 98; Win 9x 4.90; Trident/4.0)', 'Ipsam sed quos quis eum. Aliquam aut explicabo illum consectetur sit. Corrupti cupiditate minima quae beatae autem.', '2004-04-21 12:42:29'),
(642541786, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_5 rv:5.0; sl-SI) AppleWebKit/534.24.6 (KHTML, like Ge', 'Vel qui hic optio qui qui nemo. Aut quia beatae soluta corporis sit omnis. Dolorem ea et dignissimos veniam quam amet adipisci temporibus. Sed ad rem quisquam veritatis quo.', '2003-07-13 13:25:56'),
(658625657, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_5 rv:2.0) Gecko/20150706 Firefox/3.8', 'Debitis voluptas magni nisi hic mollitia maxime commodi. Nostrum omnis dolore soluta doloribus. Quia id error dolores. Nostrum quisquam hic cum necessitatibus maxime corrupti inventore.', '1981-05-17 17:51:32'),
(676184084, 'Opera/9.39 (Windows NT 5.0; sl-SI) Presto/2.9.185 Version/11.00', 'Porro vel dicta vel similique est nemo consequatur optio. Illum debitis sit voluptatem quia qui. Inventore autem accusamus quidem fugiat.', '2022-04-17 21:06:52'),
(682465436, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 6.0; Trident/4.1)', 'Culpa omnis rerum ad blanditiis nostrum molestiae fugit. Voluptatem voluptatem explicabo qui omnis nemo nobis. Omnis quia in vel.', '2023-03-17 17:42:31'),
(683399077, 'Mozilla/5.0 (X11; Linuxi686; rv:7.0) Gecko/20111008 Firefox/6.0', 'Earum optio culpa voluptatibus molestiae temporibus enim accusantium. Dolorem aut doloribus ut minus quam architecto quia eum. Inventore impedit est quae quam porro autem quas. Et rerum quod impedit consequuntur non sed nobis.', '2021-10-26 19:25:13'),
(687207525, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows 98; Win 9x 4.90; Trident/5.1)', 'Laborum laboriosam assumenda vitae vel aut sit. Voluptatem dignissimos velit nemo adipisci illum. In dignissimos quibusdam magni autem cupiditate suscipit.', '2018-03-02 19:45:00'),
(693106654, 'Mozilla/5.0 (Windows 95; en-US; rv:1.9.0.20) Gecko/20160207 Firefox/3.8', 'Atque accusantium nisi rem debitis quia similique tempora. In voluptate exercitationem qui suscipit. At tenetur eos dolorem repellendus laborum. Similique ea consectetur aut enim vero qui quam at.', '1991-09-30 22:37:30'),
(696030732, 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/5321 (KHTML, like Gecko) Chrome/15.0.879.0 Safari/5321', 'Dolore odit assumenda cupiditate et aliquam aut ut. Laborum voluptas exercitationem illum magni sapiente atque illo. Qui porro ipsum distinctio harum quas suscipit. Eos porro nemo sit rerum non non.', '1975-03-05 06:06:44'),
(704222693, 'Opera/8.94 (X11; Linuxx86_64; sl-SI) Presto/2.9.184 Version/12.00', 'Et ratione et natus aperiam. Beatae id non quos dolores fugit sed. Praesentium et beatae blanditiis voluptate dolores laudantium consequatur alias. Velit aut mollitia culpa cum.', '1984-12-13 15:08:01'),
(714613807, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_7 rv:6.0) Gecko/20130419 Firefox/4.0', 'Minus et sed magni. Modi est sunt quis rerum. Et rerum enim quam qui.', '2008-06-29 02:38:52'),
(719503914, 'Mozilla/5.0 (Windows CE) AppleWebKit/5330 (KHTML, like Gecko) Chrome/15.0.846.0 Safari/5330', 'Repellat nihil perspiciatis quis a est assumenda. Quasi quis magni libero quisquam similique.', '1977-11-27 04:00:57'),
(736340153, 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_8_6) AppleWebKit/5352 (KHTML, like Gecko) Chrome/15.0.875', 'Distinctio aliquid et sunt dolore voluptatem voluptatem. Natus tenetur alias corrupti. Et consequuntur quaerat voluptate qui architecto voluptatem ut est. Fugit non ea facilis atque.', '1975-09-18 15:00:50'),
(739372334, 'Opera/8.59 (Windows NT 5.01; sl-SI) Presto/2.9.181 Version/10.00', 'Ab deserunt quaerat vel soluta qui hic. In labore dolorem suscipit et ducimus natus maxime eum. Corporis cupiditate officiis sint qui nesciunt. Qui et necessitatibus eaque cumque sequi ea.', '1971-07-08 03:46:16'),
(742758949, 'Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 5.0; Trident/4.1)', 'Ipsa veniam voluptatem optio repudiandae aliquid ea sit. Expedita vitae rerum in dolorum voluptatem suscipit. Voluptates perferendis et ipsam. Ea temporibus neque veniam fugit quasi.', '2011-11-12 11:30:22'),
(761734151, 'Opera/9.84 (Windows NT 4.0; en-US) Presto/2.9.180 Version/11.00', 'Consectetur molestiae officia odit quis harum quisquam. Et quis cumque aspernatur est non ut aliquam. Modi nihil minus itaque sit iure voluptatem ea.', '2005-02-05 10:55:05'),
(764125731, 'Mozilla/5.0 (Windows; U; Windows 98) AppleWebKit/534.28.3 (KHTML, like Gecko) Version/5.0 Safari/534', 'Quo possimus molestias id sed. Nostrum qui quia aliquam adipisci voluptatem a molestiae.', '1971-10-28 15:27:42'),
(792414175, 'Mozilla/5.0 (Windows NT 6.2) AppleWebKit/5330 (KHTML, like Gecko) Chrome/13.0.879.0 Safari/5330', 'Vel et eos ipsam. Ut molestias dolores nemo. Sit aperiam eum et quia optio. Suscipit nulla debitis qui sed assumenda totam. Rerum tempore odio et quas optio molestias minima.', '1982-01-02 22:00:09'),
(797254136, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/5.0)', 'Fuga voluptatem deleniti quam quo rerum. Quia consequuntur placeat quo id quia ut minus qui. Provident repellat molestiae aut accusantium.', '1973-03-17 16:14:47'),
(825392043, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.2; Trident/3.1)', 'Velit natus corporis dolores labore ipsam autem. Sed voluptatem dolor qui dolorem repellendus vel. Ratione dolorum praesentium qui eligendi in. Eum et sed consectetur praesentium omnis.', '1982-01-27 02:49:00'),
(840815721, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows CE; Trident/5.1)', 'Vel cumque ullam dolore sunt. Nulla occaecati numquam hic perspiciatis ratione. Velit et quibusdam placeat odit nesciunt temporibus id repudiandae.', '1970-03-13 02:03:33'),
(843032071, 'Opera/9.34 (Windows NT 5.01; en-US) Presto/2.9.189 Version/10.00', 'Officiis distinctio saepe iure sequi sit fuga repellat. Ipsum voluptate et est dolores est nobis itaque aperiam. Ipsa provident deserunt accusantium. Rerum dolores at sapiente eum.', '2009-05-18 08:11:22'),
(843280580, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_2 like Mac OS X; en-US) AppleWebKit/532.33.2 (KHTML, like Geck', 'Ullam ad repudiandae eligendi sed non ab. Consequatur et non impedit maxime. Sapiente officia maiores est. Suscipit ut aspernatur id corrupti animi.', '1983-02-21 07:40:26'),
(850709546, 'Mozilla/5.0 (Windows; U; Windows NT 6.2) AppleWebKit/531.49.7 (KHTML, like Gecko) Version/5.0.3 Safa', 'Ut soluta quae natus asperiores repellendus dignissimos. Optio in facere ex natus illum qui.', '1999-12-05 07:54:31'),
(856276622, 'Mozilla/5.0 (Windows; U; Windows NT 6.1) AppleWebKit/532.9.4 (KHTML, like Gecko) Version/5.0.4 Safar', 'Sit impedit esse reiciendis eum nostrum. Eius magni architecto placeat. Est quo porro quam veritatis vel.', '2001-01-20 18:23:52'),
(859096322, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_8_1 rv:5.0; sl-SI) AppleWebKit/533.24.4 (KHTML, like Gecko) ', 'Aut repellat distinctio et qui laborum. Voluptates nam accusamus rerum dolores. Esse nihil id sint qui aliquam rerum rerum assumenda. Necessitatibus sapiente voluptatum hic quidem rem saepe corrupti.', '2013-07-08 01:13:56'),
(860030009, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_2 like Mac OS X; sl-SI) AppleWebKit/532.29.4 (KHTML, like Geck', 'Rerum omnis maxime harum ut. Sed ipsum iure placeat ut libero et. Exercitationem delectus consequuntur aut. Repellat et rerum quod eligendi dolores dolores consequatur.', '1981-08-10 15:25:38'),
(861572398, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_9 rv:5.0) Gecko/20140824 Firefox/3.8', 'Praesentium magni adipisci aut sint. Et et rem nesciunt enim. Cupiditate architecto libero magnam eum magnam.', '1979-09-27 17:15:24'),
(861720813, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_3 like Mac OS X; en-US) AppleWebKit/532.38.2 (KHTML, like Geck', 'Totam commodi amet nostrum sit. Exercitationem nulla reiciendis quia ut et. Beatae et ducimus adipisci sint voluptas. Veritatis voluptas non repellendus id nulla.', '1988-03-15 09:13:30'),
(862842010, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_3) AppleWebKit/5342 (KHTML, like Gecko) Chrome/13.0.822.', 'Nam id libero consectetur neque. Debitis doloribus dolorem non enim. Ab necessitatibus repudiandae molestias voluptas.', '1981-10-22 10:26:45'),
(865222169, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_0 rv:3.0; en-US) AppleWebKit/532.44.1 (KHTML, like Gecko', 'Aut non aut nam saepe tempore voluptatum. Molestiae aspernatur perspiciatis voluptatem laborum consequatur sint. Non quia nostrum et ipsam consequatur architecto quas.', '1974-09-03 04:48:52'),
(868041775, 'Opera/8.93 (X11; Linuxi686; en-US) Presto/2.9.170 Version/12.00', 'Labore ducimus qui dolor beatae. Illum quia exercitationem aut ullam. Rerum reiciendis perspiciatis explicabo eveniet sunt.', '1978-07-29 14:08:29'),
(873935225, 'Opera/8.25 (Windows NT 5.0; en-US) Presto/2.9.161 Version/11.00', 'Et quos rerum quos magnam. Id dolorem cumque enim quo. Eveniet similique recusandae molestias dolor.', '2025-01-16 08:15:29'),
(881824683, 'Opera/8.39 (X11; Linuxi686; sl-SI) Presto/2.9.178 Version/12.00', 'Explicabo laboriosam temporibus harum. Quia laborum ea et maiores consequatur esse dolorem. Sed officia quam voluptatem voluptatem similique. Eveniet quos porro autem eos et omnis magni.', '2004-06-30 10:18:46'),
(887600460, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 4_3 like Mac OS X; sl-SI) AppleWebKit/531.43.5 (KHTML, like Geck', 'Magnam omnis eligendi ab. Voluptate voluptatum ut facilis expedita nostrum vel. At voluptas tempore deleniti tempore.', '2021-03-18 10:29:52'),
(891467513, 'Mozilla/5.0 (X11; Linuxi686; rv:7.0) Gecko/20140213 Firefox/3.8', 'Iure accusamus consectetur officiis sit. Autem labore non asperiores laboriosam. Voluptas velit dolores laborum architecto et aut. Expedita dolores nihil modi natus. Ea sed vitae in provident.', '2002-08-02 01:12:12'),
(891824896, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows CE; Trident/3.0)', 'Consectetur ipsam natus quam cumque commodi dignissimos quis dolore. Minima accusamus consequatur quo nihil qui. Et eveniet quo quibusdam velit suscipit eligendi.', '1997-09-15 07:32:11'),
(893127593, 'Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.2; Trident/4.0)', 'Officia voluptatem minima qui ea. Ipsa rerum aut incidunt accusamus quasi incidunt eaque. Et dolorem maiores nostrum et asperiores. Et ut nisi voluptas aut.', '1973-01-28 17:17:46'),
(900366604, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 6.0; Trident/3.0)', 'Et libero dolorum doloremque autem non. Dolor aut cupiditate quibusdam accusamus voluptas repellat quam. Blanditiis sunt expedita et minus repudiandae molestiae rerum. Omnis a repellat voluptatibus reiciendis. Debitis ipsam voluptas non reiciendis provident.', '1987-02-08 00:55:02'),
(905590321, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.1; Trident/5.1)', 'Fugit debitis a nesciunt labore. Enim aliquam facere sunt atque.', '1979-05-31 20:05:58'),
(915845744, 'Opera/8.89 (X11; Linuxx86_64; en-US) Presto/2.9.169 Version/12.00', 'Unde dolore eos non soluta quam pariatur dignissimos aut. Quasi quia harum molestias ut aut facilis excepturi. Architecto laudantium minima itaque fuga aut quia.', '1970-10-16 17:23:41'),
(938933154, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.2; Trident/4.0)', 'Iste excepturi ullam tempora assumenda vel deserunt. Totam qui repudiandae ullam iure qui quia. Similique perspiciatis libero ut saepe. Vero occaecati veniam reiciendis aut voluptatum vero ea fugiat.', '1981-07-01 06:49:34'),
(938938877, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_5_1 rv:6.0) Gecko/20180106 Firefox/13.0', 'Et rem sint ratione nihil sed. Beatae similique vel id quia rem aperiam consequatur. Quo dolor omnis nesciunt consequuntur. Minus soluta magni qui neque. Hic explicabo veritatis voluptas facilis libero commodi.', '1977-09-25 18:21:36'),
(953542234, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_2 like Mac OS X; en-US) AppleWebKit/532.11.6 (KHTML, like Geck', 'Perspiciatis earum sed eveniet. Distinctio exercitationem tempora laborum nam blanditiis et porro. Ex est eos exercitationem facilis in neque aspernatur.', '2017-11-10 08:10:31'),
(954056430, 'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.1)', 'Qui necessitatibus ad omnis nihil non et. Molestias commodi fugiat ad culpa ut aut. Aut ducimus quia sint id aspernatur cumque perspiciatis pariatur. Tempora sit perferendis sint in alias.', '1993-02-21 13:51:54'),
(969448593, 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10_7_5 rv:5.0; en-US) AppleWebKit/531.14.5 (KHTML, like Gecko) ', 'Non magni facere aliquam et sit. Voluptatem ad accusantium saepe ullam quia ea. Qui est commodi quos laboriosam rerum aut. Omnis dolor omnis nihil itaque.', '1973-01-08 20:56:14'),
(973012936, 'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_0 like Mac OS X; sl-SI) AppleWebKit/531.24.3 (KHTML, like Geck', 'Illum eum laudantium quasi eius eligendi voluptatum deserunt aspernatur. Et est non voluptates qui. Pariatur sint delectus itaque tempora ratione quia. Optio occaecati natus iure et.', '1995-11-22 23:58:01'),
(980688236, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.1; Trident/4.0)', 'Rerum id sint earum id dolores. Aut facere incidunt quidem dicta quisquam quaerat. Eos omnis reiciendis exercitationem a magni.', '1973-10-14 22:23:10'),
(993155097, 'Mozilla/5.0 (Windows NT 4.0; en-US; rv:1.9.1.20) Gecko/20190916 Firefox/3.6.9', 'Neque occaecati error ut aut non. Recusandae ut asperiores assumenda soluta vel. Perspiciatis soluta et cumque sunt culpa sed dolores quis.', '1991-06-28 00:47:34');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `customer_email` varchar(100) DEFAULT NULL,
  `customer_address` text DEFAULT NULL,
  `customer_type` enum('Regular','Premium','Wholesale') DEFAULT 'Regular',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `branch_id`, `customer_name`, `customer_phone`, `customer_email`, `customer_address`, `customer_type`, `created_at`) VALUES
(5, NULL, 'test2', 'jkjkfjskd55', 'kjfksdj@gmail.com', 'test2', 'Regular', '2025-05-03 00:06:51'),
(6, NULL, 'test3', '3423', 'hjghg@gmai.com', 'test3', 'Premium', '2025-05-03 00:07:02'),
(7, NULL, 'test', '2432', '2342@fjasdklf.com', 'dsfasd', 'Wholesale', '2025-05-03 00:14:09'),
(8, NULL, 'test final ', '2342343', 'sdkfs@gmail.com', 'ahmedabad', 'Wholesale', '2025-05-03 02:00:24'),
(9, NULL, 'maru test puru', '92804923840', 'sdkfjs@gmail.com', 'final', 'Premium', '2025-05-03 02:19:39');

-- --------------------------------------------------------

--
-- Table structure for table `gst_reports`
--

CREATE TABLE `gst_reports` (
  `id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `invoice_type` enum('purchase','sale') DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `gst_percent` decimal(5,2) DEFAULT NULL,
  `taxable_value` decimal(10,2) DEFAULT NULL,
  `gst_amount` decimal(10,2) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `unit` varchar(20) DEFAULT NULL,
  `hsn` varchar(20) DEFAULT NULL,
  `gst` decimal(5,2) DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `min_stock` int(11) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `active` tinyint(4) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `name`, `code`, `category`, `unit`, `hsn`, `gst`, `cost`, `price`, `stock`, `min_stock`, `type`, `active`) VALUES
(1, 'cable-5mm-red', 'cable-1242-red-5mm', 'cable', '50', 'row meterial', 3.00, 333.00, 230.00, 100, 3, 'Finished', 0),
(3, 'cable-5mm-green', 'cbl-5grn', 'cable', '55', 'row meterial', 18.00, 55.00, 55.00, 5, 5, 'Raw', 1);

-- --------------------------------------------------------

--
-- Table structure for table `medicines`
--

CREATE TABLE `medicines` (
  `id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `generic_name` varchar(100) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `manufacturer` varchar(100) DEFAULT NULL,
  `hsn_code` varchar(20) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `pos_transactions`
--

CREATE TABLE `pos_transactions` (
  `id` int(11) NOT NULL,
  `invoice_no` varchar(50) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `sale_date` datetime DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `discount` varchar(100) DEFAULT NULL,
  `tax_total` varchar(100) DEFAULT NULL,
  `paid_amount` varchar(100) DEFAULT NULL,
  `payment_mode` varchar(50) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL,
  `company_id` int(100) DEFAULT NULL,
  `status` enum('pending','success','cancel') NOT NULL DEFAULT 'pending',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pos_transactions`
--

INSERT INTO `pos_transactions` (`id`, `invoice_no`, `customer_id`, `sale_date`, `total_amount`, `discount`, `tax_total`, `paid_amount`, `payment_mode`, `created_by`, `branch_id`, `store_id`, `company_id`, `status`, `created_at`) VALUES
(1, 'INV1', NULL, NULL, 249.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'pending', '2025-05-06 11:19:02'),
(2, 'INV2', NULL, NULL, 1524.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'pending', '2025-05-06 11:20:38'),
(3, 'INV3', NULL, NULL, 249.00, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, 'pending', '2025-05-06 11:21:29');

-- --------------------------------------------------------

--
-- Table structure for table `pos_transaction_items`
--

CREATE TABLE `pos_transaction_items` (
  `id` int(11) NOT NULL,
  `pos_transaction_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `rate` decimal(10,2) NOT NULL,
  `discount` decimal(10,2) DEFAULT 0.00,
  `amount` decimal(10,2) GENERATED ALWAYS AS ((`rate` - `discount`) * `quantity`) STORED,
  `total_price` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pos_transaction_items`
--

INSERT INTO `pos_transaction_items` (`id`, `pos_transaction_id`, `product_id`, `quantity`, `rate`, `discount`, `total_price`, `created_at`) VALUES
(1, 1, 1, 1, 249.00, 0.00, '249', '2025-05-06 11:19:02'),
(2, 2, 2, 1, 149.00, 0.00, '149', '2025-05-06 11:20:38'),
(3, 2, 5, 1, 129.00, 0.00, '129', '2025-05-06 11:20:38'),
(4, 2, 7, 1, 499.00, 0.00, '499', '2025-05-06 11:20:38'),
(5, 2, 9, 1, 349.00, 0.00, '349', '2025-05-06 11:20:38'),
(6, 2, 2, 1, 149.00, 0.00, '149', '2025-05-06 11:20:38'),
(7, 2, 1, 1, 249.00, 0.00, '249', '2025-05-06 11:20:38'),
(8, 3, 1, 1, 249.00, 0.00, '249', '2025-05-06 11:21:29');

-- --------------------------------------------------------

--
-- Table structure for table `po_items`
--

CREATE TABLE `po_items` (
  `id` int(11) NOT NULL,
  `purchase_master_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `rate` decimal(10,2) NOT NULL,
  `amount` decimal(10,2) GENERATED ALWAYS AS (`rate` * `quantity`) STORED,
  `mrp` varchar(100) DEFAULT NULL,
  `item_gst` varchar(100) DEFAULT NULL,
  `purchase_price` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `po_items`
--

INSERT INTO `po_items` (`id`, `purchase_master_id`, `product_id`, `quantity`, `rate`, `mrp`, `item_gst`, `purchase_price`, `created_at`) VALUES
(5, 2, 18, 15, 555.00, NULL, NULL, NULL, '2025-05-07 22:25:17'),
(6, 2, 10, 17, 499.00, NULL, NULL, NULL, '2025-05-07 22:25:17'),
(7, 2, 4, 18, 299.00, NULL, NULL, NULL, '2025-05-07 22:25:17'),
(8, 3, 11, 7, 899.00, NULL, NULL, NULL, '2025-05-07 22:42:47'),
(9, 3, 8, 3, 699.00, NULL, NULL, NULL, '2025-05-07 22:42:47'),
(10, 3, 4, 8, 299.00, NULL, NULL, NULL, '2025-05-07 22:42:47'),
(11, 3, 7, 3, 499.00, NULL, NULL, NULL, '2025-05-07 22:42:47');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `company_id` int(27) NOT NULL,
  `name` varchar(150) NOT NULL,
  `sku` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `MRP` int(25) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `subcategory_id` int(11) DEFAULT NULL,
  `image_path` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `unit_id`, `company_id`, `name`, `sku`, `description`, `price`, `MRP`, `category_id`, `subcategory_id`, `image_path`, `created_at`) VALUES
(1, NULL, 1, 'HDMI Cable 5m', 'HDMI-5M-001', NULL, 249.00, NULL, 1, 2, NULL, '2025-04-29 17:35:36'),
(2, NULL, 1, 'USB Cable 1m', 'SKU1001', 'Durable 1 meter USB charging cable', 149.00, NULL, 1, 1, NULL, '2025-04-29 17:50:30'),
(3, NULL, 1, 'USB Cable 2m', 'SKU1002', 'High-quality 2 meter cable for fast charging', 199.00, NULL, 1, 1, NULL, '2025-04-29 17:50:30'),
(4, NULL, 1, 'HDMI Cable 1.5m', 'SKU1003', '1.5 meter HDMI cable for TVs and Monitors', 299.00, NULL, 1, 2, NULL, '2025-04-29 17:50:30'),
(5, NULL, 1, 'Micro USB Cable', 'SKU1004', 'Universal micro USB cable', 129.00, NULL, 1, 1, NULL, '2025-04-29 17:50:30'),
(6, NULL, 1, 'Type-C Cable', 'SKU1005', 'Fast charging Type-C USB cable', 159.00, NULL, 1, 1, NULL, '2025-04-29 17:50:30'),
(7, NULL, 1, 'PVC Water Pipe 1 inch', 'SKU1006', 'High quality PVC pipe 1 inch diameter', 499.00, NULL, 2, 3, NULL, '2025-04-29 17:50:30'),
(8, NULL, 1, 'PVC Water Pipe 2 inch', 'SKU1007', 'Durable pipe for plumbing', 699.00, NULL, 2, 3, NULL, '2025-04-29 17:50:30'),
(9, NULL, 1, 'Flexible Pipe 1m', 'SKU1008', 'Bendable pipe for home use', 349.00, NULL, 2, 4, NULL, '2025-04-29 17:50:30'),
(10, NULL, 1, 'Flexible Pipe 2m', 'SKU1009', '2 meter flexible pipe', 499.00, NULL, 2, 4, NULL, '2025-04-29 17:50:30'),
(11, NULL, 1, 'Steel Pipe 1.5 inch', 'SKU1010', 'Heavy-duty steel pipe', 899.00, NULL, 2, 5, NULL, '2025-04-29 17:50:30'),
(12, NULL, 2, 'Mobile Screen Guard for iPhone 13', 'SKU1011', 'Tempered glass screen guard', 299.00, NULL, 3, 6, NULL, '2025-04-29 17:50:30'),
(13, NULL, 2, 'Screen Guard for Samsung A52', 'SKU1012', 'High clarity guard', 249.00, NULL, 3, 6, NULL, '2025-04-29 17:50:30'),
(14, NULL, 2, 'Screen Guard for Redmi Note 10', 'SKU1013', 'Anti-scratch glass', 199.00, NULL, 3, 6, NULL, '2025-04-29 17:50:30'),
(15, NULL, 2, 'Mobile Back Cover for iPhone 13', 'SKU1014', 'Soft silicon back case', 399.00, NULL, 3, 7, NULL, '2025-04-29 17:50:30'),
(16, NULL, 2, 'Back Cover for Samsung A52', 'SKU1015', 'Shockproof back cover', 349.00, NULL, 3, 7, NULL, '2025-04-29 17:50:30'),
(17, NULL, 2, 'Back Cover for Vivo Y21', 'SKU1050', 'Perfect fitting case for Vivo Y21', 249.00, NULL, 3, 7, NULL, '2025-04-29 17:50:30'),
(18, 2, 0, 'test', NULL, 'test', 555.00, NULL, 2, 7, 'uploads/1746006424_priti.jpg', '2025-04-30 09:47:04'),
(19, 5, 3, 'test2', NULL, 'test 2', 7.00, NULL, 3, 11, 'uploads/1746007778_photo.jpg', '2025-04-30 10:09:38');

-- --------------------------------------------------------

--
-- Table structure for table `product_attributes`
--

CREATE TABLE `product_attributes` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `attribute_name` varchar(100) NOT NULL,
  `attribute_value` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_attributes`
--

INSERT INTO `product_attributes` (`id`, `product_id`, `attribute_name`, `attribute_value`) VALUES
(1, 1, 'Length', '5 Meter'),
(2, 1, 'Color', 'Black'),
(3, 1, 'Material', 'Copper');

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `image_url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`id`, `product_id`, `image_url`) VALUES
(1, 1, 'hdmi-cable-5m.jpg'),
(2, 1, 'hdmi-cable-side.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_master`
--

CREATE TABLE `purchase_master` (
  `id` int(11) NOT NULL,
  `company_id` int(100) DEFAULT NULL,
  `po_no` varchar(50) NOT NULL,
  `supplier_id` int(25) DEFAULT NULL,
  `total_amount` varchar(100) DEFAULT NULL,
  `received_date` datetime NOT NULL DEFAULT current_timestamp(),
  `branch_id` int(25) DEFAULT NULL,
  `store_id` int(25) DEFAULT NULL,
  `created_by` int(25) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `purchase_master`
--

INSERT INTO `purchase_master` (`id`, `company_id`, `po_no`, `supplier_id`, `total_amount`, `received_date`, `branch_id`, `store_id`, `created_by`, `created_at`) VALUES
(2, NULL, 'GRN2', NULL, '22190', '2025-05-07 22:25:17', NULL, NULL, NULL, '2025-05-07 16:55:17'),
(3, NULL, 'GRN3', NULL, '12279', '2025-05-07 22:42:47', NULL, NULL, NULL, '2025-05-07 17:12:47');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `invoice_no` varchar(50) DEFAULT NULL,
  `sale_date` datetime DEFAULT current_timestamp(),
  `total_amount` decimal(10,2) DEFAULT NULL,
  `gst_percent` decimal(5,2) DEFAULT NULL,
  `discount` decimal(10,2) DEFAULT 0.00,
  `net_total` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `branch_id`, `customer_id`, `invoice_no`, `sale_date`, `total_amount`, `gst_percent`, `discount`, `net_total`) VALUES
(1, 7879, 87, '78', '1999-08-07 00:00:00', 7.00, 7.00, 7.00, 8.00),
(2, 5542, 11, '11', '2025-05-07 00:00:00', 798.00, 7.00, 8789.00, 79.00),
(3, 0, 75, '976', '2025-05-03 00:00:00', 77867.00, 7.00, 66.00, 677.00);

-- --------------------------------------------------------

--
-- Table structure for table `sale_items`
--

CREATE TABLE `sale_items` (
  `id` int(11) NOT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `medicine_id` int(11) DEFAULT NULL,
  `batch_no` varchar(50) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `rate` decimal(10,2) DEFAULT NULL,
  `discount` decimal(10,2) DEFAULT NULL,
  `gst_percent` decimal(5,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sale_items`
--

INSERT INTO `sale_items` (`id`, `sale_id`, `medicine_id`, `batch_no`, `expiry_date`, `quantity`, `rate`, `discount`, `gst_percent`, `total`) VALUES
(8, 3, 0, '6', '2025-05-03', 3248, 8789.00, 78978.00, 999.99, 987987.00),
(9, 3, 392, '6876', '2025-05-03', 76, 966.00, 757.00, 54.00, 854.00),
(10, 3, 0, '7657', '2025-05-03', 86, 7.00, 56.00, 4.00, 54.00),
(35, 2, 0, 'werasda', '2025-05-03', 23, 5.00, 5.00, 4.00, 4.00),
(36, 2, 0, 'sdf', '2025-05-05', 5, 5.00, 5.00, 4.00, 4.00),
(37, 2, 0, 'aa', '2025-05-03', 5, 5.00, 4.00, 4.00, 4.00),
(38, 1, 0, '7', '2025-05-03', 77, 77.00, 7.00, 7.00, 7.00);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `setting_key` varchar(100) DEFAULT NULL,
  `setting_value` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `sku_master`
--

CREATE TABLE `sku_master` (
  `id` int(11) NOT NULL,
  `sku_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sku_master`
--

INSERT INTO `sku_master` (`id`, `sku_name`, `description`, `company_id`, `created_at`) VALUES
(1, 'test sku 2', 'final', 3, '2025-04-30 16:16:50'),
(2, 'rj45', 'clear', 3, '2025-04-30 16:33:01');

-- --------------------------------------------------------

--
-- Table structure for table `sku_products`
--

CREATE TABLE `sku_products` (
  `id` int(11) NOT NULL,
  `sku_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `unit_type` varchar(50) DEFAULT NULL,
  `quantity` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sku_products`
--

INSERT INTO `sku_products` (`id`, `sku_id`, `product_id`, `unit_type`, `quantity`, `created_at`, `updated_at`) VALUES
(39, 1, 2, 'Meter', 5.00, '2025-05-03 13:36:22', '2025-05-03 13:36:22'),
(40, 1, 10, 'Feet', 4.00, '2025-05-03 13:36:22', '2025-05-03 13:36:22'),
(46, 2, 17, 'Liter', 3.00, '2025-05-04 11:29:41', '2025-05-04 11:29:41'),
(47, 2, 8, 'Meter', 500.00, '2025-05-04 11:29:41', '2025-05-04 11:29:41'),
(48, 2, 9, 'Nos', 700.00, '2025-05-04 11:29:41', '2025-05-04 11:29:41');

-- --------------------------------------------------------

--
-- Table structure for table `stock_alerts`
--

CREATE TABLE `stock_alerts` (
  `id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `medicine_id` int(11) DEFAULT NULL,
  `alert_type` enum('low_stock','expiry') DEFAULT NULL,
  `alert_date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `stock_ledger`
--

CREATE TABLE `stock_ledger` (
  `id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `medicine_id` int(11) DEFAULT NULL,
  `batch_no` varchar(50) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `stock_in` int(11) DEFAULT 0,
  `stock_out` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `id` int(11) NOT NULL,
  `store_name` varchar(100) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `location` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `subcategories`
--

CREATE TABLE `subcategories` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subcategories`
--

INSERT INTO `subcategories` (`id`, `category_id`, `name`, `description`, `created_at`) VALUES
(1, 1, 'Type-C', NULL, '2025-04-29 17:35:36'),
(2, 1, 'HDMI', NULL, '2025-04-29 17:35:36'),
(3, 2, 'PVC', NULL, '2025-04-29 17:35:36'),
(4, 3, 'Screen Guard', NULL, '2025-04-29 17:35:36'),
(5, 1, 'USB Cable', 'All types of USB cables including micro USB, Type-C, etc.', '2025-04-29 17:55:13'),
(6, 1, 'HDMI Cable', 'HDMI cables for connecting TVs, monitors, etc.', '2025-04-29 17:55:13'),
(7, 2, 'PVC Pipe', 'PVC pipes for plumbing and water supply.', '2025-04-29 17:55:13'),
(8, 2, 'Flexible Pipe', 'Flexible pipes for various household uses.', '2025-04-29 17:55:13'),
(9, 2, 'Steel Pipe', 'Heavy-duty steel pipes for industrial use.', '2025-04-29 17:55:13'),
(10, 3, 'Screen Guard', 'Screen protection products for mobile phones.', '2025-04-29 17:55:13'),
(11, 3, 'Back Cover', 'Protective covers for mobile phones', '2025-04-29 17:55:13');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `Supplier_name` varchar(100) DEFAULT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `gst_no` varchar(20) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `branch_id`, `Supplier_name`, `contact_person`, `phone`, `email`, `address`, `gst_no`, `created_at`) VALUES
(1, 1, 'intas pharmaceuticals limited', 'MANOJ', '0980238029', 'kfsadjfkl@gmail.com', 'aaaa1', '55555', '2025-05-02 18:42:03'),
(2, 1, 'zydus lifesciences ltd', 'ramakant', '908923480923', 'ksdjfskdj@gma.com', 'sajklasjd', 'kjskljfk', '2025-05-02 18:53:32'),
(5, 2, 'cadila pharmaceuticals', 'ashok', '98209348203', 'test3@gmail.com', 'djfakjfa', 'ksjfksadjk', '2025-05-02 22:35:25');

-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE `units` (
  `id` int(11) NOT NULL,
  `unit_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `units`
--

INSERT INTO `units` (`id`, `unit_name`) VALUES
(1, 'Liter'),
(2, 'Meter'),
(3, 'Nos'),
(4, 'Feet'),
(5, 'Kg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `role` enum('admin','cashier','pharmacist','manager') DEFAULT NULL,
  `status` tinyint(4) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gst_reports`
--
ALTER TABLE `gst_reports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `medicines`
--
ALTER TABLE `medicines`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pos_transactions`
--
ALTER TABLE `pos_transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `invoice_no` (`invoice_no`);

--
-- Indexes for table `pos_transaction_items`
--
ALTER TABLE `pos_transaction_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `po_items`
--
ALTER TABLE `po_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sku` (`sku`);

--
-- Indexes for table `product_attributes`
--
ALTER TABLE `product_attributes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchase_master`
--
ALTER TABLE `purchase_master`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `grn_no` (`po_no`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sale_items`
--
ALTER TABLE `sale_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sku_master`
--
ALTER TABLE `sku_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sku_products`
--
ALTER TABLE `sku_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sku_id` (`sku_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `stock_alerts`
--
ALTER TABLE `stock_alerts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stock_ledger`
--
ALTER TABLE `stock_ledger`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `store_name` (`store_name`);

--
-- Indexes for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `units`
--
ALTER TABLE `units`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `branches`
--
ALTER TABLE `branches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=993155098;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `gst_reports`
--
ALTER TABLE `gst_reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `medicines`
--
ALTER TABLE `medicines`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pos_transactions`
--
ALTER TABLE `pos_transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pos_transaction_items`
--
ALTER TABLE `pos_transaction_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `po_items`
--
ALTER TABLE `po_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `product_attributes`
--
ALTER TABLE `product_attributes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `purchase_master`
--
ALTER TABLE `purchase_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sale_items`
--
ALTER TABLE `sale_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sku_master`
--
ALTER TABLE `sku_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sku_products`
--
ALTER TABLE `sku_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `stock_alerts`
--
ALTER TABLE `stock_alerts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stock_ledger`
--
ALTER TABLE `stock_ledger`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subcategories`
--
ALTER TABLE `subcategories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `units`
--
ALTER TABLE `units`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sku_products`
--
ALTER TABLE `sku_products`
  ADD CONSTRAINT `sku_products_ibfk_1` FOREIGN KEY (`sku_id`) REFERENCES `sku_master` (`id`),
  ADD CONSTRAINT `sku_products_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
